/* Zypher app — dependency-free SVG charts. Theme-aware via CSS tokens.
   Exported to window for the app screens. */

function _path(points) {
  return points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
}

/* Smooth area chart with gradient fill. data = array of numbers. */
function AreaChart({ data = [], height = 220, stroke = 'var(--teal)', fill = 'var(--teal)', showAxis = true }) {
  const w = 800, h = height, padX = 8, padY = 16;
  const max = Math.max(...data) * 1.08, min = Math.min(...data) * 0.92;
  const span = max - min || 1;
  const pts = data.map((d, i) => [
    padX + (i / (data.length - 1)) * (w - padX * 2),
    padY + (1 - (d - min) / span) * (h - padY * 2),
  ]);
  const id = React.useMemo(() => 'ag' + Math.random().toString(36).slice(2, 7), []);
  const line = _path(pts);
  const area = `${line} L ${pts[pts.length - 1][0].toFixed(1)} ${h} L ${pts[0][0].toFixed(1)} ${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{ width: '100%', height, display: 'block' }}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={fill} stopOpacity="0.28" />
          <stop offset="100%" stopColor={fill} stopOpacity="0" />
        </linearGradient>
      </defs>
      {showAxis && [0.25, 0.5, 0.75].map((g) => (
        <line key={g} x1={padX} x2={w - padX} y1={padY + g * (h - padY * 2)} y2={padY + g * (h - padY * 2)}
          stroke="var(--border-default)" strokeWidth="1" strokeDasharray="3 5" />
      ))}
      <path d={area} fill={`url(#${id})`} />
      <path d={line} fill="none" stroke={stroke} strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="4.5" fill={stroke} />
    </svg>
  );
}

/* Tiny inline sparkline. */
function Sparkline({ data = [], width = 88, height = 28, color = 'var(--teal)', up = true }) {
  const max = Math.max(...data), min = Math.min(...data), span = (max - min) || 1;
  const pts = data.map((d, i) => [
    (i / (data.length - 1)) * width,
    height - 2 - ((d - min) / span) * (height - 4),
  ]);
  return (
    <svg viewBox={`0 0 ${width} ${height}`} style={{ width, height, display: 'block', overflow: 'visible' }}>
      <path d={_path(pts)} fill="none" stroke={up ? color : '#DC2626'} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

/* Donut for allocation. segments = [{label, value, color}]. */
function Donut({ segments = [], size = 140, thickness = 18, centerLabel, centerSub }) {
  const r = (size - thickness) / 2, c = size / 2, circ = 2 * Math.PI * r;
  const total = segments.reduce((s, x) => s + x.value, 0) || 1;
  let offset = 0;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg viewBox={`0 0 ${size} ${size}`} style={{ width: size, height: size, transform: 'rotate(-90deg)' }}>
        <circle cx={c} cy={c} r={r} fill="none" stroke="var(--border-default)" strokeWidth={thickness} />
        {segments.map((s, i) => {
          const len = (s.value / total) * circ;
          const el = (
            <circle key={i} cx={c} cy={c} r={r} fill="none" stroke={s.color} strokeWidth={thickness}
              strokeDasharray={`${len} ${circ - len}`} strokeDashoffset={-offset} strokeLinecap="butt" />
          );
          offset += len;
          return el;
        })}
      </svg>
      {centerLabel && (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, color: 'var(--text-strong)', lineHeight: 1 }}>{centerLabel}</div>
          {centerSub && <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 3 }}>{centerSub}</div>}
        </div>
      )}
    </div>
  );
}

/* Horizontal vote/progress bar. */
function VoteBar({ value = 0, max = 100, color = 'var(--teal)', height = 8 }) {
  return (
    <div style={{ background: 'var(--border-default)', borderRadius: 999, height, overflow: 'hidden', width: '100%' }}>
      <div style={{ width: `${Math.min(100, (value / max) * 100)}%`, background: color, height: '100%', borderRadius: 999, transition: 'width var(--dur-slow)' }} />
    </div>
  );
}

/* Mini vertical bars (e.g. weekly query-fee usage). */
function BarMini({ data = [], height = 64, color = 'var(--teal)' }) {
  const max = Math.max(...data) || 1;
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height }}>
      {data.map((d, i) => (
        <div key={i} title={String(d)} style={{ flex: 1, height: `${(d / max) * 100}%`, minHeight: 3, background: i === data.length - 1 ? color : 'var(--color-primary-tint)', borderRadius: 3 }} />
      ))}
    </div>
  );
}

Object.assign(window, { AreaChart, Sparkline, Donut, VoteBar, BarMini });

/* Zypher Holder Dashboard — Providers (list + detail) + Settings. */
const { Button: CB, Badge: CBadge, MintAddress: CMint, Accordion: CAccordion } = window.ZypherDesignSystem_7d1dbd;

const PROVIDERS = [
  { npi: '1487654320', name: 'Mercy General Hospital', specialty: 'General Acute Care', loc: 'Sacramento, CA', status: 'anchored', updated: '2h ago' },
  { npi: '1992847163', name: 'Dr. Elena Park, MD', specialty: 'Cardiology', loc: 'Boston, MA', status: 'anchored', updated: '6h ago' },
  { npi: '1730495862', name: 'Cascade Family Clinic', specialty: 'Family Medicine', loc: 'Portland, OR', status: 'pending', updated: '1d ago' },
  { npi: '1558372049', name: 'Dr. Marcus Hill, DO', specialty: 'Orthopedics', loc: 'Austin, TX', status: 'anchored', updated: '2d ago' },
  { npi: '1209384756', name: 'Northside Pediatrics', specialty: 'Pediatrics', loc: 'Atlanta, GA', status: 'stale', updated: '9d ago' },
];

function Providers({ onOpen }) {
  const [q, setQ] = React.useState('');
  const rows = PROVIDERS.filter((p) => (p.name + p.npi + p.specialty + p.loc).toLowerCase().includes(q.toLowerCase()));
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 }} className="zy-grid3">
        <StatTile label="Verified Records" value="2.4M" sub="anchored on Solana" icon="shield-check" change="+18K / day" up />
        <StatTile label="Your Queries (30d)" value="118" sub="142.6 ZPH spent" icon="search" />
        <StatTile label="Avg Anchor Time" value="0.4s" sub="ingest → on-chain" icon="zap" change="−0.1s" up />
      </div>
      <Panel pad={0}>
        <div style={{ padding: '20px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
          <SectionTitle>Provider Registry</SectionTitle>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--surface-page)', border: '1px solid var(--border-default)', borderRadius: 9, padding: '8px 12px', minWidth: 260 }}>
            <Icon name="search" size={16} color="var(--text-muted)" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, NPI, specialty…" style={{ border: 'none', background: 'transparent', outline: 'none', fontFamily: 'var(--font-sans)', fontSize: 13, color: 'var(--text-strong)', width: '100%' }} />
          </div>
        </div>
        <DataTable
          onRowClick={onOpen}
          columns={[
            { key: 'name', label: 'Provider', render: (r) => <span style={{ display: 'inline-flex', alignItems: 'center', gap: 12 }}><span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--surface-tint)', color: 'var(--color-primary)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="building-2" size={16} /></span><span><span style={{ display: 'block', color: 'var(--text-strong)', fontWeight: 500 }}>{r.name}</span><span style={{ display: 'block', color: 'var(--text-muted)', fontSize: 12 }}>{r.specialty}</span></span></span> },
            { key: 'npi', label: 'NPI', render: (r) => <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-body)' }}>{r.npi}</span> },
            { key: 'loc', label: 'Location', render: (r) => <span style={{ color: 'var(--text-body)' }}>{r.loc}</span> },
            { key: 'status', label: 'Status', render: (r) => <StatusPill status={r.status} /> },
            { key: 'open', label: '', align: 'right', render: () => <Icon name="chevron-right" size={16} color="var(--text-muted)" /> },
          ]}
          rows={rows}
        />
      </Panel>
    </div>
  );
}

function ProviderDetail({ provider, onBack, notify }) {
  const p = provider || PROVIDERS[0];
  const trail = [
    { icon: 'database', t: 'Record ingested from NPPES', d: 'Federal NPI record pulled from the NPPES batch feed.', time: 'Jun 16, 2026 · 09:42 UTC', tone: 'done' },
    { icon: 'check-check', t: 'Normalized & validated', d: 'Address, taxonomy and credential fields normalized; 0 conflicts.', time: 'Jun 16, 2026 · 09:42 UTC', tone: 'done' },
    { icon: 'hash', t: 'SHA-256 hash computed', d: 'Canonical record hashed for tamper-evident anchoring.', time: 'Jun 16, 2026 · 09:42 UTC', tone: 'done' },
    { icon: 'link', t: 'Anchored to Solana', d: 'Hash written on-chain in slot 287,449,201.', time: 'Jun 16, 2026 · 09:42 UTC', tone: 'done' },
  ];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <button onClick={onBack} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 500, padding: 0, alignSelf: 'flex-start' }}>
        <Icon name="arrow-left" size={15} /> Back to registry
      </button>
      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 24 }} className="zy-grid-main">
        <Panel>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, marginBottom: 24 }}>
            <span style={{ width: 56, height: 56, borderRadius: 12, background: 'var(--surface-tint)', color: 'var(--color-primary)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Icon name="building-2" size={26} /></span>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, color: 'var(--text-strong)', margin: 0, fontWeight: 400 }}>{p.name}</h2>
                <StatusPill status={p.status} />
              </div>
              <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{p.specialty} · {p.loc}</div>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 8 }}>
            <Field k="NPI" v={p.npi} mono />
            <Field k="Taxonomy" v="207RC0000X" mono />
            <Field k="Enumeration" v="2008-05-23" />
            <Field k="Last verified" v={p.updated} />
          </div>
          <div style={{ borderTop: '1px solid var(--border-default)', marginTop: 8, paddingTop: 18 }}>
            <Eyebrow style={{ marginBottom: 12 }}>On-Chain Anchoring</Eyebrow>
            <CMint address="3xMz9Kp2vQ7Lr8sN1tWfYbHcEdJgUaRkPpZ4nVqB6mT" label="Anchor Transaction" />
            <div style={{ display: 'flex', gap: 24, fontSize: 13, color: 'var(--text-muted)', marginTop: 14, flexWrap: 'wrap' }}>
              <span>Slot: <b style={{ color: 'var(--text-strong)', fontFamily: 'var(--font-mono)' }}>287,449,201</b></span>
              <span>SHA-256: <b style={{ color: 'var(--text-strong)', fontFamily: 'var(--font-mono)' }}>a3f9…7e21</b></span>
            </div>
            <div style={{ marginTop: 16 }}>
              <CB size="sm" variant="secondary" onClick={() => notify({ tone: 'info', title: 'Opening explorer', message: 'View this anchor transaction on Solana Explorer.' })} trailingIcon={<Icon name="external-link" size={14} />}>View on Solana Explorer</CB>
            </div>
          </div>
        </Panel>
        <Panel>
          <SectionTitle>Audit Trail</SectionTitle>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {trail.map((e, i) => (
              <div key={i} style={{ display: 'flex', gap: 14 }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <span style={{ width: 34, height: 34, borderRadius: '50%', background: 'var(--color-primary-tint)', color: 'var(--color-primary)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Icon name={e.icon} size={16} /></span>
                  {i < trail.length - 1 && <span style={{ width: 2, flex: 1, minHeight: 24, background: 'var(--border-default)', margin: '4px 0' }} />}
                </div>
                <div style={{ paddingBottom: 18 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-strong)' }}>{e.t}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--text-muted)', lineHeight: 1.5, margin: '2px 0 4px' }}>{e.d}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{e.time}</div>
                </div>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}

function Field({ k, v, mono }) {
  return (
    <div>
      <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600, marginBottom: 4 }}>{k}</div>
      <div style={{ fontSize: 14, color: 'var(--text-strong)', fontWeight: 500, fontFamily: mono ? 'var(--font-mono)' : 'inherit' }}>{v}</div>
    </div>
  );
}

/* ---------- SETTINGS ---------- */
function Settings({ theme, setTheme, notify }) {
  const [name, setName] = React.useState('zypher.holder');
  const [notifs, setNotifs] = React.useState({ rewards: true, governance: true, queries: false, security: true });
  const wallets = [
    { label: 'Phantom', addr: '8sG1…r82t', primary: true },
    { label: 'Solflare', addr: '4Kp9…a7d1', primary: false },
  ];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24, maxWidth: 860 }}>
      <Panel style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <SectionTitle>Account</SectionTitle>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <span style={{ width: 56, height: 56, borderRadius: '50%', background: 'var(--teal)', color: '#fff', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontSize: 24 }}>Z</span>
          <label style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-body)' }}>Display name</span>
            <input value={name} onChange={(e) => setName(e.target.value)} style={{ ...inp(), maxWidth: 320 }} />
          </label>
        </div>
      </Panel>

      <Panel style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <SectionTitle action={<CB size="sm" variant="secondary" onClick={() => notify({ tone: 'info', title: 'Connect wallet', message: 'Choose a wallet provider to link.' })}>Connect wallet</CB>}>Connected Wallets</SectionTitle>
        {wallets.map((w) => (
          <div key={w.label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 14px', border: '1px solid var(--border-default)', borderRadius: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--surface-tint)', color: 'var(--color-primary)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="wallet" size={16} /></span>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-strong)' }}>{w.label} {w.primary && <CBadge tone="done">Primary</CBadge>}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{w.addr}</div>
              </div>
            </div>
            <button onClick={() => notify({ tone: 'warn', title: 'Disconnect wallet', message: `${w.label} would be unlinked.` })} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}><Icon name="x" size={18} /></button>
          </div>
        ))}
      </Panel>

      <Panel style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <SectionTitle>Appearance</SectionTitle>
        <div style={{ display: 'flex', gap: 12 }}>
          {[['light', 'sun', 'Light'], ['dark', 'moon', 'Dark']].map(([val, icon, label]) => (
            <button key={val} onClick={() => setTheme(val)} style={{
              flex: 1, display: 'flex', alignItems: 'center', gap: 10, padding: '14px 18px', borderRadius: 12, cursor: 'pointer', fontFamily: 'var(--font-sans)', fontSize: 14, fontWeight: 600,
              border: `2px solid ${theme === val ? 'var(--color-primary)' : 'var(--border-default)'}`, background: theme === val ? 'var(--color-primary-tint)' : 'var(--surface-card)', color: theme === val ? 'var(--color-primary)' : 'var(--text-body)',
            }}>
              <Icon name={icon} size={18} /> {label}
              {theme === val && <Icon name="check" size={16} style={{ marginLeft: 'auto' }} />}
            </button>
          ))}
        </div>
      </Panel>

      <Panel style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <SectionTitle>Notifications</SectionTitle>
        {[['rewards', 'Staking rewards'], ['governance', 'Governance proposals'], ['queries', 'Query-fee receipts'], ['security', 'Security alerts']].map(([k, label]) => (
          <div key={k} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid var(--border-default)' }}>
            <span style={{ fontSize: 14, color: 'var(--text-body)' }}>{label}</span>
            <Switch on={notifs[k]} onToggle={() => setNotifs((s) => ({ ...s, [k]: !s[k] }))} />
          </div>
        ))}
      </Panel>
    </div>
  );
}

function Switch({ on, onToggle }) {
  return (
    <button onClick={onToggle} aria-pressed={on} style={{
      width: 42, height: 24, borderRadius: 999, border: 'none', cursor: 'pointer', padding: 2, transition: 'background var(--dur-base)',
      background: on ? 'var(--teal)' : 'var(--border-strong)', display: 'flex', justifyContent: on ? 'flex-end' : 'flex-start',
    }}>
      <span style={{ width: 20, height: 20, borderRadius: '50%', background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.3)', transition: 'all var(--dur-base)' }} />
    </button>
  );
}

Object.assign(window, { Providers, ProviderDetail, Field, Settings, Switch, PROVIDERS });

/* Zypher Holder Dashboard — App root: routing, theme, toasts. */
const { ToastViewport: AppToastViewport } = window.ZypherDesignSystem_7d1dbd;

function useToast(autoDismiss = 3800) {
  const [toasts, setToasts] = React.useState([]);
  const dismiss = React.useCallback((id) => setToasts((c) => c.filter((t) => t.id !== id)), []);
  const notify = React.useCallback((t) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((c) => [...c, { id, ...t }]);
    if (autoDismiss) setTimeout(() => dismiss(id), autoDismiss);
    return id;
  }, [autoDismiss, dismiss]);
  return { toasts, notify, dismiss };
}

const TITLES = {
  overview: ['Overview', 'Good morning — here\u2019s your ZPH at a glance'],
  wallet: ['Wallet', 'Manage your ZPH balance and transactions'],
  staking: ['Staking', 'Earn rewards by securing the Zypher network'],
  governance: ['Governance', 'Shape the protocol with your voting power'],
  providers: ['Providers', 'Search the verified on-chain provider registry'],
  settings: ['Settings', 'Account, wallets and preferences'],
};

function App() {
  const [theme, setThemeState] = React.useState(() => {
    try { return localStorage.getItem('zy-app-theme') || 'light'; } catch (e) { return 'light'; }
  });
  const [screen, setScreen] = React.useState('overview');
  const [provider, setProvider] = React.useState(null);
  const { toasts, notify, dismiss } = useToast();

  const setTheme = React.useCallback((t) => {
    setThemeState(t);
    try { localStorage.setItem('zy-app-theme', t); } catch (e) {}
  }, []);
  const toggleTheme = () => setTheme(theme === 'dark' ? 'light' : 'dark');

  const nav = (id) => { setProvider(null); setScreen(id); };

  let body;
  if (screen === 'overview') body = <Overview onNav={nav} />;
  else if (screen === 'wallet') body = <Wallet notify={notify} />;
  else if (screen === 'staking') body = <Staking notify={notify} />;
  else if (screen === 'governance') body = <Governance notify={notify} />;
  else if (screen === 'providers') body = provider
    ? <ProviderDetail provider={provider} onBack={() => setProvider(null)} notify={notify} />
    : <Providers onOpen={setProvider} />;
  else if (screen === 'settings') body = <Settings theme={theme} setTheme={setTheme} notify={notify} />;

  const [title, subtitle] = provider && screen === 'providers'
    ? ['Provider Record', 'Verified on-chain provider detail']
    : (TITLES[screen] || ['', '']);

  return (
    <div data-theme={theme} className="zy-app" style={{ display: 'flex', minHeight: '100vh', background: 'var(--surface-page)', color: 'var(--text-strong)', fontFamily: 'var(--font-sans)' }}>
      <Sidebar active={screen} onNav={nav} />
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <Topbar title={title} subtitle={subtitle} theme={theme} onToggleTheme={toggleTheme}
          onNotify={() => notify({ tone: 'info', title: '2 new notifications', message: 'Staking reward received · ZIP-016 is now open for voting.' })} />
        <main style={{ flex: 1, padding: 32 }} className="zy-main">{body}</main>
      </div>
      <AppToastViewport toasts={toasts} onDismiss={dismiss} position="bottom-right" />
    </div>
  );
}

window.ZypherApp = App;

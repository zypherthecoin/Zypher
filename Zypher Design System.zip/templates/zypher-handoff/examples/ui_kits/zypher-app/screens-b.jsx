/* Zypher Holder Dashboard — Staking + Governance screens. */
const { Button: AB, Badge: ABadge } = window.ZypherDesignSystem_7d1dbd;

/* ---------- STAKING ---------- */
function Staking({ notify }) {
  const [amount, setAmount] = React.useState('');
  const [mode, setMode] = React.useState('stake');
  const validators = [
    { name: 'Helius', status: 'active', apy: '6.2%', stake: '8,000', uptime: '99.98%', you: true },
    { name: 'Triton One', status: 'active', apy: '6.0%', stake: '12,000', uptime: '99.95%', you: true },
    { name: 'Figment', status: 'active', apy: '5.8%', stake: '8,000', uptime: '99.91%', you: true },
    { name: 'Chorus One', status: 'active', apy: '5.9%', stake: '—', uptime: '99.97%', you: false },
    { name: 'Everstake', status: 'active', apy: '6.1%', stake: '—', uptime: '99.93%', you: false },
  ];
  const submit = () => {
    if (!amount) { notify({ tone: 'warn', title: 'Enter an amount', message: `Specify how much ZPH to ${mode}.` }); return; }
    notify({ tone: 'success', title: mode === 'stake' ? 'Stake submitted' : 'Unstake requested', message: mode === 'stake' ? `Staking ${amount} ZPH. Rewards begin next epoch.` : `Unstaking ${amount} ZPH. Available after the cooldown.` });
    setAmount('');
  };
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16 }} className="zy-grid4">
        <StatTile label="Total Staked" value="28,000" sub="ZPH" icon="coins" change="61% of holdings" up />
        <StatTile label="Rewards Earned" value="1,842" sub="ZPH all-time" icon="gift" change="+182 / epoch" up spark={[120,140,150,165,172,182]} />
        <StatTile label="Avg APY" value="6.0%" sub="across 3 validators" icon="percent" change="+0.2%" up />
        <StatTile label="Next Reward" value="~14h" sub="epoch 642" icon="clock" />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.6fr', gap: 24 }} className="zy-grid-main">
        <Panel style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'flex', gap: 4, background: 'var(--surface-tint)', borderRadius: 9, padding: 3 }}>
            {['stake', 'unstake'].map((m) => (
              <button key={m} onClick={() => setMode(m)} style={{
                flex: 1, border: 'none', cursor: 'pointer', padding: '9px 0', borderRadius: 7, fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, textTransform: 'capitalize',
                background: mode === m ? 'var(--surface-card)' : 'transparent', color: mode === m ? 'var(--color-primary)' : 'var(--text-muted)', boxShadow: mode === m ? 'var(--shadow-xs)' : 'none',
              }}>{m}</button>
            ))}
          </div>
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--text-muted)', marginBottom: 6 }}>
              <span>Amount</span><span>Available: {mode === 'stake' ? '17,500' : '28,000'} ZPH</span>
            </div>
            <div style={{ position: 'relative' }}>
              <input value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ''))} placeholder="0.00" inputMode="decimal" style={{ ...inp(), paddingRight: 60 }} />
              <button onClick={() => setAmount(mode === 'stake' ? '17500' : '28000')} style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', background: 'var(--color-primary-tint)', color: 'var(--color-primary)', border: 'none', borderRadius: 6, padding: '4px 8px', fontSize: 11, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-sans)' }}>MAX</button>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: 13, color: 'var(--text-body)' }}>
            <Row k="Est. APY" v="6.2%" />
            <Row k="Est. yearly reward" v={amount ? `${(parseFloat(amount) * 0.062).toFixed(0)} ZPH` : '—'} />
            <Row k={mode === 'stake' ? 'Activation' : 'Cooldown'} v={mode === 'stake' ? 'Next epoch (~14h)' : '~2.5 days'} />
          </div>
          <AB onClick={submit} style={{ width: '100%', textTransform: 'capitalize' }}>{mode} ZPH</AB>
        </Panel>
        <Panel pad={0}>
          <div style={{ padding: '20px 24px 4px' }}><SectionTitle action={<span style={{ fontSize: 12, color: 'var(--text-muted)' }}>5 validators</span>}>Validators</SectionTitle></div>
          <DataTable
            columns={[
              { key: 'name', label: 'Validator', render: (r) => <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }}><span style={{ width: 28, height: 28, borderRadius: 7, background: 'var(--surface-tint)', color: 'var(--color-primary)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontSize: 13 }}>{r.name[0]}</span><span style={{ color: 'var(--text-strong)', fontWeight: 500 }}>{r.name}</span>{r.you && <ABadge tone="done">Staked</ABadge>}</span> },
              { key: 'apy', label: 'APY', render: (r) => <span style={{ color: 'var(--teal)', fontWeight: 600 }}>{r.apy}</span> },
              { key: 'stake', label: 'Your Stake', render: (r) => <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-body)' }}>{r.stake}</span> },
              { key: 'uptime', label: 'Uptime', render: (r) => <span style={{ color: 'var(--text-muted)' }}>{r.uptime}</span> },
              { key: 'act', label: '', align: 'right', render: (r) => <AB size="sm" variant={r.you ? 'ghost' : 'secondary'} onClick={() => notify({ tone: 'info', title: `${r.name}`, message: r.you ? 'Manage your stake with this validator.' : `Open a stake with ${r.name}.` })}>{r.you ? 'Manage' : 'Stake'}</AB> },
            ]}
            rows={validators}
          />
        </Panel>
      </div>
      <Panel>
        <SectionTitle action={<span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Last 12 epochs</span>}>Rewards History</SectionTitle>
        <AreaChart data={[120, 132, 128, 140, 145, 150, 148, 160, 165, 172, 176, 182]} height={170} />
      </Panel>
    </div>
  );
}

function Row({ k, v }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
      <span style={{ color: 'var(--text-muted)' }}>{k}</span>
      <span style={{ color: 'var(--text-strong)', fontWeight: 500 }}>{v}</span>
    </div>
  );
}

/* ---------- GOVERNANCE ---------- */
function Governance({ notify }) {
  const [props, setProps] = React.useState([
    { id: 'ZIP-016', title: 'Add HRSA workforce dataset to ingestion pipeline', desc: 'Extend federal data coverage to include HRSA health workforce shortage data for richer provider context.', status: 'voting', forV: 41200000, against: 8600000, quorum: 60000000, ends: '2d 6h', voted: null },
    { id: 'ZIP-015', title: 'Reduce base query fee from 1.2 to 1.0 ZPH', desc: 'Lower the per-query fee to improve accessibility for smaller clearinghouses while maintaining validator incentives.', status: 'voting', forV: 52000000, against: 14000000, quorum: 60000000, ends: '5d 1h', voted: null },
  ]);
  const past = [
    { id: 'ZIP-014', title: 'Treasury allocation for Q3 pilot partnerships', status: 'passed', result: '82% For' },
    { id: 'ZIP-013', title: 'Onboard Triton One as a verified validator', status: 'passed', result: '91% For' },
    { id: 'ZIP-012', title: 'Increase governance lock multiplier to 1.5×', status: 'rejected', result: '38% For' },
  ];
  const vote = (id, dir) => {
    setProps((cur) => cur.map((p) => {
      if (p.id !== id || p.voted) return p;
      return { ...p, voted: dir, [dir === 'for' ? 'forV' : 'against']: p[dir === 'for' ? 'forV' : 'against'] + 5000000 };
    }));
    notify({ tone: 'success', title: `Vote cast on ${id}`, message: `You voted ${dir === 'for' ? 'For' : 'Against'} with 5,000,000 ZPH voting power.` });
  };
  const fmt = (n) => (n / 1e6).toFixed(1) + 'M';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 }} className="zy-grid3">
        <StatTile label="Voting Power" value="5.0M" sub="ZPH (incl. staked)" icon="gavel" />
        <StatTile label="Active Proposals" value="2" sub="open for voting" icon="vote" />
        <StatTile label="Participation" value="68%" sub="your voting rate" icon="users" change="+5%" up />
      </div>
      <div>
        <SectionTitle>Active Proposals</SectionTitle>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {props.map((p) => {
            const total = p.forV + p.against;
            const forPct = Math.round((p.forV / total) * 100);
            const quorumPct = Math.min(100, Math.round((total / p.quorum) * 100));
            return (
              <Panel key={p.id}>
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, marginBottom: 14 }}>
                  <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--color-primary)', background: 'var(--color-primary-tint)', padding: '4px 8px', borderRadius: 6, flexShrink: 0 }}>{p.id}</span>
                    <div>
                      <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-strong)', marginBottom: 4 }}>{p.title}</div>
                      <div style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.55, maxWidth: 620 }}>{p.desc}</div>
                    </div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6, flexShrink: 0 }}>
                    <StatusPill status={p.status} />
                    <span style={{ fontSize: 12, color: 'var(--text-muted)', display: 'inline-flex', alignItems: 'center', gap: 4 }}><Icon name="clock" size={12} /> {p.ends} left</span>
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 6 }}>
                  <span style={{ color: 'var(--teal)', fontWeight: 600 }}>For · {fmt(p.forV)} ({forPct}%)</span>
                  <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>Against · {fmt(p.against)} ({100 - forPct}%)</span>
                </div>
                <VoteBar value={forPct} max={100} />
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 14, gap: 16, flexWrap: 'wrap' }}>
                  <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Quorum {quorumPct}% of {fmt(p.quorum)} ZPH</span>
                  {p.voted ? (
                    <span style={{ fontSize: 13, color: 'var(--teal)', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 6 }}><Icon name="check-circle-2" size={15} /> You voted {p.voted === 'for' ? 'For' : 'Against'}</span>
                  ) : (
                    <div style={{ display: 'flex', gap: 8 }}>
                      <AB size="sm" onClick={() => vote(p.id, 'for')}>Vote For</AB>
                      <AB size="sm" variant="secondary" onClick={() => vote(p.id, 'against')}>Vote Against</AB>
                    </div>
                  )}
                </div>
              </Panel>
            );
          })}
        </div>
      </div>
      <Panel pad={0}>
        <div style={{ padding: '20px 24px 4px' }}><SectionTitle>Past Proposals</SectionTitle></div>
        <DataTable
          columns={[
            { key: 'id', label: 'ID', render: (r) => <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{r.id}</span> },
            { key: 'title', label: 'Proposal', wrap: true, render: (r) => <span style={{ color: 'var(--text-strong)', fontWeight: 500 }}>{r.title}</span> },
            { key: 'result', label: 'Result', render: (r) => <span style={{ color: 'var(--text-body)' }}>{r.result}</span> },
            { key: 'status', label: 'Status', align: 'right', render: (r) => <StatusPill status={r.status} /> },
          ]}
          rows={past}
        />
      </Panel>
    </div>
  );
}

Object.assign(window, { Staking, Governance, Row });

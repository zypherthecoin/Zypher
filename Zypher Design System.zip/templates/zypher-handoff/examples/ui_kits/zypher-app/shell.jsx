/* Zypher Holder Dashboard — app shell (sidebar, topbar, theme, primitives).
   Composes design-system components from window.ZypherDesignSystem_7d1dbd. */
const ZDS = window.ZypherDesignSystem_7d1dbd;
const { Button, Badge, WalletButton } = ZDS;

/* ---- Lucide icon helper ---- */
function Icon({ name, size = 18, color = 'currentColor', strokeWidth = 1.75, style }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = '';
      const i = document.createElement('i');
      i.setAttribute('data-lucide', name);
      ref.current.appendChild(i);
      window.lucide.createIcons({ attrs: { width: size, height: size, stroke: color, 'stroke-width': strokeWidth } });
    }
  }, [name, size, color, strokeWidth]);
  return <span ref={ref} style={{ display: 'inline-flex', lineHeight: 0, ...style }} />;
}

/* ---- Panel: the app's base surface (themed) ---- */
function Panel({ children, style, pad = 24, ...rest }) {
  return (
    <div style={{ background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 16, padding: pad, ...style }} {...rest}>
      {children}
    </div>
  );
}

/* ---- Section label ---- */
function Eyebrow({ children, style }) {
  return <div style={{ font: 'var(--type-eyebrow)', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)', ...style }}>{children}</div>;
}

/* ---- Themed icon well ---- */
function IconWell({ name, tone = 'teal', size = 38 }) {
  const bg = tone === 'teal' ? 'var(--color-primary-tint)' : 'var(--surface-tint)';
  return (
    <span style={{ width: size, height: size, borderRadius: 10, background: bg, color: 'var(--color-primary)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
      <Icon name={name} size={Math.round(size * 0.5)} />
    </span>
  );
}

/* ---- Theme toggle ---- */
function ThemeToggle({ theme, onToggle }) {
  return (
    <button onClick={onToggle} aria-label="Toggle theme" style={{
      width: 38, height: 38, borderRadius: 10, border: '1px solid var(--border-default)', background: 'var(--surface-card)',
      color: 'var(--text-body)', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <Icon name={theme === 'dark' ? 'sun' : 'moon'} size={18} />
    </button>
  );
}

/* ---- Sidebar ---- */
const NAV = [
  { id: 'overview', label: 'Overview', icon: 'layout-dashboard' },
  { id: 'wallet', label: 'Wallet', icon: 'wallet' },
  { id: 'staking', label: 'Staking', icon: 'coins' },
  { id: 'governance', label: 'Governance', icon: 'vote' },
  { id: 'providers', label: 'Providers', icon: 'shield-check' },
  { id: 'settings', label: 'Settings', icon: 'settings' },
];

function Sidebar({ active, onNav }) {
  return (
    <aside style={{
      width: 240, flexShrink: 0, background: 'var(--surface-sidebar)', borderRight: '1px solid var(--border-default)',
      display: 'flex', flexDirection: 'column', padding: '20px 16px', position: 'sticky', top: 0, height: '100vh',
    }} className="zy-sidebar">
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 8px 22px' }}>
        <span style={{ width: 34, height: 34, background: 'var(--teal)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: 'var(--font-display)', fontSize: 17, letterSpacing: '-0.5px' }}>Z</span>
        <span style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-strong)', letterSpacing: '-0.3px' }}>Zypher</span>
        <span style={{ fontSize: 11, color: 'var(--color-primary)', background: 'var(--color-primary-tint)', padding: '2px 7px', borderRadius: 4, fontWeight: 500 }}>ZPH</span>
      </div>
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV.map((n) => {
          const on = active === n.id;
          return (
            <button key={n.id} onClick={() => onNav(n.id)} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', borderRadius: 9, border: 'none', cursor: 'pointer',
              background: on ? 'var(--color-primary-tint)' : 'transparent', color: on ? 'var(--color-primary)' : 'var(--text-body)',
              fontFamily: 'var(--font-sans)', fontSize: 14, fontWeight: on ? 600 : 500, textAlign: 'left', transition: 'background var(--dur-fast)',
            }}
            onMouseEnter={(e) => { if (!on) e.currentTarget.style.background = 'var(--surface-tint)'; }}
            onMouseLeave={(e) => { if (!on) e.currentTarget.style.background = 'transparent'; }}>
              <Icon name={n.icon} size={18} strokeWidth={on ? 2 : 1.75} />
              {n.label}
            </button>
          );
        })}
      </nav>
      <div style={{ marginTop: 'auto' }}>
        <div style={{ background: 'var(--surface-tint)', borderRadius: 12, padding: 16 }}>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 6 }}>Network</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--text-strong)', fontWeight: 500 }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--teal-mid)' }} className="zy-pulse" />
            Solana Mainnet
          </div>
        </div>
      </div>
    </aside>
  );
}

/* ---- Topbar ---- */
function Topbar({ title, subtitle, theme, onToggleTheme, onNotify }) {
  return (
    <header style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16,
      padding: '20px 32px', borderBottom: '1px solid var(--border-default)', background: 'var(--surface-page)',
      position: 'sticky', top: 0, zIndex: 20,
    }}>
      <div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 26, color: 'var(--text-strong)', margin: 0, fontWeight: 400, letterSpacing: '-0.5px' }}>{title}</h1>
        {subtitle && <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 2 }}>{subtitle}</div>}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 10, padding: '8px 12px', color: 'var(--text-muted)', fontSize: 13, minWidth: 200 }} className="zy-search">
          <Icon name="search" size={16} />
          <span>Search providers, txns…</span>
        </div>
        <button onClick={onNotify} aria-label="Notifications" style={{ width: 38, height: 38, borderRadius: 10, border: '1px solid var(--border-default)', background: 'var(--surface-card)', color: 'var(--text-body)', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
          <Icon name="bell" size={18} />
          <span style={{ position: 'absolute', top: 9, right: 10, width: 7, height: 7, borderRadius: '50%', background: 'var(--teal-mid)', border: '2px solid var(--surface-card)' }} />
        </button>
        <ThemeToggle theme={theme} onToggle={onToggleTheme} />
        <WalletButton connected address="8sG1MjujqWKNZKkkGQQdekuMTLJvFdP3hoohyEiUr82t" balance="12,500 ZPH" />
      </div>
    </header>
  );
}

Object.assign(window, { Icon, Panel, Eyebrow, IconWell, ThemeToggle, Sidebar, Topbar, NAV });

/* Zypher Holder Dashboard — shared screen helpers + Overview + Wallet. */
const { Button: AppButton, Badge: AppBadge, MintAddress } = window.ZypherDesignSystem_7d1dbd;

/* ---------- shared bits ---------- */
function StatTile({ label, value, sub, change, up = true, spark, icon }) {
  return (
    <Panel pad={20} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Eyebrow>{label}</Eyebrow>
        {icon && <IconWell name={icon} size={32} />}
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 30, color: 'var(--text-strong)', lineHeight: 1 }}>{value}</div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {change != null && (
            <span style={{ fontSize: 12, fontWeight: 600, color: up ? 'var(--teal)' : '#DC2626', display: 'inline-flex', alignItems: 'center', gap: 2 }}>
              <Icon name={up ? 'trending-up' : 'trending-down'} size={13} /> {change}
            </span>
          )}
          {sub && <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{sub}</span>}
        </div>
        {spark && <Sparkline data={spark} up={up} />}
      </div>
    </Panel>
  );
}

function StatusPill({ status }) {
  const map = {
    confirmed: ['done', 'Confirmed'], anchored: ['done', 'Anchored'], active: ['done', 'Active'],
    pending: ['active', 'Pending'], voting: ['active', 'Voting'], passed: ['done', 'Passed'],
    rejected: ['future', 'Rejected'], failed: ['future', 'Failed'], stale: ['future', 'Re-verify'],
  };
  const [tone, label] = map[status] || ['future', status];
  return <AppBadge tone={tone}>{label}</AppBadge>;
}

function DataTable({ columns, rows, onRowClick }) {
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} style={{ textAlign: c.align || 'left', padding: '10px 14px', font: 'var(--type-eyebrow)', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)', borderBottom: '1px solid var(--border-default)', whiteSpace: 'nowrap' }}>{c.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} onClick={onRowClick ? () => onRowClick(r) : undefined}
              style={{ cursor: onRowClick ? 'pointer' : 'default', transition: 'background var(--dur-fast)' }}
              onMouseEnter={(e) => onRowClick && (e.currentTarget.style.background = 'var(--surface-tint)')}
              onMouseLeave={(e) => onRowClick && (e.currentTarget.style.background = 'transparent')}>
              {columns.map((c) => (
                <td key={c.key} style={{ textAlign: c.align || 'left', padding: '13px 14px', color: 'var(--text-body)', borderBottom: i < rows.length - 1 ? '1px solid var(--border-default)' : 'none', whiteSpace: c.wrap ? 'normal' : 'nowrap' }}>
                  {c.render ? c.render(r) : r[c.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function TxIcon({ type }) {
  const m = { send: 'arrow-up-right', receive: 'arrow-down-left', stake: 'coins', reward: 'gift', query: 'search', vote: 'vote' };
  return <span style={{ width: 30, height: 30, borderRadius: 8, background: 'var(--surface-tint)', color: 'var(--color-primary)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name={m[type] || 'circle'} size={15} /></span>;
}

function SectionTitle({ children, action }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 20, color: 'var(--text-strong)', margin: 0, fontWeight: 400 }}>{children}</h2>
      {action}
    </div>
  );
}

/* timeframe pills */
function Timeframe({ value, onChange }) {
  const opts = ['24H', '7D', '30D', '1Y'];
  return (
    <div style={{ display: 'flex', gap: 4, background: 'var(--surface-tint)', borderRadius: 8, padding: 3 }}>
      {opts.map((o) => (
        <button key={o} onClick={() => onChange(o)} style={{
          border: 'none', cursor: 'pointer', padding: '5px 12px', borderRadius: 6, fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 600,
          background: value === o ? 'var(--surface-card)' : 'transparent', color: value === o ? 'var(--color-primary)' : 'var(--text-muted)',
          boxShadow: value === o ? 'var(--shadow-xs)' : 'none',
        }}>{o}</button>
      ))}
    </div>
  );
}

/* ---------- OVERVIEW ---------- */
const SERIES = {
  '24H': [41, 41.4, 40.9, 41.8, 42.6, 42.1, 43, 43.8, 43.4, 44.2, 45.1, 44.8],
  '7D': [38, 39.5, 39, 41, 42.5, 41.8, 44.8],
  '30D': [31, 33, 32, 35, 34, 37, 39, 38, 41, 40, 43, 44.8],
  '1Y': [12, 16, 14, 19, 24, 22, 28, 31, 29, 36, 41, 44.8],
};

function Overview({ onNav }) {
  const [tf, setTf] = React.useState('30D');
  const alloc = [
    { label: 'Liquid', value: 12500, color: 'var(--teal)' },
    { label: 'Staked', value: 28000, color: 'var(--navy-mid)' },
    { label: 'Gov-locked', value: 5000, color: 'var(--teal-bright)' },
  ];
  const activity = [
    { type: 'reward', detail: 'Staking reward', amount: '+182.4 ZPH', status: 'confirmed', time: '2m ago', pos: true },
    { type: 'query', detail: 'Provider query fee', amount: '-1.20 ZPH', status: 'confirmed', time: '1h ago' },
    { type: 'vote', detail: 'Voted on ZIP-014', amount: '5,000 ZPH', status: 'confirmed', time: '3h ago' },
    { type: 'receive', detail: 'From 9aB2…3f12', amount: '+2,400 ZPH', status: 'confirmed', time: 'Yesterday', pos: true },
    { type: 'stake', detail: 'Staked to Helius', amount: '-8,000 ZPH', status: 'confirmed', time: '2d ago' },
  ];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16 }} className="zy-grid4">
        <StatTile label="Portfolio Value" value="$44,820" change="+8.4%" up sub="30d" icon="wallet" spark={SERIES['30D']} />
        <StatTile label="ZPH Balance" value="45,500" change="+2,400" up sub="ZPH" icon="circle-dollar-sign" spark={SERIES['7D']} />
        <StatTile label="Staked" value="28,000" change="6.2% APY" up sub="ZPH" icon="coins" spark={[20,22,24,25,27,28]} />
        <StatTile label="Query Fees (30d)" value="142.6" change="-12%" up={false} sub="ZPH spent" icon="search" spark={[8,6,7,5,4,5,3]} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1.7fr 1fr', gap: 24 }} className="zy-grid-main">
        <Panel>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
            <div>
              <Eyebrow>Portfolio Value</Eyebrow>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 32, color: 'var(--text-strong)', lineHeight: 1.2 }}>$44,820.18</div>
            </div>
            <Timeframe value={tf} onChange={setTf} />
          </div>
          <AreaChart data={SERIES[tf]} height={230} />
        </Panel>
        <Panel style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <Eyebrow>Allocation</Eyebrow>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <Donut segments={alloc} centerLabel="45.5K" centerSub="Total ZPH" />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, flex: 1 }}>
              {alloc.map((a) => (
                <div key={a.label} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                  <span style={{ width: 10, height: 10, borderRadius: 3, background: a.color }} />
                  <span style={{ color: 'var(--text-body)', flex: 1 }}>{a.label}</span>
                  <span style={{ color: 'var(--text-strong)', fontWeight: 600 }}>{a.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
            <AppButton size="sm" onClick={() => onNav('wallet')} leadingIcon={<Icon name="arrow-up-right" size={15} />}>Send</AppButton>
            <AppButton size="sm" variant="secondary" onClick={() => onNav('staking')} leadingIcon={<Icon name="coins" size={15} />}>Stake</AppButton>
            <AppButton size="sm" variant="secondary" onClick={() => onNav('governance')} leadingIcon={<Icon name="vote" size={15} />}>Vote</AppButton>
          </div>
        </Panel>
      </div>
      <Panel pad={0}>
        <div style={{ padding: '20px 24px 4px' }}><SectionTitle action={<AppButton size="sm" variant="ghost" onClick={() => onNav('wallet')}>View all →</AppButton>}>Recent Activity</SectionTitle></div>
        <DataTable
          columns={[
            { key: 'detail', label: 'Activity', render: (r) => <span style={{ display: 'inline-flex', alignItems: 'center', gap: 12 }}><TxIcon type={r.type} /><span style={{ color: 'var(--text-strong)', fontWeight: 500 }}>{r.detail}</span></span> },
            { key: 'amount', label: 'Amount', render: (r) => <span style={{ fontFamily: 'var(--font-mono)', color: r.pos ? 'var(--teal)' : 'var(--text-strong)' }}>{r.amount}</span> },
            { key: 'status', label: 'Status', render: (r) => <StatusPill status={r.status} /> },
            { key: 'time', label: 'Time', align: 'right', render: (r) => <span style={{ color: 'var(--text-muted)' }}>{r.time}</span> },
          ]}
          rows={activity}
        />
      </Panel>
    </div>
  );
}

/* ---------- WALLET ---------- */
function Wallet({ notify }) {
  const [amount, setAmount] = React.useState('');
  const [to, setTo] = React.useState('');
  const txns = [
    { type: 'reward', detail: 'Staking reward · Helius', amount: '+182.4 ZPH', status: 'confirmed', time: '2m ago', pos: true },
    { type: 'query', detail: 'Provider query · NPI 1487…', amount: '-1.20 ZPH', status: 'confirmed', time: '1h ago' },
    { type: 'receive', detail: 'From 9aB2…3f12', amount: '+2,400 ZPH', status: 'confirmed', time: 'Yesterday', pos: true },
    { type: 'send', detail: 'To 4Kp9…a7d1', amount: '-500 ZPH', status: 'confirmed', time: '2d ago' },
    { type: 'stake', detail: 'Staked to Helius', amount: '-8,000 ZPH', status: 'confirmed', time: '2d ago' },
    { type: 'query', detail: 'Provider query · NPI 1992…', amount: '-1.20 ZPH', status: 'confirmed', time: '3d ago' },
  ];
  const send = () => {
    if (!amount) { notify({ tone: 'warn', title: 'Enter an amount', message: 'Specify how much ZPH to send.' }); return; }
    notify({ tone: 'success', title: 'Transaction submitted', message: `Sending ${amount} ZPH${to ? ' to ' + to.slice(0, 6) + '…' : ''}. Awaiting confirmation.` });
    setAmount(''); setTo('');
  };
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 24 }} className="zy-grid-main">
        <Panel style={{ background: 'var(--navy)', border: 'none', color: '#fff', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minHeight: 200, position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', right: -30, top: -50, fontFamily: 'var(--font-display)', fontSize: 180, color: 'rgba(255,255,255,0.03)', lineHeight: 1 }}>Z</div>
          <div style={{ position: 'relative' }}>
            <div style={{ font: 'var(--type-eyebrow)', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--teal-mid)', marginBottom: 10 }}>Total Balance</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 44, lineHeight: 1 }}>45,500 <span style={{ fontSize: 24, color: 'rgba(255,255,255,0.6)' }}>ZPH</span></div>
            <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.55)', marginTop: 8 }}>≈ $44,820.18 USD</div>
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 24, position: 'relative' }}>
            <AppButton onClick={() => document.getElementById('zy-send')?.scrollIntoView({ block: 'nearest' })} leadingIcon={<Icon name="arrow-up-right" size={16} color="#fff" />}>Send</AppButton>
            <AppButton variant="dark" onClick={() => notify({ tone: 'info', title: 'Receive ZPH', message: 'Your wallet address has been copied.' })} leadingIcon={<Icon name="arrow-down-left" size={16} />}>Receive</AppButton>
          </div>
        </Panel>
        <Panel id="zy-send" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <SectionTitle>Send ZPH</SectionTitle>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-body)' }}>Recipient</span>
            <input value={to} onChange={(e) => setTo(e.target.value)} placeholder="Solana address" style={inp()} />
          </label>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-body)' }}>Amount (ZPH)</span>
            <input value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ''))} placeholder="0.00" inputMode="decimal" style={inp()} />
          </label>
          <AppButton onClick={send} style={{ width: '100%', marginTop: 4 }}>Send ZPH</AppButton>
        </Panel>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }} className="zy-grid2">
        <Panel>
          <SectionTitle>Query-Fee Usage</SectionTitle>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, color: 'var(--text-strong)' }}>142.6 ZPH</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>spent this month · 118 queries</div>
            </div>
            <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--teal)' }}>−12% vs last</span>
          </div>
          <BarMini data={[14, 11, 18, 9, 22, 16, 13, 19, 24, 12, 17, 21]} height={72} />
        </Panel>
        <Panel style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <SectionTitle>ZPH Token</SectionTitle>
          <MintAddress address="8sG1MjujqWKNZKkkGQQdekuMTLJvFdP3hoohyEiUr82t" label="Mint Address" />
          <div style={{ display: 'flex', gap: 24, fontSize: 13, color: 'var(--text-muted)' }}>
            <span>Network: <b style={{ color: 'var(--text-strong)' }}>Solana</b></span>
            <span>Decimals: <b style={{ color: 'var(--text-strong)' }}>9</b></span>
            <span>Standard: <b style={{ color: 'var(--text-strong)' }}>SPL</b></span>
          </div>
        </Panel>
      </div>
      <Panel pad={0}>
        <div style={{ padding: '20px 24px 4px' }}><SectionTitle>Transaction History</SectionTitle></div>
        <DataTable
          columns={[
            { key: 'detail', label: 'Transaction', render: (r) => <span style={{ display: 'inline-flex', alignItems: 'center', gap: 12 }}><TxIcon type={r.type} /><span style={{ color: 'var(--text-strong)', fontWeight: 500 }}>{r.detail}</span></span> },
            { key: 'amount', label: 'Amount', render: (r) => <span style={{ fontFamily: 'var(--font-mono)', color: r.pos ? 'var(--teal)' : 'var(--text-strong)' }}>{r.amount}</span> },
            { key: 'status', label: 'Status', render: (r) => <StatusPill status={r.status} /> },
            { key: 'time', label: 'Time', align: 'right', render: (r) => <span style={{ color: 'var(--text-muted)' }}>{r.time}</span> },
          ]}
          rows={txns}
        />
      </Panel>
    </div>
  );
}

function inp() {
  return {
    border: '1px solid var(--border-default)', background: 'var(--surface-page)', borderRadius: 8, padding: '11px 14px',
    fontFamily: 'var(--font-sans)', fontSize: 14, color: 'var(--text-strong)', outline: 'none', width: '100%', boxSizing: 'border-box',
  };
}

Object.assign(window, { StatTile, StatusPill, DataTable, TxIcon, SectionTitle, Timeframe, Overview, Wallet, inp });

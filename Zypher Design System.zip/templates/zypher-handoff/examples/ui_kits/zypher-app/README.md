# Zypher App — UI Kit (ZPH Holder Dashboard)

A fully click-through **ZPH Holder Dashboard** for crypto-native users — wallet, staking, governance, the verified provider registry, and settings. Light/dark themed.

> **Net-new, extrapolated design.** The Zypher source repo contains only the marketing site — there is no app/dashboard. This kit is an *original* product surface built on the Zypher design foundations (tokens, components, voice), not a recreation of an existing screen.

## Files
- `index.html` — loads the bundle + scripts in order and renders `<ZypherApp />`. Tagged as a Starting Point.
- `charts.jsx` — dependency-free SVG charts: `AreaChart`, `Sparkline`, `Donut`, `VoteBar`, `BarMini`.
- `shell.jsx` — `Sidebar`, `Topbar`, `ThemeToggle`, `Panel`, `Icon` (Lucide), `IconWell`, `Eyebrow`.
- `screens-a.jsx` — shared helpers (`StatTile`, `DataTable`, `StatusPill`, `Timeframe`) + **Overview** + **Wallet**.
- `screens-b.jsx` — **Staking** + **Governance**.
- `screens-c.jsx` — **Providers** (list) + **ProviderDetail** (audit trail) + **Settings**.
- `app.jsx` — root: sidebar routing, theme state (persisted), toast queue.

## Screens
1. **Overview** — portfolio value area chart w/ timeframe, allocation donut, stat tiles, recent activity.
2. **Wallet** — balance hero, send/receive (send triggers a toast), query-fee usage bars, ZPH mint address, transaction history.
3. **Staking** — stat tiles, stake/unstake panel (MAX, live yield estimate), validator table, rewards history.
4. **Governance** — voting power, active proposals with **live For/Against voting** (click to cast), past proposals.
5. **Providers** — searchable registry table → **Provider Detail** with on-chain anchoring + audit-trail timeline.
6. **Settings** — account, connected wallets, **theme picker**, notification switches.

## Design-system usage
Composes `Button`, `Badge`, `WalletButton`, `MintAddress`, `ToastViewport` from the bundle. Charts and the app shell are kit-specific. All surfaces use semantic tokens (`--surface-*`, `--text-*`, `--border-*`) so the **light/dark toggle** works automatically via the system's `[data-theme="dark"]` scope.

## Interactivity
Sidebar navigation, theme toggle (persisted to `localStorage`), governance voting, stake/unstake + send forms (faked, with toast feedback), provider search and drill-in. Icons: **Lucide**.

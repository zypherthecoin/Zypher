/* Zypher site UI kit — section components.
   Composes design-system primitives from window.ZypherDesignSystem_7d1dbd.
   Icons: Lucide (the system's standard) in place of the original site's emoji. */
const { Button, Badge, Card, StatCard, MintAddress, SectionHeading, Callout, Accordion, Stepper, WalletButton } = window.ZypherDesignSystem_7d1dbd;
const MINT = '8sG1MjujqWKNZKkkGQQdekuMTLJvFdP3hoohyEiUr82t';

function Icon({ name, size = 22, color = 'currentColor' }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = '';
      const el = document.createElement('i');
      el.setAttribute('data-lucide', name);
      ref.current.appendChild(el);
      window.lucide.createIcons({ attrs: { width: size, height: size, stroke: color } });
    }
  }, [name, size, color]);
  return <span ref={ref} style={{ display: 'inline-flex' }} />;
}

const wrap = { maxWidth: 'var(--content-max)', margin: '0 auto', padding: '0 2rem' };

/* ---------------- NAV ---------------- */
function Nav() {
  const links = ['About', 'Tokenomics', 'Roadmap', 'zCARE', 'FAQ'];
  return (
    <nav style={{
      position: 'sticky', top: 0, zIndex: 100, background: 'rgba(255,255,255,0.95)',
      backdropFilter: 'blur(12px)', borderBottom: '1px solid var(--border)', height: 64,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 2rem',
    }}>
      <a href="#top" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
        <span style={{ width: 36, height: 36, background: 'var(--teal)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: 'var(--font-display)', fontSize: 18, letterSpacing: '-0.5px' }}>Z</span>
        <span style={{ fontSize: 17, fontWeight: 600, color: 'var(--navy)', letterSpacing: '-0.3px' }}>Zypher</span>
        <span style={{ fontSize: 12, color: 'var(--teal-mid)', background: 'var(--teal-light)', padding: '2px 7px', borderRadius: 4 }}>ZPH</span>
      </a>
      <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
        <ul style={{ display: 'flex', gap: '2rem', listStyle: 'none', margin: 0, padding: 0 }} className="zy-navlinks">
          {links.map((l) => (
            <li key={l}><a href={'#' + l.toLowerCase()} style={{ textDecoration: 'none', color: 'var(--slate)', fontSize: 14, fontWeight: 500 }}>{l}</a></li>
          ))}
        </ul>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Button size="sm">Buy ZPH</Button>
          <WalletButton size="sm" />
        </div>
      </div>
    </nav>
  );
}

/* ---------------- HERO ---------------- */
function Hero() {
  const stats = [
    { value: '$80B+', label: 'Uncompensated Care', sub: 'Lost annually in the US' },
    { value: '1B', label: 'ZPH Supply', sub: 'Fixed, minting revoked' },
    { value: "Mar '26", label: 'Token Launch', sub: 'TGE March 17, 2026' },
    { value: 'Solana', label: 'Blockchain', sub: '65K TPS, sub-$0.001 fees' },
  ];
  return (
    <section id="top" style={{ ...wrap, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, alignItems: 'center', padding: '96px 2rem 80px' }} className="zy-hero">
      <div>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'var(--teal-light)', color: 'var(--teal)', font: 'var(--type-eyebrow)', letterSpacing: '0.08em', textTransform: 'uppercase', padding: '6px 14px', borderRadius: 20, marginBottom: 24 }}>
          <span className="zy-pulse" style={{ width: 6, height: 6, background: 'var(--teal-mid)', borderRadius: '50%' }} /> Live on Solana
        </span>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 52, lineHeight: 1.1, color: 'var(--navy)', letterSpacing: '-1px', margin: '0 0 24px', fontWeight: 400 }}>
          Healthcare payments need a <em style={{ fontStyle: 'italic', color: 'var(--teal)' }}>data layer.</em>
        </h1>
        <p style={{ fontSize: 17, color: 'var(--slate)', lineHeight: 1.75, fontWeight: 300, margin: '0 0 36px' }}>
          Zypher (ZPH) is building verified, on-chain provider infrastructure connected to federal data pipelines — designed to solve the $80B+ uncompensated care crisis in American healthcare.
        </p>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <Button trailingIcon="↗">Buy ZPH on Jupiter</Button>
          <Button variant="secondary">Read Whitepaper</Button>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1, background: 'var(--border)', borderRadius: 16, overflow: 'hidden', border: '1px solid var(--border)' }}>
        {stats.map((s) => <StatCard key={s.label} {...s} />)}
      </div>
    </section>
  );
}

/* ---------------- TICKER ---------------- */
function Ticker() {
  const items = [
    'ZPH · SOLANA · HEALTHCARE INFRASTRUCTURE',
    'MINT AUTHORITY REVOKED · FREEZE AUTHORITY REVOKED',
    'LISTED ON JUPITER · RAYDIUM · DEXSCREENER',
    'PHASE 2: zCARE STABLE PAYMENT TOKEN · COMING SOON',
  ];
  const seq = [...items, ...items];
  return (
    <div style={{ background: 'var(--navy)', color: '#fff', padding: '12px 0', overflow: 'hidden', whiteSpace: 'nowrap' }}>
      <div className="zy-ticker" style={{ display: 'inline-flex', gap: '3rem', fontSize: 13, fontWeight: 500, letterSpacing: '0.04em', opacity: 0.85 }}>
        {seq.map((t, i) => (
          <span key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 4, height: 4, background: 'var(--teal-mid)', borderRadius: '50%' }} /> {t}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ---------------- PROBLEM ---------------- */
function Problem() {
  const cards = [
    { n: '$80B+', t: 'Uncompensated Care Annually', d: 'U.S. hospitals absorb over $80 billion per year in uncompensated care — services rendered to patients whose claims fail due to data errors and billing fragmentation.' },
    { n: '~50%', t: 'Provider Directory Error Rate', d: 'Studies show provider directory error rates as high as 50% in certain markets. Outdated records cause claims denials that cannot be corrected retroactively.' },
    { n: '0', t: 'Real-Time National Registry', d: 'The federal NPPES registry is batch-updated and siloed. No shared, real-time, composable infrastructure exists to synchronize provider data across payers.' },
  ];
  return (
    <section id="about" style={{ background: 'var(--surface)', padding: '96px 0' }}>
      <div style={wrap}>
        <SectionHeading label="The Problem" title={<>American healthcare loses billions<br/>to a broken data layer.</>} sub="Provider directories are inaccurate. Billing systems are fragmented. No unified, real-time source of provider truth exists — and hospitals pay for it every year." />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 24, marginTop: 56 }} className="zy-3col">
          {cards.map((c) => (
            <Card key={c.t} accent>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 48, color: 'var(--teal)', lineHeight: 1, marginBottom: 12 }}>{c.n}</div>
              <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--navy)', marginBottom: 8 }}>{c.t}</div>
              <div style={{ fontSize: 14, color: 'var(--slate)', lineHeight: 1.65 }}>{c.d}</div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- HOW IT WORKS ---------------- */
function HowItWorks() {
  const steps = [
    { title: 'Federal Data Ingestion', desc: 'NPPES, CMS, and HRSA data pipelines are connected and continuously ingested into the Zypher network.' },
    { title: 'Verification & Hashing', desc: 'Provider records are normalized, validated, and cryptographically hashed using SHA-256.' },
    { title: 'On-Chain Anchoring', desc: 'Verified hashes are anchored to Solana, creating an immutable audit trail linked to each provider NPI.' },
    { title: 'Composable Access', desc: 'Any participant — payer, clearinghouse, or patient — can query verified provider data in real time via ZPH.' },
  ];
  return (
    <section style={{ ...wrap, padding: '96px 2rem' }}>
      <SectionHeading label="The Solution" title={<>On-chain provider infrastructure,<br/>anchored to federal data.</>} sub="Zypher ingests authoritative federal data and anchors it permanently on Solana — creating a composable, verifiable provider registry any participant can query." />
      <div style={{ marginTop: 56 }} className="zy-steps">
        <Stepper orientation="horizontal" steps={steps} />
      </div>
    </section>
  );
}

/* ---------------- TOKENOMICS ---------------- */
function Tokenomics() {
  const specs = [
    ['Token Name', 'Zypher', false], ['Ticker', 'ZPH', true], ['Blockchain', 'Solana (SPL)', false],
    ['Total Supply', '1,000,000,000', true], ['Mint Authority', 'Revoked ✓', 'green'], ['Freeze Authority', 'Revoked ✓', 'green'],
    ['TGE', 'March 17, 2026', false], ['DEX', 'Jupiter / Raydium', false],
  ];
  const utils = [
    { icon: 'search', t: 'Network Query Fees', d: 'Participants querying verified provider records pay fees denominated in ZPH, creating continuous demand as utilization scales.' },
    { icon: 'settings', t: 'Validator Incentives', d: 'Nodes that ingest, verify, and anchor federal data to the chain are compensated in ZPH.' },
    { icon: 'vote', t: 'Governance', d: 'ZPH holders participate in protocol governance — data source additions, fee parameters, and network upgrades.' },
    { icon: 'landmark', t: 'zCARE Collateral', d: 'Phase 2 introduces ZPH as collateral backing the zCARE stable payment token, creating a direct demand sink.' },
  ];
  return (
    <section id="tokenomics" style={{ background: 'var(--surface)', padding: '96px 0' }}>
      <div style={wrap}>
        <SectionHeading label="Tokenomics" title="ZPH — Infrastructure Token" sub="ZPH powers access, governance, and liquidity across the Zypher network. Fixed supply, both authorities permanently revoked." />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'start' }} className="zy-2col">
          <Card dark style={{ borderRadius: 16, padding: 40 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, marginBottom: 28 }}>Token Specifications</div>
            {specs.map(([k, v, hl], i) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: i < specs.length - 1 ? '1px solid rgba(255,255,255,0.08)' : 'none', fontSize: 14 }}>
                <span style={{ color: 'rgba(255,255,255,0.55)' }}>{k}</span>
                <span style={{ fontSize: 13, fontWeight: hl ? 600 : 500, color: hl === 'green' ? '#6EE7B7' : hl ? 'var(--teal-mid)' : '#fff' }}>{v}</span>
              </div>
            ))}
          </Card>
          <div>
            <h3 style={{ fontSize: 20, fontWeight: 600, color: 'var(--navy)', margin: '0 0 20px' }}>ZPH Utility</h3>
            {utils.map((u, i) => (
              <div key={u.t} style={{ display: 'flex', gap: 16, padding: '16px 0', borderBottom: i < utils.length - 1 ? '1px solid var(--border)' : 'none' }}>
                <span style={{ width: 36, height: 36, background: 'var(--teal-light)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: 'var(--teal)' }}><Icon name={u.icon} size={18} /></span>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--navy)', marginBottom: 4 }}>{u.t}</div>
                  <div style={{ fontSize: 13, color: 'var(--slate)', lineHeight: 1.55 }}>{u.d}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ marginTop: 48 }}><MintAddress address={MINT} /></div>
      </div>
    </section>
  );
}

/* ---------------- ROADMAP ---------------- */
function Roadmap() {
  const phases = [
    { tag: 'Underway', tone: 'done', title: 'Phase 1', when: 'Infrastructure Foundation · 2026', items: [
      ['done', 'Token Generation Event (March 17, 2026)'], ['done', 'Raydium liquidity pool deployment'], ['done', 'Jupiter DEX listing'],
      ['done', 'Website & whitepaper publication'], ['active', 'CoinGecko listing'], ['active', 'Community growth & Twitter presence'], ['future', 'NPPES data pipeline proof-of-concept (Q3 2026)'],
    ]},
    { tag: 'Upcoming', tone: 'future', title: 'Phase 2', when: 'Payment Layer · 2026–2027', items: [
      ['future', 'zCARE stable payment token design'], ['future', 'Regulatory framework & compliance scaffolding'], ['future', 'Pilot partnerships with billing clearinghouses'],
      ['future', 'zCARE token generation & liquidity initialization'], ['future', 'Cross-chain bridge exploration'],
    ]},
    { tag: 'Horizon', tone: 'future', title: 'Phase 3', when: 'Scale & Adoption · 2027+', items: [
      ['future', 'National-scale NPPES/CMS data anchoring'], ['future', 'Payer & health system integration partnerships'],
      ['future', 'Expansion to additional federal health data sources'], ['future', 'Governance decentralization & DAO transition'],
    ]},
  ];
  const mark = { done: '✓', active: '→', future: '○' };
  const markStyle = {
    done: { background: 'var(--teal)', color: '#fff' },
    active: { background: 'var(--amber-bg)', color: 'var(--amber-fg)', border: '1px solid #FCD34D' },
    future: { background: '#F1F5F9', color: 'var(--muted)' },
  };
  return (
    <section id="roadmap" style={{ ...wrap, padding: '96px 2rem' }}>
      <SectionHeading label="Roadmap" title={<>Building the infrastructure,<br/>phase by phase.</>} sub="From token launch to national-scale healthcare data infrastructure and the zCARE payment layer." />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 24, marginTop: 56 }} className="zy-3col">
        {phases.map((p) => (
          <div key={p.title} style={{ border: '1px solid var(--border)', borderRadius: 12, overflow: 'hidden' }}>
            <div style={{ padding: '24px 28px 20px', background: 'var(--surface)', borderBottom: '1px solid var(--border)' }}>
              <div style={{ marginBottom: 12 }}><Badge tone={p.tone}>{p.tag}</Badge></div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, color: 'var(--navy)', marginBottom: 4 }}>{p.title}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 500 }}>{p.when}</div>
            </div>
            <div style={{ padding: '20px 28px', background: 'var(--surface)', display: 'flex', flexDirection: 'column', gap: 10 }}>
              {p.items.map(([st, label]) => (
                <div key={label} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, fontSize: 13, color: 'var(--slate)', lineHeight: 1.5 }}>
                  <span style={{ width: 18, height: 18, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1, fontSize: 10, ...markStyle[st] }}>{mark[st]}</span>
                  <span>{label}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------------- ZCARE ---------------- */
function Zcare() {
  return (
    <section id="zcare" style={{ background: 'var(--bg)', padding: '96px 0' }}>
      <div style={wrap}>
        <div style={{ background: 'var(--navy)', borderRadius: 20, padding: 64, display: 'grid', gridTemplateColumns: '1fr auto', gap: 48, alignItems: 'center', position: 'relative', overflow: 'hidden' }} className="zy-zcare">
          <div style={{ position: 'absolute', right: -20, top: -40, fontFamily: 'var(--font-display)', fontSize: 200, color: 'rgba(255,255,255,0.03)', lineHeight: 1, pointerEvents: 'none' }}>zCARE</div>
          <div style={{ position: 'relative' }}>
            <div style={{ font: 'var(--type-eyebrow)', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--teal-mid)', marginBottom: 16 }}>Phase 2 · Coming Soon</div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 40, color: '#fff', lineHeight: 1.15, margin: '0 0 20px', fontWeight: 400 }}>Introducing zCARE —<br/>Healthcare's Payment Token.</h2>
            <p style={{ fontSize: 16, color: 'rgba(255,255,255,0.6)', lineHeight: 1.75, fontWeight: 300, maxWidth: 480, margin: 0 }}>Built on Zypher's verified provider infrastructure, zCARE is a stable payment token designed specifically for healthcare transactions — with HIPAA-compatible structures and clearinghouse integration hooks.</p>
          </div>
          <div style={{ background: 'rgba(29,158,117,0.15)', border: '1px solid rgba(29,158,117,0.3)', borderRadius: 16, padding: '40px 36px', textAlign: 'center', minWidth: 200, position: 'relative' }}>
            <div style={{ fontSize: 11, color: 'var(--teal-mid)', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 12 }}>Phase 2 Token</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 36, color: '#fff', marginBottom: 8 }}>zCARE</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.45)' }}>Stable · Healthcare-native · Composable</div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- FAQ (interactive) ---------------- */
function Faq() {
  const qs = [
    { q: 'What is Zypher (ZPH)?', a: 'Zypher (ZPH) is a Solana-based cryptocurrency project building healthcare payments infrastructure. ZPH powers a system designed to solve the $80B+ uncompensated care crisis through decentralized payment rails connected to real federal data pipelines including NPPES, CMS, and HRSA.' },
    { q: 'Why is Zypher built on Solana?', a: 'Solana processes up to 65,000 transactions per second with sub-second finality and fees averaging less than $0.001 per transaction. For healthcare payment infrastructure at national scale, this throughput and cost profile is essential.' },
    { q: 'Is ZPH supply fixed?', a: 'Yes — ZPH has a hard cap of 1,000,000,000 (1 billion) tokens. Both Mint Authority and Freeze Authority have been permanently revoked, meaning no additional ZPH can ever be created. This is cryptographically enforced and irreversible on-chain.' },
    { q: 'Where can I buy ZPH?', a: 'ZPH is currently available on Jupiter and Raydium, two of Solana\'s leading DEX platforms. Always verify the mint address before trading to ensure you are purchasing the correct token.' },
    { q: 'What is zCARE and when is it launching?', a: 'zCARE is Zypher\'s Phase 2 stable payment token designed specifically for healthcare transactions. It will be built with HIPAA-compatible transaction structures and integration hooks for existing billing clearinghouses.' },
  ];
  return (
    <section id="faq" style={{ ...wrap, padding: '96px 2rem' }}>
      <SectionHeading label="FAQ" title="Frequently asked questions." />
      <div style={{ marginTop: 48 }}>
        <Accordion items={qs} defaultOpen={0} />
      </div>
    </section>
  );
}

/* ---------------- FOOTER ---------------- */
function Footer() {
  const cols = [
    ['Protocol', ['About', 'Tokenomics', 'Roadmap', 'Whitepaper']],
    ['Trade', ['Jupiter', 'Raydium', 'DexScreener', 'CoinGecko']],
    ['Community', ['Twitter / X', 'GitHub', 'Telegram']],
  ];
  return (
    <footer style={{ background: 'var(--navy)', color: 'rgba(255,255,255,0.6)', padding: '64px 2rem 40px' }}>
      <div style={{ maxWidth: 'var(--content-max)', margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 48, paddingBottom: 48, borderBottom: '1px solid rgba(255,255,255,0.08)' }} className="zy-footcols">
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, color: '#fff', marginBottom: 12 }}>Zypher</div>
            <div style={{ fontSize: 14, lineHeight: 1.7, color: 'rgba(255,255,255,0.45)', maxWidth: 280 }}>Healthcare payments infrastructure on Solana. Verified, on-chain provider data anchored to federal pipelines.</div>
          </div>
          {cols.map(([title, items]) => (
            <div key={title}>
              <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', marginBottom: 16 }}>{title}</div>
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 10, margin: 0, padding: 0 }}>
                {items.map((l) => <li key={l}><a href="#" style={{ color: 'rgba(255,255,255,0.55)', textDecoration: 'none', fontSize: 14 }}>{l}</a></li>)}
              </ul>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 32, fontSize: 12, color: 'rgba(255,255,255,0.3)', flexWrap: 'wrap', gap: 12 }}>
          <span>© 2026 Zypher. ZPH is a utility token, not investment advice.</span>
          <span style={{ fontFamily: 'var(--font-mono)' }}>MINT: {MINT.slice(0, 6)}…{MINT.slice(-4)}</span>
        </div>
      </div>
    </footer>
  );
}

function ZypherSite() {
  return (
    <div className="zy">
      <Nav /><Hero /><Ticker /><Problem /><HowItWorks /><Tokenomics /><Roadmap /><Zcare /><Faq /><Footer />
    </div>
  );
}

Object.assign(window, { ZypherSite, Nav, Hero, Ticker, Problem, HowItWorks, Tokenomics, Roadmap, Zcare, Faq, Footer });

# Zypher Site — UI Kit

A faithful, interactive recreation of the **Zypher (ZPH)** marketing landing page — the project's single public product surface.

## Files
- `index.html` — assembles and renders the full page (`<ZypherSite />`). Also tagged as a Starting Point.
- `sections.jsx` — all section components, composing design-system primitives from `window.ZypherDesignSystem_7d1dbd`.

## Sections
`Nav` · `Hero` (with `StatCard` cluster) · `Ticker` (animated marquee) · `Problem` · `HowItWorks` · `Tokenomics` (specs panel + utility list + `MintAddress`) · `Roadmap` (3 phases w/ `Badge` states) · `Zcare` banner · `Faq` (interactive accordion) · `Footer`.

## Components used
`Button`, `Card`, `StatCard`, `Badge`, `MintAddress`, `SectionHeading` — all from the Zypher design system bundle.

## Notes
- Icons use **Lucide** (the system standard) in place of the original site's emoji utility icons.
- Interactive: FAQ accordion toggles, mint-address copy button, ticker animation, hover lifts.
- Source of truth: `github.com/zypherthecoin/Zypher` (`index.html`).

import React from 'react';

export interface TooltipProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Tooltip content (kept short). */
  label: React.ReactNode;
  /** @default 'top' */
  position?: 'top' | 'bottom' | 'left' | 'right';
  /** Hover delay in ms. @default 80 */
  delay?: number;
  /** The trigger element. */
  children: React.ReactNode;
}

/** Zypher hover/focus tooltip (navy bubble with arrow). */
export function Tooltip(props: TooltipProps): JSX.Element;

Small navy tooltip shown on hover/focus of its trigger — ideal for explaining the brand's technical terms (NPI, SPL, TGE, mint authority).

```jsx
<Tooltip label="National Provider Identifier" position="top">
  <span style={{ borderBottom: '1px dotted var(--text-muted)', cursor: 'help' }}>NPI</span>
</Tooltip>

<Tooltip label="Copied to clipboard" position="right">
  <button>Copy</button>
</Tooltip>
```

Positions: `top` (default), `bottom`, `left`, `right`. Keep labels short; the bubble is single-line by default.

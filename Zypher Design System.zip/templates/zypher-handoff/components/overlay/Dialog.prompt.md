Modal dialog with a blurred navy backdrop and a centered card. Controlled with `open` + `onClose` (closes on backdrop click and Escape). Build the footer from `Button`s.

```jsx
const [open, setOpen] = React.useState(false);
<Button onClick={() => setOpen(true)}>Disconnect wallet</Button>
<Dialog
  open={open}
  onClose={() => setOpen(false)}
  title="Disconnect wallet?"
  description="You'll need to reconnect to sign transactions."
  footer={<>
    <Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button>
    <Button onClick={() => setOpen(false)}>Disconnect</Button>
  </>}
/>
```

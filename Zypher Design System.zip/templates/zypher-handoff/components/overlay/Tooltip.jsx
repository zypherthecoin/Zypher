import React from 'react';

/**
 * Zypher tooltip. Wraps a trigger; shows a small navy bubble on hover/focus.
 * Good for the brand's technical terms (NPI, SPL, TGE). Position: top
 * (default), bottom, left, right.
 */
export function Tooltip({ label, position = 'top', delay = 80, children, style, ...rest }) {
  const [open, setOpen] = React.useState(false);
  const timer = React.useRef(null);
  const show = () => { clearTimeout(timer.current); timer.current = setTimeout(() => setOpen(true), delay); };
  const hide = () => { clearTimeout(timer.current); setOpen(false); };

  const pos = {
    top: { bottom: '100%', left: '50%', transform: 'translateX(-50%)', marginBottom: 8 },
    bottom: { top: '100%', left: '50%', transform: 'translateX(-50%)', marginTop: 8 },
    left: { right: '100%', top: '50%', transform: 'translateY(-50%)', marginRight: 8 },
    right: { left: '100%', top: '50%', transform: 'translateY(-50%)', marginLeft: 8 },
  }[position];

  const arrowBase = { position: 'absolute', width: 7, height: 7, background: 'var(--navy)', transform: 'rotate(45deg)' };
  const arrow = {
    top: { ...arrowBase, bottom: -3, left: '50%', marginLeft: -3.5 },
    bottom: { ...arrowBase, top: -3, left: '50%', marginLeft: -3.5 },
    left: { ...arrowBase, right: -3, top: '50%', marginTop: -3.5 },
    right: { ...arrowBase, left: -3, top: '50%', marginTop: -3.5 },
  }[position];

  return (
    <span
      style={{ position: 'relative', display: 'inline-flex', ...style }}
      onMouseEnter={show} onMouseLeave={hide} onFocus={show} onBlur={hide}
      {...rest}
    >
      {children}
      <span
        role="tooltip"
        style={{
          position: 'absolute', zIndex: 'var(--z-overlay, 200)', ...pos,
          background: 'var(--navy)', color: '#fff', fontFamily: 'var(--font-sans)',
          fontSize: 'var(--fs-2xs)', fontWeight: 'var(--fw-medium)', lineHeight: 1.45,
          padding: '7px 11px', borderRadius: 'var(--radius-md)', whiteSpace: 'nowrap', maxWidth: 240,
          boxShadow: 'var(--shadow-md)', pointerEvents: 'none',
          opacity: open ? 1 : 0, visibility: open ? 'visible' : 'hidden',
          transition: 'opacity var(--dur-fast)',
        }}
      >
        {label}
        <span style={arrow} />
      </span>
    </span>
  );
}

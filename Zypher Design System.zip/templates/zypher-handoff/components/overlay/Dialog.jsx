import React from 'react';

/**
 * Zypher modal dialog. Backdrop blur + centered card. Controlled via
 * `open` + `onClose`. Closes on backdrop click and Escape. Compose the
 * footer with Button(s).
 */
export function Dialog({ open, onClose, title, description, children, footer, width = 460, style, ...rest }) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === 'Escape') onClose && onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose && onClose(); }}
      style={{
        position: 'fixed', inset: 0, zIndex: 'var(--z-overlay, 200)', background: 'rgba(12,35,64,0.45)',
        backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24,
      }}
    >
      <div
        role="dialog" aria-modal="true"
        style={{
          width, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', background: 'var(--surface-card)',
          border: '1px solid var(--border-default)', borderRadius: 'var(--radius-2xl)', boxShadow: 'var(--shadow-lg)',
          padding: 28, fontFamily: 'var(--font-sans)', ...style,
        }}
        {...rest}
      >
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16 }}>
          <div>
            {title && <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-display-sm)', color: 'var(--text-strong)', margin: 0, fontWeight: 400, lineHeight: 1.2 }}>{title}</h3>}
            {description && <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-muted)', margin: '8px 0 0', lineHeight: 1.55 }}>{description}</p>}
          </div>
          {onClose && (
            <button onClick={onClose} aria-label="Close" style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: 22, lineHeight: 1, padding: 0, flexShrink: 0 }}>×</button>
          )}
        </div>
        {children && <div style={{ marginTop: title || description ? 20 : 0, fontSize: 'var(--fs-sm)', color: 'var(--text-body)', lineHeight: 1.6 }}>{children}</div>}
        {footer && <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 24 }}>{footer}</div>}
      </div>
    </div>
  );
}

import React from 'react';

export interface DialogProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Whether the dialog is visible. */
  open: boolean;
  /** Called on backdrop click, Escape, or the close button. */
  onClose?: () => void;
  title?: React.ReactNode;
  description?: React.ReactNode;
  /** Footer action row (usually Button[s]). */
  footer?: React.ReactNode;
  /** Card width in px. @default 460 */
  width?: number;
  children?: React.ReactNode;
}

/**
 * Zypher modal dialog with blurred backdrop.
 * @startingPoint section="Overlay" subtitle="Modal dialog with backdrop & actions" viewport="700x360"
 */
export function Dialog(props: DialogProps): JSX.Element;

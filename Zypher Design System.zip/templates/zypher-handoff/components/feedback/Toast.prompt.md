Toast notifications — white card, soft shadow, tinted status-icon well. Pairs with copy/transaction actions (e.g. confirming a mint-address copy). Drive a live stack with the `useToast` hook + `ToastViewport`.

> **Namespace note:** the design-system bundle exposes only Capitalized exports, so `Toast` and `ToastViewport` are on `window.ZypherDesignSystem_7d1dbd` but the lowercase `useToast` hook is **not**. In real source code `import { useToast, ToastViewport } from './Toast'`. When mounting from the bundle (HTML/Babel), inline the tiny hook (it's ~8 lines) and use the namespace's `Toast`/`ToastViewport` to render.

```jsx
import { Toast, ToastViewport, useToast } from './Toast'; // source import

function App() {
  const { toasts, notify, dismiss } = useToast();
  return (
    <>
      <button onClick={() => notify({ tone: 'success', title: 'Address copied', message: 'Mint address copied to clipboard.' })}>Copy</button>
      <ToastViewport toasts={toasts} onDismiss={dismiss} position="bottom-right" />
    </>
  );
}
```

Tones: `success` (teal), `info` (navy), `warn` (amber), `error` (red). Use `<Toast/>` standalone for a static card.

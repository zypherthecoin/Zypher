import React from 'react';

const TONES = {
  success: { dot: 'var(--teal)', icon: '✓', tint: 'var(--teal-light)', iconColor: 'var(--teal)' },
  info: { dot: 'var(--navy)', icon: 'i', tint: '#EFF4FB', iconColor: 'var(--navy)' },
  warn: { dot: '#F59E0B', icon: '!', tint: 'var(--amber-bg)', iconColor: 'var(--amber-fg)' },
  error: { dot: '#DC2626', icon: '×', tint: '#FEF2F2', iconColor: '#DC2626' },
};

/**
 * Zypher toast — a white card with a soft shadow, a tinted status icon
 * well, title/message and a dismiss control. Use directly, or drive a
 * stack with ToastViewport + useToast.
 */
export function Toast({ tone = 'success', title, message, icon, onClose, style, ...rest }) {
  const t = TONES[tone] || TONES.success;
  return (
    <div
      role="status"
      style={{
        display: 'flex', alignItems: 'flex-start', gap: 12, width: 360, maxWidth: '90vw',
        background: 'var(--surface-card)', border: '1px solid var(--border-default)',
        borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)', padding: '14px 16px',
        fontFamily: 'var(--font-sans)', ...style,
      }}
      {...rest}
    >
      <span style={{
        width: 28, height: 28, borderRadius: 'var(--radius-md)', background: t.tint, color: t.iconColor,
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontWeight: 700, fontSize: 15,
      }}>{icon || t.icon}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        {title && <div style={{ fontSize: 'var(--fs-sm)', fontWeight: 'var(--fw-semibold)', color: 'var(--navy)', marginBottom: message ? 2 : 0 }}>{title}</div>}
        {message && <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--slate)', lineHeight: 1.5 }}>{message}</div>}
      </div>
      {onClose && (
        <button onClick={onClose} aria-label="Dismiss" style={{ background: 'none', border: 'none', color: 'var(--muted)', cursor: 'pointer', fontSize: 18, lineHeight: 1, padding: 0, flexShrink: 0 }}>×</button>
      )}
    </div>
  );
}

/** Fixed-position stack of toasts. */
export function ToastViewport({ toasts = [], onDismiss, position = 'bottom-right' }) {
  const pos = {
    'bottom-right': { bottom: 24, right: 24, alignItems: 'flex-end' },
    'bottom-left': { bottom: 24, left: 24, alignItems: 'flex-start' },
    'top-right': { top: 24, right: 24, alignItems: 'flex-end' },
    'top-center': { top: 24, left: '50%', transform: 'translateX(-50%)', alignItems: 'center' },
  }[position];
  return (
    <div style={{ position: 'fixed', zIndex: 'var(--z-overlay)', display: 'flex', flexDirection: 'column', gap: 10, ...pos }}>
      {toasts.map((t) => (
        <Toast key={t.id} {...t} onClose={onDismiss ? () => onDismiss(t.id) : undefined} />
      ))}
    </div>
  );
}

/** Minimal toast queue hook: { toasts, notify, dismiss }. */
export function useToast(autoDismiss = 3500) {
  const [toasts, setToasts] = React.useState([]);
  const dismiss = React.useCallback((id) => setToasts((cur) => cur.filter((t) => t.id !== id)), []);
  const notify = React.useCallback((toast) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((cur) => [...cur, { id, ...toast }]);
    if (autoDismiss) setTimeout(() => dismiss(id), autoDismiss);
    return id;
  }, [autoDismiss, dismiss]);
  return { toasts, notify, dismiss };
}

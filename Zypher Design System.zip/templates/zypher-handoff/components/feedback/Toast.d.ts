import React from 'react';

export type ToastTone = 'success' | 'info' | 'warn' | 'error';

export interface ToastData {
  id?: string;
  tone?: ToastTone;
  title?: React.ReactNode;
  message?: React.ReactNode;
  /** Override the status glyph. */
  icon?: React.ReactNode;
}

export interface ToastProps extends ToastData, React.HTMLAttributes<HTMLDivElement> {
  onClose?: () => void;
}

export interface ToastViewportProps {
  toasts: ToastData[];
  onDismiss?: (id: string) => void;
  /** @default 'bottom-right' */
  position?: 'bottom-right' | 'bottom-left' | 'top-right' | 'top-center';
}

/** A single Zypher toast card. */
export function Toast(props: ToastProps): JSX.Element;
/** Fixed-position toast stack. */
export function ToastViewport(props: ToastViewportProps): JSX.Element;
/** Toast queue hook → { toasts, notify, dismiss }. */
export function useToast(autoDismiss?: number): {
  toasts: ToastData[];
  notify: (t: ToastData) => string;
  dismiss: (id: string) => void;
};

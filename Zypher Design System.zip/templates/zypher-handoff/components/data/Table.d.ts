import React from 'react';

export interface TableColumn<Row = any> {
  /** Unique key; also the field read when `render` is omitted. */
  key: string;
  label: React.ReactNode;
  align?: 'left' | 'center' | 'right';
  /** Allow the cell to wrap (default: nowrap). */
  wrap?: boolean;
  /** Custom cell renderer. */
  render?: (row: Row, index: number) => React.ReactNode;
}

export interface TableProps<Row = any> extends React.HTMLAttributes<HTMLDivElement> {
  columns: TableColumn<Row>[];
  rows: Row[];
  onRowClick?: (row: Row, index: number) => void;
  /** plain = hairline header; navy = brand dark header bar. @default 'plain' */
  headerStyle?: 'plain' | 'navy';
  /** Tighter row height. */
  dense?: boolean;
}

/**
 * Zypher data table with custom cell rendering and optional navy header.
 * @startingPoint section="Data" subtitle="Data table — hairline or navy header" viewport="700x300"
 */
export function Table(props: TableProps): JSX.Element;

import React from 'react';

/**
 * Zypher content card. Optional accent stripe (top or left), optional
 * hover lift. The brand's feature/problem/link cards all derive from this.
 */
export function Card({
  accent = false,
  accentSide = 'top',
  hover = false,
  dark = false,
  children,
  style,
  ...rest
}) {
  const [lifted, setLifted] = React.useState(false);

  const base = {
    position: 'relative',
    background: dark ? 'var(--navy)' : 'var(--surface-card)',
    color: dark ? '#fff' : 'inherit',
    border: dark ? 'none' : '1px solid var(--border-default)',
    borderRadius: 'var(--radius-xl)',
    padding: '32px 28px',
    overflow: 'hidden',
    transition: 'transform var(--dur-fast), box-shadow var(--dur-base), border-color var(--dur-base)',
    transform: hover && lifted ? 'var(--hover-lift)' : 'none',
    boxShadow: hover && lifted ? 'var(--shadow-sm)' : 'none',
    borderColor: hover && lifted ? 'var(--teal)' : (dark ? 'none' : 'var(--border-default)'),
    ...style,
  };

  const stripe = accentSide === 'left'
    ? { top: 0, bottom: 0, left: 0, width: 'var(--border-accent-width)' }
    : { top: 0, left: 0, right: 0, height: 'var(--border-accent-width)' };

  return (
    <div
      style={base}
      onMouseEnter={() => hover && setLifted(true)}
      onMouseLeave={() => hover && setLifted(false)}
      {...rest}
    >
      {accent && <span style={{ position: 'absolute', background: 'var(--teal)', ...stripe }} />}
      {children}
    </div>
  );
}

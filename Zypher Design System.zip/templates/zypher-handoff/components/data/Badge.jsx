import React from 'react';

/**
 * Zypher status badge / tag. Used for roadmap phase states and pills.
 * `tone` maps to the brand's done/active/future status colors.
 */
export function Badge({ tone = 'done', dot = false, children, style, ...rest }) {
  const tones = {
    done: { background: 'var(--status-done-bg)', color: 'var(--status-done-fg)' },
    active: { background: 'var(--status-active-bg)', color: 'var(--status-active-fg)' },
    future: { background: 'var(--status-future-bg)', color: 'var(--status-future-fg)' },
    teal: { background: 'var(--teal)', color: '#fff' },
    navy: { background: 'var(--navy)', color: '#fff' },
    outline: { background: 'transparent', color: 'var(--teal)', boxShadow: 'inset 0 0 0 1px var(--border-default)' },
  };

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '6px',
        font: 'var(--type-eyebrow)',
        letterSpacing: 'var(--ls-eyebrow)',
        textTransform: 'uppercase',
        padding: '4px 10px',
        borderRadius: 'var(--radius-sm)',
        ...tones[tone],
        ...style,
      }}
      {...rest}
    >
      {dot && (
        <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'currentColor', flexShrink: 0 }} />
      )}
      {children}
    </span>
  );
}

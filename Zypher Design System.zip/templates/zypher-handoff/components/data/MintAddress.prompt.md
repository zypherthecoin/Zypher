Navy panel that displays a Solana mint/wallet address in DM Mono with a one-click copy button — the brand's signature tokenomics element.

```jsx
<MintAddress address="8sG1MjujqWKNZKkkGQQdekuMTLJvFdP3hoohyEiUr82t" />
```

The copy button confirms inline ("Copied ✓"). Override `label` for wallet/contract contexts.

Big-number stat card with a serif value, all-caps label and teal sub-line. Combine four in a 2×2 grid (1px gap on a border background) for the hero cluster.

```jsx
<StatCard value="$80B+" label="Uncompensated Care" sub="Lost annually in the US" />
<StatCard value="1B" label="ZPH Supply" sub="Fixed, minting revoked" />
```

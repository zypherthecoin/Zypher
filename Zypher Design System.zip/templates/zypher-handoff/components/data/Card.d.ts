import React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Show a teal accent stripe. */
  accent?: boolean;
  /** Which edge the accent stripe sits on. @default 'top' */
  accentSide?: 'top' | 'left';
  /** Lift + teal border + shadow on hover. */
  hover?: boolean;
  /** Navy surface variant for dark sections. */
  dark?: boolean;
  children?: React.ReactNode;
}

/**
 * Zypher content card with optional accent stripe and hover lift.
 * @startingPoint section="Surfaces" subtitle="Bordered card with accent stripe & hover lift" viewport="700x260"
 */
export function Card(props: CardProps): JSX.Element;

The base surface for Zypher's feature, problem, link and team cards: white, hairline border, 12px radius. Add a teal accent stripe or a hover lift; switch to a navy `dark` surface for dark sections.

```jsx
<Card accent>
  <div style={{fontFamily:'var(--font-display)',fontSize:'48px',color:'var(--teal)'}}>$80B+</div>
  <h3>Uncompensated Care Annually</h3>
  <p>U.S. hospitals absorb over $80 billion per year…</p>
</Card>

<Card hover accentSide="left">…</Card>
<Card dark>…</Card>
```

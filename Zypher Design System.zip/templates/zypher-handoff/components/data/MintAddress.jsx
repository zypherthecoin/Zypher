import React from 'react';

/**
 * Zypher mint-address bar — a navy panel showing a mono blockchain
 * address with a copy button. Mirrors the site's tokenomics mint bar.
 */
export function MintAddress({ address, label = 'Mint Address', style, ...rest }) {
  const [copied, setCopied] = React.useState(false);

  const copy = () => {
    try {
      navigator.clipboard?.writeText(address);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch (e) { /* noop */ }
  };

  return (
    <div
      style={{
        background: 'var(--navy)',
        padding: '20px 32px',
        borderRadius: 'var(--radius-lg)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '16px',
        flexWrap: 'wrap',
        ...style,
      }}
      {...rest}
    >
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 'var(--fs-3xs)', color: 'rgba(255,255,255,0.45)', fontWeight: 'var(--fw-semibold)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: '4px' }}>
          {label}
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--fs-xs)', color: 'var(--teal-mid)', letterSpacing: '0.03em', wordBreak: 'break-all' }}>
          {address}
        </div>
      </div>
      <button
        onClick={copy}
        style={{
          background: 'rgba(29,158,117,0.15)',
          border: '1px solid rgba(29,158,117,0.3)',
          color: 'var(--teal-mid)',
          borderRadius: 'var(--radius-md)',
          padding: '8px 16px',
          fontSize: 'var(--fs-xs)',
          cursor: 'pointer',
          fontFamily: 'var(--font-sans)',
          whiteSpace: 'nowrap',
          flexShrink: 0,
          transition: 'background var(--dur-base)',
        }}
        onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(29,158,117,0.25)')}
        onMouseLeave={(e) => (e.currentTarget.style.background = 'rgba(29,158,117,0.15)')}
      >
        {copied ? 'Copied ✓' : 'Copy Address'}
      </button>
    </div>
  );
}

import React from 'react';

export interface StatCardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Large serif headline value, e.g. "$80B+". */
  value: React.ReactNode;
  /** All-caps label below the value. */
  label: React.ReactNode;
  /** Optional teal sub-line. */
  sub?: React.ReactNode;
}

/** Zypher hero stat card: serif value + caps label + teal sub. */
export function StatCard(props: StatCardProps): JSX.Element;

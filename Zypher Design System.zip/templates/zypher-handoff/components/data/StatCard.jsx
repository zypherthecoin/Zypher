import React from 'react';

/**
 * Zypher stat card — large serif value over an all-caps label and a
 * teal sub-line. Used in the hero stat cluster.
 */
export function StatCard({ value, label, sub, style, ...rest }) {
  return (
    <div
      style={{
        background: 'var(--surface-card)',
        padding: '28px 24px',
        display: 'flex',
        flexDirection: 'column',
        gap: '6px',
        ...style,
      }}
      {...rest}
    >
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-display-md)', color: 'var(--navy)', lineHeight: 1 }}>
        {value}
      </div>
      <div style={{ fontSize: 'var(--fs-2xs)', color: 'var(--text-muted)', fontWeight: 'var(--fw-medium)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
        {label}
      </div>
      {sub && <div style={{ fontSize: 'var(--fs-3xs)', color: 'var(--teal)', fontWeight: 'var(--fw-medium)' }}>{sub}</div>}
    </div>
  );
}

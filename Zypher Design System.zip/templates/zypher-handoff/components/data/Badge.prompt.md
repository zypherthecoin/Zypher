All-caps status badge for roadmap phases, ticker labels and pills. Tones map to Zypher's status system.

```jsx
<Badge tone="done">Underway</Badge>
<Badge tone="active">In Progress</Badge>
<Badge tone="future">Horizon</Badge>
<Badge tone="teal" dot>Live on Solana</Badge>
```

Tones: `done` (teal tint), `active` (amber), `future` (grey), `teal`, `navy`, `outline`. Set `dot` for a leading status dot.

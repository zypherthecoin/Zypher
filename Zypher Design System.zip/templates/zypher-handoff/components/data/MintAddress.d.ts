import React from 'react';

export interface MintAddressProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The on-chain address to display in mono and copy. */
  address: string;
  /** Caps label above the address. @default 'Mint Address' */
  label?: string;
}

/** Navy mint-address bar with mono address and copy-to-clipboard button. */
export function MintAddress(props: MintAddressProps): JSX.Element;

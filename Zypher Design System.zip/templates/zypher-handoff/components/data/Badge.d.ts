import React from 'react';

export type BadgeTone = 'done' | 'active' | 'future' | 'teal' | 'navy' | 'outline';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Status colour. done=teal tint, active=amber, future=grey. @default 'done' */
  tone?: BadgeTone;
  /** Show a leading status dot. */
  dot?: boolean;
  children?: React.ReactNode;
}

/** Zypher all-caps status badge / pill. */
export function Badge(props: BadgeProps): JSX.Element;

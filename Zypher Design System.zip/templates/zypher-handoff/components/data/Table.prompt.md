Reusable data table — the formalized version of the dashboard's transaction/validator/registry tables. Hairline rows with an all-caps muted header (or a navy header bar), per-column alignment, custom cell renderers, and optional clickable rows.

```jsx
<Table
  headerStyle="navy"
  onRowClick={(r) => open(r)}
  columns={[
    { key: 'name', label: 'Provider', render: (r) => <strong>{r.name}</strong> },
    { key: 'npi', label: 'NPI', render: (r) => <span style={{fontFamily:'var(--font-mono)'}}>{r.npi}</span> },
    { key: 'status', label: 'Status', align: 'right', render: (r) => <Badge tone="done">{r.status}</Badge> },
  ]}
  rows={providers}
/>
```

Use `dense` for compact rows. Pair cells with `Badge` for statuses and DM Mono for addresses/IDs.

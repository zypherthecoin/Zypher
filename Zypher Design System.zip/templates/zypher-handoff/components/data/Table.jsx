import React from 'react';

/**
 * Zypher data table. Hairline rows, all-caps muted header, optional row
 * hover/click, and an optional navy header treatment. Columns drive
 * alignment and custom cell rendering.
 */
export function Table({ columns = [], rows = [], onRowClick, headerStyle = 'plain', dense = false, style, ...rest }) {
  const navy = headerStyle === 'navy';
  const cellPadY = dense ? 9 : 13;

  return (
    <div style={{ overflowX: 'auto', ...style }} {...rest}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 'var(--fs-xs)', fontFamily: 'var(--font-sans)' }}>
        <thead>
          <tr style={navy ? { background: 'var(--navy)' } : undefined}>
            {columns.map((c) => (
              <th key={c.key} style={{
                textAlign: c.align || 'left', padding: '11px 14px', whiteSpace: 'nowrap',
                font: 'var(--type-eyebrow)', letterSpacing: '0.08em', textTransform: 'uppercase',
                color: navy ? 'rgba(255,255,255,0.6)' : 'var(--text-muted)',
                borderBottom: navy ? 'none' : '1px solid var(--border-default)',
                borderTopLeftRadius: navy && c === columns[0] ? 'var(--radius-md)' : 0,
                borderTopRightRadius: navy && c === columns[columns.length - 1] ? 'var(--radius-md)' : 0,
              }}>{c.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} onClick={onRowClick ? () => onRowClick(r, i) : undefined}
              style={{ cursor: onRowClick ? 'pointer' : 'default', transition: 'background var(--dur-fast)' }}
              onMouseEnter={(e) => onRowClick && (e.currentTarget.style.background = 'var(--surface-tint, var(--teal-light))')}
              onMouseLeave={(e) => onRowClick && (e.currentTarget.style.background = 'transparent')}>
              {columns.map((c) => (
                <td key={c.key} style={{
                  textAlign: c.align || 'left', padding: `${cellPadY}px 14px`,
                  color: 'var(--text-body)', whiteSpace: c.wrap ? 'normal' : 'nowrap',
                  borderBottom: i < rows.length - 1 ? '1px solid var(--border-default)' : 'none',
                }}>
                  {c.render ? c.render(r, i) : r[c.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

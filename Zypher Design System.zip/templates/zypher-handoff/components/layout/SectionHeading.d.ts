import React from 'react';

export interface SectionHeadingProps extends React.HTMLAttributes<HTMLElement> {
  /** Small teal all-caps eyebrow above the title. */
  label?: React.ReactNode;
  /** Serif section title. */
  title: React.ReactNode;
  /** Light-weight lede subtitle. */
  sub?: React.ReactNode;
  /** @default 'left' */
  align?: 'left' | 'center';
  /** Use light text colours for navy sections. */
  onDark?: boolean;
}

/** Zypher section opener: eyebrow + serif title + lede. */
export function SectionHeading(props: SectionHeadingProps): JSX.Element;

import React from 'react';

/**
 * Zypher process stepper. Horizontal = the "How it works" numbered row
 * (teal circles on a connector line). Vertical = the "How to buy" flow
 * (numbered nodes joined by a vertical rule). Numerals use the serif face.
 */
export function Stepper({ steps = [], orientation = 'horizontal', style, ...rest }) {
  const Num = ({ n }) => (
    <div style={{
      width: orientation === 'horizontal' ? 56 : 48,
      height: orientation === 'horizontal' ? 56 : 48,
      background: 'var(--teal)', borderRadius: '50%', color: '#fff',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'var(--font-display)', fontSize: 20, flexShrink: 0, zIndex: 1,
    }}>{n}</div>
  );

  if (orientation === 'vertical') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', ...style }} {...rest}>
        {steps.map((s, i) => (
          <div key={i} style={{ display: 'flex', gap: 32, paddingBottom: i < steps.length - 1 ? 40 : 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
              <Num n={i + 1} />
              {i < steps.length - 1 && <div style={{ width: 2, flex: 1, background: 'var(--border)', margin: '8px 0', minHeight: 40 }} />}
            </div>
            <div style={{ paddingTop: 10, flex: 1 }}>
              <div style={{ fontSize: 18, fontWeight: 600, color: 'var(--navy)', marginBottom: 10, lineHeight: 1.3 }}>{s.title}</div>
              {s.desc && <div style={{ fontSize: 15, color: 'var(--slate)', lineHeight: 1.75 }}>{s.desc}</div>}
              {s.children}
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: `repeat(${steps.length}, 1fr)`, position: 'relative', ...style }} {...rest}>
      <div style={{ position: 'absolute', top: 28, left: '10%', right: '10%', height: 1, background: 'var(--border)', zIndex: 0 }} />
      {steps.map((s, i) => (
        <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: '0 16px', position: 'relative', zIndex: 1 }}>
          <div style={{ marginBottom: 20 }}><Num n={i + 1} /></div>
          <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--navy)', marginBottom: 8 }}>{s.title}</div>
          {s.desc && <div style={{ fontSize: 13, color: 'var(--slate)', lineHeight: 1.6 }}>{s.desc}</div>}
        </div>
      ))}
    </div>
  );
}

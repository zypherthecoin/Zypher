Numbered process flow with serif numerals in teal circles. `horizontal` reproduces the "How it works" row (circles on a connector line); `vertical` reproduces the "How to buy" timeline.

```jsx
<Stepper orientation="horizontal" steps={[
  { title: 'Federal Data Ingestion', desc: 'NPPES, CMS and HRSA pipelines are connected.' },
  { title: 'Verification & Hashing', desc: 'Records are normalized and SHA-256 hashed.' },
  { title: 'On-Chain Anchoring', desc: 'Hashes are anchored to Solana.' },
]} />

<Stepper orientation="vertical" steps={[
  { title: 'Download a Solana wallet', desc: 'Phantom or Solflare.' },
]} />
```

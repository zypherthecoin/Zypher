import React from 'react';

export interface CalloutProps extends React.HTMLAttributes<HTMLDivElement> {
  /** info=teal, warn=amber. @default 'info' */
  tone?: 'info' | 'warn';
  /** Optional leading icon node. */
  icon?: React.ReactNode;
  children?: React.ReactNode;
}

/** Tinted note box with a left accent bar (teal or amber). */
export function Callout(props: CalloutProps): JSX.Element;

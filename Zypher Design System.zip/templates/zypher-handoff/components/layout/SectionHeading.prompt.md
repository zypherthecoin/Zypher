The canonical opener for any Zypher section — teal eyebrow, large DM Serif Display title, light lede. Use `onDark` on navy backgrounds.

```jsx
<SectionHeading
  label="The Problem"
  title="American healthcare loses billions to a broken data layer."
  sub="Provider directories are inaccurate. Billing systems are fragmented."
/>
```

Inline note box with a left accent bar — teal for tips/info, amber for warnings. Used throughout the "how to buy" walkthrough.

```jsx
<Callout tone="info" icon="✓">Always verify the mint address before trading.</Callout>
<Callout tone="warn" icon="!">Never share your seed phrase with anyone.</Callout>
```

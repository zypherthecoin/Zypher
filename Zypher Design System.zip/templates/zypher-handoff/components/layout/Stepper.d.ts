import React from 'react';

export interface StepperStep {
  title: React.ReactNode;
  desc?: React.ReactNode;
  /** Extra content under the step (vertical orientation only). */
  children?: React.ReactNode;
}

export interface StepperProps extends React.HTMLAttributes<HTMLDivElement> {
  steps: StepperStep[];
  /** horizontal = connected row; vertical = numbered timeline. @default 'horizontal' */
  orientation?: 'horizontal' | 'vertical';
}

/** Zypher numbered process stepper (serif numerals in teal circles). */
export function Stepper(props: StepperProps): JSX.Element;

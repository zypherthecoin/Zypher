import React from 'react';

/**
 * Zypher callout — a tinted box with a left accent bar for inline notes.
 * `info` = teal, `warn` = amber. Mirrors the "how to buy" callouts.
 */
export function Callout({ tone = 'info', icon, children, style, ...rest }) {
  const tones = {
    info: { background: 'var(--teal-light)', border: 'var(--teal)', color: 'var(--teal-dark)' },
    warn: { background: 'var(--amber-bg)', border: '#F59E0B', color: '#92400E' },
  };
  const t = tones[tone];

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '10px',
        background: t.background,
        borderLeft: `3px solid ${t.border}`,
        borderRadius: '0 var(--radius-lg) var(--radius-lg) 0',
        padding: '12px 16px',
        fontSize: 'var(--fs-xs)',
        color: t.color,
        lineHeight: 1.6,
        ...style,
      }}
      {...rest}
    >
      {icon && <span style={{ flexShrink: 0, fontSize: '15px', lineHeight: 1.4 }}>{icon}</span>}
      <div>{children}</div>
    </div>
  );
}

import React from 'react';

/**
 * Zypher section heading: teal eyebrow label, large serif title, light
 * lede subtitle. The standard opener for every page section.
 */
export function SectionHeading({ label, title, sub, align = 'left', onDark = false, style, ...rest }) {
  return (
    <header style={{ textAlign: align, ...style }} {...rest}>
      {label && (
        <div style={{ font: 'var(--type-eyebrow)', letterSpacing: 'var(--ls-eyebrow)', textTransform: 'uppercase', color: 'var(--teal)', marginBottom: '12px' }}>
          {label}
        </div>
      )}
      <h2 style={{
        fontFamily: 'var(--font-display)',
        fontSize: 'var(--fs-display-lg)',
        color: onDark ? '#fff' : 'var(--navy)',
        lineHeight: 1.15,
        letterSpacing: '-0.5px',
        margin: 0,
        fontWeight: 400,
      }}>
        {title}
      </h2>
      {sub && (
        <p style={{
          fontSize: 'var(--fs-lede)',
          color: onDark ? 'rgba(255,255,255,0.6)' : 'var(--slate)',
          fontWeight: 'var(--fw-light)',
          maxWidth: '560px',
          lineHeight: 1.75,
          marginTop: '16px',
          marginLeft: align === 'center' ? 'auto' : 0,
          marginRight: align === 'center' ? 'auto' : 0,
          marginBottom: 0,
        }}>
          {sub}
        </p>
      )}
    </header>
  );
}

Single-line text input with optional label, helper hint, error state and prefix slot. Border lifts to teal with a soft focus ring on focus.

```jsx
<Input label="Email" placeholder="you@hospital.org" />
<Input label="Wallet address" prefix="◎" hint="Solana address" />
<Input label="Amount" error="Insufficient balance" />
```

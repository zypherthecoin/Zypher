import React from 'react';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Field label rendered above the input. */
  label?: string;
  /** Helper text below the field. */
  hint?: string;
  /** Error message — turns the border and hint red. */
  error?: string;
  /** Static prefix node inside the field (e.g. a unit or icon). */
  prefix?: React.ReactNode;
}

/** Zypher text input with label, hint and teal focus ring. */
export function Input(props: InputProps): JSX.Element;

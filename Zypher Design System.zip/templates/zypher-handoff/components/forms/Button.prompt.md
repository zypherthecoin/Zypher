Zypher's primary action button — teal fill for primary actions, bordered white for secondary, text-only ghost, and a `dark` variant tuned for navy panels.

```jsx
<Button href="https://jup.ag" trailingIcon="↗">Buy ZPH on Jupiter</Button>
<Button variant="secondary">Read Whitepaper</Button>
<Button variant="ghost" size="sm">Learn more</Button>
<Button variant="dark">Copy Address</Button>
```

Variants: `primary` (default), `secondary`, `ghost`, `dark`. Sizes: `sm`, `md` (default), `lg`. Pass `href` to render as a link. Hover lifts the button 1px and darkens the fill.

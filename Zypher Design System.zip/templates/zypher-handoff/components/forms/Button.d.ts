import React from 'react';

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'dark';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual style. `dark` is for placement on navy surfaces. @default 'primary' */
  variant?: ButtonVariant;
  /** @default 'md' */
  size?: ButtonSize;
  /** Render as an anchor instead of a button. */
  href?: string;
  /** Icon node placed before the label. */
  leadingIcon?: React.ReactNode;
  /** Icon node placed after the label (e.g. an ↗ arrow). */
  trailingIcon?: React.ReactNode;
  disabled?: boolean;
  children?: React.ReactNode;
}

/**
 * Zypher action button.
 * @startingPoint section="Forms" subtitle="Primary, secondary, ghost & dark buttons" viewport="700x200"
 */
export function Button(props: ButtonProps): JSX.Element;

import React from 'react';

/**
 * Zypher text input with optional label. Cool border, teal focus ring.
 */
export function Input({
  label,
  hint,
  error,
  prefix,
  id,
  style,
  ...rest
}) {
  const inputId = id || (label ? `zy-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);

  const wrap = { display: 'flex', flexDirection: 'column', gap: '6px', fontFamily: 'var(--font-sans)' };
  const labelStyle = {
    font: 'var(--type-label)',
    color: 'var(--text-strong)',
    fontWeight: 'var(--fw-semibold)',
  };
  const field = {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    background: 'var(--surface-card)',
    border: `1px solid ${error ? '#DC2626' : 'var(--border-default)'}`,
    borderRadius: 'var(--radius-md)',
    padding: '0 14px',
    transition: 'border-color var(--dur-base), box-shadow var(--dur-base)',
  };
  const input = {
    flex: 1,
    border: 'none',
    outline: 'none',
    background: 'transparent',
    padding: '11px 0',
    fontSize: 'var(--fs-sm)',
    color: 'var(--text-strong)',
    fontFamily: 'var(--font-sans)',
    ...style,
  };

  return (
    <label style={wrap} htmlFor={inputId}>
      {label && <span style={labelStyle}>{label}</span>}
      <span
        style={field}
        onFocus={(e) => { e.currentTarget.style.borderColor = 'var(--teal)'; e.currentTarget.style.boxShadow = '0 0 0 3px var(--focus-ring)'; }}
        onBlur={(e) => { e.currentTarget.style.borderColor = error ? '#DC2626' : 'var(--border-default)'; e.currentTarget.style.boxShadow = 'none'; }}
      >
        {prefix && <span style={{ color: 'var(--text-muted)', fontSize: 'var(--fs-sm)' }}>{prefix}</span>}
        <input id={inputId} style={input} {...rest} />
      </span>
      {(hint || error) && (
        <span style={{ fontSize: 'var(--fs-2xs)', color: error ? '#DC2626' : 'var(--text-muted)' }}>
          {error || hint}
        </span>
      )}
    </label>
  );
}

import React from 'react';

/**
 * Zypher primary action button. Teal fill by default; secondary is a
 * bordered white pill; ghost is text-only. Lifts 1px on hover.
 */
export function Button({
  variant = 'primary',
  size = 'md',
  href,
  trailingIcon,
  leadingIcon,
  disabled = false,
  children,
  style,
  ...rest
}) {
  const sizes = {
    sm: { padding: '8px 16px', fontSize: '13px' },
    md: { padding: '13px 24px', fontSize: '15px' },
    lg: { padding: '16px 30px', fontSize: '16px' },
  };

  const variants = {
    primary: {
      background: 'var(--teal)',
      color: '#fff',
      border: '1px solid var(--teal)',
    },
    secondary: {
      background: 'var(--surface-card)',
      color: 'var(--navy)',
      border: '1px solid var(--border-default)',
    },
    ghost: {
      background: 'transparent',
      color: 'var(--teal)',
      border: '1px solid transparent',
    },
    dark: {
      background: 'rgba(29,158,117,0.15)',
      color: 'var(--teal-mid)',
      border: '1px solid rgba(29,158,117,0.3)',
    },
  };

  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    borderRadius: 'var(--radius-lg)',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--fw-medium)',
    lineHeight: 1,
    textDecoration: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    transition: 'background var(--dur-base), border-color var(--dur-base), transform var(--dur-fast)',
    whiteSpace: 'nowrap',
    ...sizes[size],
    ...variants[variant],
    ...style,
  };

  const onEnter = (e) => {
    if (disabled) return;
    e.currentTarget.style.transform = 'translateY(-1px)';
    if (variant === 'primary') e.currentTarget.style.background = 'var(--teal-dark)';
    if (variant === 'secondary') { e.currentTarget.style.borderColor = 'var(--teal)'; e.currentTarget.style.color = 'var(--teal)'; }
    if (variant === 'ghost') e.currentTarget.style.background = 'var(--teal-light)';
    if (variant === 'dark') e.currentTarget.style.background = 'rgba(29,158,117,0.25)';
  };
  const onLeave = (e) => {
    if (disabled) return;
    e.currentTarget.style.transform = 'none';
    e.currentTarget.style.background = variants[variant].background;
    e.currentTarget.style.borderColor = variants[variant].border.split(' ').pop();
    if (variant === 'secondary') e.currentTarget.style.color = 'var(--navy)';
  };

  const content = (
    <>
      {leadingIcon}
      {children}
      {trailingIcon}
    </>
  );

  const Tag = href ? 'a' : 'button';
  const tagProps = href ? { href } : { disabled };

  return (
    <Tag style={base} onMouseEnter={onEnter} onMouseLeave={onLeave} {...tagProps} {...rest}>
      {content}
    </Tag>
  );
}

import React from 'react';

/**
 * Zypher tabs. `underline` (default) = a row of labels with a teal active
 * underline; `segment` = a pill segmented control on a tinted track.
 * Controlled (pass value + onChange) or uncontrolled (defaultValue).
 */
export function Tabs({ tabs = [], value, defaultValue, onChange, variant = 'underline', style, ...rest }) {
  const [internal, setInternal] = React.useState(defaultValue ?? (tabs[0] && tabs[0].id));
  const active = value !== undefined ? value : internal;
  const select = (id) => { if (value === undefined) setInternal(id); onChange && onChange(id); };

  if (variant === 'segment') {
    return (
      <div role="tablist" style={{ display: 'inline-flex', gap: 4, background: 'var(--surface-tint, var(--teal-light))', borderRadius: 'var(--radius-lg)', padding: 3, ...style }} {...rest}>
        {tabs.map((t) => {
          const on = active === t.id;
          return (
            <button key={t.id} role="tab" aria-selected={on} onClick={() => select(t.id)} style={{
              border: 'none', cursor: 'pointer', padding: '7px 16px', borderRadius: 'var(--radius-md)',
              fontFamily: 'var(--font-sans)', fontSize: 'var(--fs-xs)', fontWeight: 'var(--fw-semibold)',
              background: on ? 'var(--surface-card)' : 'transparent', color: on ? 'var(--color-primary)' : 'var(--text-muted)',
              boxShadow: on ? 'var(--shadow-xs)' : 'none', transition: 'color var(--dur-fast)',
              display: 'inline-flex', alignItems: 'center', gap: 7,
            }}>
              {t.icon}{t.label}{t.count != null && <span style={{ fontSize: 11, opacity: 0.7 }}>{t.count}</span>}
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div role="tablist" style={{ display: 'flex', gap: 4, borderBottom: '1px solid var(--border-default)', ...style }} {...rest}>
      {tabs.map((t) => {
        const on = active === t.id;
        return (
          <button key={t.id} role="tab" aria-selected={on} onClick={() => select(t.id)} style={{
            border: 'none', background: 'none', cursor: 'pointer', padding: '12px 14px',
            fontFamily: 'var(--font-sans)', fontSize: 'var(--fs-sm)', fontWeight: on ? 'var(--fw-semibold)' : 'var(--fw-medium)',
            color: on ? 'var(--color-primary)' : 'var(--text-muted)', position: 'relative', marginBottom: -1,
            borderBottom: `2px solid ${on ? 'var(--color-primary)' : 'transparent'}`, transition: 'color var(--dur-fast)',
            display: 'inline-flex', alignItems: 'center', gap: 8,
          }}>
            {t.icon}{t.label}
            {t.count != null && (
              <span style={{ fontSize: 11, fontWeight: 600, color: on ? 'var(--color-primary)' : 'var(--text-muted)', background: on ? 'var(--color-primary-tint, var(--teal-light))' : 'var(--surface-tint, var(--bg))', borderRadius: 999, padding: '1px 7px' }}>{t.count}</span>
            )}
          </button>
        );
      })}
    </div>
  );
}

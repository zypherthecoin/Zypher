Dropdown menu — a trigger plus a popover list (click to open, click-outside / Escape to close). Items take icons, shortcuts, dividers, and a `danger` tone.

```jsx
<Menu
  align="right"
  trigger={<Button variant="secondary">Account ▾</Button>}
  items={[
    { label: 'View on Explorer', icon: <Icon name="external-link" size={15} /> },
    { label: 'Copy address', shortcut: '⌘C' },
    { divider: true },
    { label: 'Disconnect', danger: true, onClick: disconnect },
  ]}
/>
```

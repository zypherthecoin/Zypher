Tab navigation in two styles: `underline` (a tab row with a teal active underline + optional count badges) and `segment` (a pill segmented control). Controlled or uncontrolled. You render the active panel yourself based on the selected id.

```jsx
const [tab, setTab] = React.useState('overview');
<Tabs
  value={tab}
  onChange={setTab}
  tabs={[
    { id: 'overview', label: 'Overview' },
    { id: 'activity', label: 'Activity', count: 12 },
    { id: 'about', label: 'About' },
  ]}
/>

<Tabs variant="segment" defaultValue="24h" tabs={[
  { id: '24h', label: '24H' }, { id: '7d', label: '7D' }, { id: '30d', label: '30D' },
]} />
```

import React from 'react';

/**
 * Zypher dropdown menu. A trigger element + a popover list. Click to open,
 * click-outside / Escape to close. Items support icons, dividers and a
 * `danger` tone. Align the popover left (default) or right of the trigger.
 */
export function Menu({ trigger, items = [], align = 'left', width = 200, style, ...rest }) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);

  React.useEffect(() => {
    if (!open) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onKey); };
  }, [open]);

  return (
    <span ref={ref} style={{ position: 'relative', display: 'inline-flex', ...style }} {...rest}>
      <span onClick={() => setOpen((o) => !o)} style={{ display: 'inline-flex', cursor: 'pointer' }}>{trigger}</span>
      {open && (
        <div role="menu" style={{
          position: 'absolute', top: '100%', [align]: 0, marginTop: 8, width, zIndex: 'var(--z-overlay, 200)',
          background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)',
          boxShadow: 'var(--shadow-lg)', padding: 6, fontFamily: 'var(--font-sans)',
        }}>
          {items.map((it, i) => it.divider ? (
            <div key={i} style={{ height: 1, background: 'var(--border-default)', margin: '6px 0' }} />
          ) : (
            <button key={i} role="menuitem" disabled={it.disabled}
              onClick={() => { setOpen(false); it.onClick && it.onClick(); }}
              style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '9px 11px', borderRadius: 'var(--radius-md)',
                border: 'none', background: 'transparent', cursor: it.disabled ? 'not-allowed' : 'pointer', textAlign: 'left',
                fontFamily: 'var(--font-sans)', fontSize: 'var(--fs-sm)', fontWeight: 'var(--fw-medium)',
                color: it.disabled ? 'var(--text-muted)' : (it.danger ? '#DC2626' : 'var(--text-body)'), opacity: it.disabled ? 0.6 : 1,
              }}
              onMouseEnter={(e) => { if (!it.disabled) e.currentTarget.style.background = it.danger ? '#FEF2F2' : 'var(--surface-tint, var(--teal-light))'; }}
              onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
              {it.icon && <span style={{ display: 'inline-flex', flexShrink: 0 }}>{it.icon}</span>}
              <span style={{ flex: 1 }}>{it.label}</span>
              {it.shortcut && <span style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{it.shortcut}</span>}
            </button>
          ))}
        </div>
      )}
    </span>
  );
}

import React from 'react';

export interface MenuItem {
  label?: React.ReactNode;
  icon?: React.ReactNode;
  /** Mono keyboard hint shown at the right. */
  shortcut?: string;
  onClick?: () => void;
  disabled?: boolean;
  /** Red destructive styling. */
  danger?: boolean;
  /** Render a divider instead of an item. */
  divider?: boolean;
}

export interface MenuProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** The clickable trigger element. */
  trigger: React.ReactNode;
  items: MenuItem[];
  /** Popover edge alignment. @default 'left' */
  align?: 'left' | 'right';
  /** Popover width in px. @default 200 */
  width?: number;
}

/** Zypher dropdown menu (trigger + popover list with icons/dividers/danger). */
export function Menu(props: MenuProps): JSX.Element;

import React from 'react';

export interface TabItem {
  /** Unique id reported by onChange / matched against value. */
  id: string;
  label: React.ReactNode;
  /** Optional leading icon node. */
  icon?: React.ReactNode;
  /** Optional count badge. */
  count?: number;
}

export interface TabsProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
  tabs: TabItem[];
  /** Controlled active id. */
  value?: string;
  /** Initial active id (uncontrolled). */
  defaultValue?: string;
  onChange?: (id: string) => void;
  /** underline = tab row; segment = pill control. @default 'underline' */
  variant?: 'underline' | 'segment';
}

/**
 * Zypher tabs — underline row or segmented pill control.
 * @startingPoint section="Navigation" subtitle="Underline & segmented tabs" viewport="700x160"
 */
export function Tabs(props: TabsProps): JSX.Element;

import React from 'react';

export interface AccordionItem {
  /** Trigger row label (the question). */
  q: React.ReactNode;
  /** Expanded content (the answer). */
  a: React.ReactNode;
}

export interface AccordionProps extends React.HTMLAttributes<HTMLDivElement> {
  items: AccordionItem[];
  /** Index open initially; -1 for all closed. @default 0 */
  defaultOpen?: number;
  /** Allow several rows open at once. @default false */
  allowMultiple?: boolean;
}

/**
 * Zypher FAQ-style accordion.
 * @startingPoint section="Disclosure" subtitle="FAQ-style expandable list" viewport="700x320"
 */
export function Accordion(props: AccordionProps): JSX.Element;

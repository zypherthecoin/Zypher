Bordered FAQ-style disclosure list — the reusable version of the Zypher site's FAQ. Each row has a teal "+" well that rotates open. Single-open by default; set `allowMultiple` to keep several expanded.

```jsx
<Accordion
  defaultOpen={0}
  items={[
    { q: 'Is ZPH supply fixed?', a: 'Yes — a hard cap of 1,000,000,000, both authorities revoked.' },
    { q: 'Where can I buy ZPH?', a: 'On Jupiter and Raydium. Always verify the mint address first.' },
  ]}
/>
```

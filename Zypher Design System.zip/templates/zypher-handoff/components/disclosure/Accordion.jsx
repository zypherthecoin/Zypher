import React from 'react';

/**
 * Zypher accordion / disclosure list. Mirrors the site's FAQ pattern:
 * bordered rows, teal "+" well that rotates to "×" when open.
 */
export function Accordion({ items = [], defaultOpen = 0, allowMultiple = false, style, ...rest }) {
  const [open, setOpen] = React.useState(
    allowMultiple ? (defaultOpen === -1 ? [] : [defaultOpen]) : defaultOpen
  );

  const isOpen = (i) => (allowMultiple ? open.includes(i) : open === i);
  const toggle = (i) => {
    if (allowMultiple) {
      setOpen((cur) => (cur.includes(i) ? cur.filter((x) => x !== i) : [...cur, i]));
    } else {
      setOpen((cur) => (cur === i ? -1 : i));
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, ...style }} {...rest}>
      {items.map((it, i) => {
        const o = isOpen(i);
        return (
          <div key={i} style={{ background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)', overflow: 'hidden' }}>
            <button
              onClick={() => toggle(i)}
              aria-expanded={o}
              style={{
                width: '100%', background: 'none', border: 'none', padding: '22px 28px', textAlign: 'left',
                fontSize: 'var(--fs-body)', fontWeight: 'var(--fw-medium)', color: 'var(--navy)', cursor: 'pointer',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 16, fontFamily: 'var(--font-sans)',
                transition: 'background var(--dur-fast)',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--bg)')}
              onMouseLeave={(e) => (e.currentTarget.style.background = 'none')}
            >
              {it.q}
              <span style={{
                width: 24, height: 24, borderRadius: '50%', background: 'var(--teal-light)', color: 'var(--teal)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0, lineHeight: 1,
                transition: 'transform var(--dur-base)', transform: o ? 'rotate(45deg)' : 'none',
              }}>+</span>
            </button>
            {o && (
              <div style={{ padding: '0 28px 22px', fontSize: 'var(--fs-sm)', color: 'var(--slate)', lineHeight: 1.7 }}>
                {it.a}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

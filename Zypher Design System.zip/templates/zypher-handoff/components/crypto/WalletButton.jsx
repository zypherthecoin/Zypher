import React from 'react';

const trunc = (a) => (a && a.length > 10 ? `${a.slice(0, 4)}…${a.slice(-4)}` : a);

/**
 * Zypher wallet connect button. Disconnected = teal primary "Connect
 * Wallet"; connected = a navy/teal pill showing a status dot, truncated
 * address and balance. Self-contained demo state if no handlers passed.
 */
export function WalletButton({
  address,
  balance = '0 ZPH',
  connected: connectedProp,
  onConnect,
  onDisconnect,
  size = 'md',
  style,
  ...rest
}) {
  const controlled = connectedProp !== undefined;
  const [demoConnected, setDemoConnected] = React.useState(false);
  const connected = controlled ? connectedProp : demoConnected;
  const addr = address || '8sG1MjujqWKNZKkkGQQdekuMTLJvFdP3hoohyEiUr82t';

  const pad = size === 'sm' ? '8px 14px' : '11px 18px';

  if (!connected) {
    return (
      <button
        onClick={() => { onConnect ? onConnect() : setDemoConnected(true); }}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 8, background: 'var(--teal)', color: '#fff',
          border: '1px solid var(--teal)', borderRadius: 'var(--radius-lg)', padding: pad,
          fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-medium)', fontSize: 'var(--fs-sm)',
          cursor: 'pointer', transition: 'background var(--dur-base), transform var(--dur-fast)', ...style,
        }}
        onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--teal-dark)'; e.currentTarget.style.transform = 'translateY(-1px)'; }}
        onMouseLeave={(e) => { e.currentTarget.style.background = 'var(--teal)'; e.currentTarget.style.transform = 'none'; }}
        {...rest}
      >
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#fff', opacity: 0.9 }} />
        Connect Wallet
      </button>
    );
  }

  return (
    <button
      onClick={() => { onDisconnect ? onDisconnect() : setDemoConnected(false); }}
      title="Click to disconnect"
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 10, background: 'var(--navy)', color: '#fff',
        border: '1px solid rgba(29,158,117,0.3)', borderRadius: 'var(--radius-pill)', padding: pad,
        fontFamily: 'var(--font-sans)', fontSize: 'var(--fs-xs)', cursor: 'pointer',
        transition: 'border-color var(--dur-base)', ...style,
      }}
      onMouseEnter={(e) => (e.currentTarget.style.borderColor = 'var(--teal-mid)')}
      onMouseLeave={(e) => (e.currentTarget.style.borderColor = 'rgba(29,158,117,0.3)')}
      {...rest}
    >
      <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--teal-mid)', flexShrink: 0 }} />
      <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--teal-mid)' }}>{trunc(addr)}</span>
      <span style={{ width: 1, height: 14, background: 'rgba(255,255,255,0.15)' }} />
      <span style={{ fontWeight: 'var(--fw-medium)' }}>{balance}</span>
    </button>
  );
}

Solana wallet connect button. Disconnected: a teal primary "Connect Wallet". Connected: a navy pill with a teal status dot, truncated mono address and balance. Click the pill to disconnect. With no handlers it self-toggles for demos.

```jsx
<WalletButton />                                  {/* demo toggle */}
<WalletButton connected address={addr} balance="12,500 ZPH"
  onDisconnect={() => setAddr(null)} />
```

Pass `connected`, `onConnect`, `onDisconnect` to control it; `size="sm"` for nav bars.

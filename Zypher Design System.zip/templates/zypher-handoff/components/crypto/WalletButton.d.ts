import React from 'react';

export interface WalletButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Wallet address shown (truncated) when connected. */
  address?: string;
  /** Balance label shown when connected. @default '0 ZPH' */
  balance?: string;
  /** Controlled connected state. Omit to use built-in demo toggle. */
  connected?: boolean;
  onConnect?: () => void;
  onDisconnect?: () => void;
  /** @default 'md' */
  size?: 'sm' | 'md';
}

/**
 * Zypher wallet connect / connected-account button.
 * @startingPoint section="Crypto" subtitle="Connect Wallet + connected account pill" viewport="700x140"
 */
export function WalletButton(props: WalletButtonProps): JSX.Element;

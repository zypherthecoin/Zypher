/* @ds-bundle: {"format":3,"namespace":"ZypherDesignSystem_7d1dbd","components":[{"name":"WalletButton","sourcePath":"components/crypto/WalletButton.jsx"},{"name":"Badge","sourcePath":"components/data/Badge.jsx"},{"name":"Card","sourcePath":"components/data/Card.jsx"},{"name":"MintAddress","sourcePath":"components/data/MintAddress.jsx"},{"name":"StatCard","sourcePath":"components/data/StatCard.jsx"},{"name":"Table","sourcePath":"components/data/Table.jsx"},{"name":"Accordion","sourcePath":"components/disclosure/Accordion.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"ToastViewport","sourcePath":"components/feedback/Toast.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Callout","sourcePath":"components/layout/Callout.jsx"},{"name":"SectionHeading","sourcePath":"components/layout/SectionHeading.jsx"},{"name":"Stepper","sourcePath":"components/layout/Stepper.jsx"},{"name":"Menu","sourcePath":"components/navigation/Menu.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Dialog","sourcePath":"components/overlay/Dialog.jsx"},{"name":"Tooltip","sourcePath":"components/overlay/Tooltip.jsx"}],"sourceHashes":{"components/crypto/WalletButton.jsx":"47e27752f24e","components/data/Badge.jsx":"02e8c2210090","components/data/Card.jsx":"aa2134eb22fc","components/data/MintAddress.jsx":"587154dac1ae","components/data/StatCard.jsx":"2592ebd2d6aa","components/data/Table.jsx":"7f03abe723a4","components/disclosure/Accordion.jsx":"f797f0837f1c","components/feedback/Toast.jsx":"b4b61350260e","components/forms/Button.jsx":"59eaaa73c35b","components/forms/Input.jsx":"a0c70ef9f703","components/layout/Callout.jsx":"4d7935cdf0fa","components/layout/SectionHeading.jsx":"1dcde876d337","components/layout/Stepper.jsx":"8dce88bc7284","components/navigation/Menu.jsx":"e20ff26fba6f","components/navigation/Tabs.jsx":"50bd7bfdb776","components/overlay/Dialog.jsx":"4f4f7e54e6c5","components/overlay/Tooltip.jsx":"a15b6bb89463","ui_kits/zypher-app/app.jsx":"ee5a49579ff0","ui_kits/zypher-app/charts.jsx":"55981ea3b29f","ui_kits/zypher-app/screens-a.jsx":"c1436dad25c2","ui_kits/zypher-app/screens-b.jsx":"dbf17d88d14a","ui_kits/zypher-app/screens-c.jsx":"ba3abae345c0","ui_kits/zypher-app/shell.jsx":"1c8d0d4f105e","ui_kits/zypher-site/sections.jsx":"c02d9c5246a0"},"inlinedExternals":[],"unexposedExports":[{"name":"useToast","sourcePath":"components/feedback/Toast.jsx"}]} */

(() => {

const __ds_ns = (window.ZypherDesignSystem_7d1dbd = window.ZypherDesignSystem_7d1dbd || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/crypto/WalletButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const trunc = a => a && a.length > 10 ? `${a.slice(0, 4)}…${a.slice(-4)}` : a;

/**
 * Zypher wallet connect button. Disconnected = teal primary "Connect
 * Wallet"; connected = a navy/teal pill showing a status dot, truncated
 * address and balance. Self-contained demo state if no handlers passed.
 */
function WalletButton({
  address,
  balance = '0 ZPH',
  connected: connectedProp,
  onConnect,
  onDisconnect,
  size = 'md',
  style,
  ...rest
}) {
  const controlled = connectedProp !== undefined;
  const [demoConnected, setDemoConnected] = React.useState(false);
  const connected = controlled ? connectedProp : demoConnected;
  const addr = address || '8sG1MjujqWKNZKkkGQQdekuMTLJvFdP3hoohyEiUr82t';
  const pad = size === 'sm' ? '8px 14px' : '11px 18px';
  if (!connected) {
    return /*#__PURE__*/React.createElement("button", _extends({
      onClick: () => {
        onConnect ? onConnect() : setDemoConnected(true);
      },
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        background: 'var(--teal)',
        color: '#fff',
        border: '1px solid var(--teal)',
        borderRadius: 'var(--radius-lg)',
        padding: pad,
        fontFamily: 'var(--font-sans)',
        fontWeight: 'var(--fw-medium)',
        fontSize: 'var(--fs-sm)',
        cursor: 'pointer',
        transition: 'background var(--dur-base), transform var(--dur-fast)',
        ...style
      },
      onMouseEnter: e => {
        e.currentTarget.style.background = 'var(--teal-dark)';
        e.currentTarget.style.transform = 'translateY(-1px)';
      },
      onMouseLeave: e => {
        e.currentTarget.style.background = 'var(--teal)';
        e.currentTarget.style.transform = 'none';
      }
    }, rest), /*#__PURE__*/React.createElement("span", {
      style: {
        width: 8,
        height: 8,
        borderRadius: '50%',
        background: '#fff',
        opacity: 0.9
      }
    }), "Connect Wallet");
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    onClick: () => {
      onDisconnect ? onDisconnect() : setDemoConnected(false);
    },
    title: "Click to disconnect",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      background: 'var(--navy)',
      color: '#fff',
      border: '1px solid rgba(29,158,117,0.3)',
      borderRadius: 'var(--radius-pill)',
      padding: pad,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-xs)',
      cursor: 'pointer',
      transition: 'border-color var(--dur-base)',
      ...style
    },
    onMouseEnter: e => e.currentTarget.style.borderColor = 'var(--teal-mid)',
    onMouseLeave: e => e.currentTarget.style.borderColor = 'rgba(29,158,117,0.3)'
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--teal-mid)',
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      color: 'var(--teal-mid)'
    }
  }, trunc(addr)), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 1,
      height: 14,
      background: 'rgba(255,255,255,0.15)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--fw-medium)'
    }
  }, balance));
}
Object.assign(__ds_scope, { WalletButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/crypto/WalletButton.jsx", error: String((e && e.message) || e) }); }

// components/data/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher status badge / tag. Used for roadmap phase states and pills.
 * `tone` maps to the brand's done/active/future status colors.
 */
function Badge({
  tone = 'done',
  dot = false,
  children,
  style,
  ...rest
}) {
  const tones = {
    done: {
      background: 'var(--status-done-bg)',
      color: 'var(--status-done-fg)'
    },
    active: {
      background: 'var(--status-active-bg)',
      color: 'var(--status-active-fg)'
    },
    future: {
      background: 'var(--status-future-bg)',
      color: 'var(--status-future-fg)'
    },
    teal: {
      background: 'var(--teal)',
      color: '#fff'
    },
    navy: {
      background: 'var(--navy)',
      color: '#fff'
    },
    outline: {
      background: 'transparent',
      color: 'var(--teal)',
      boxShadow: 'inset 0 0 0 1px var(--border-default)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      font: 'var(--type-eyebrow)',
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      padding: '4px 10px',
      borderRadius: 'var(--radius-sm)',
      ...tones[tone],
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: '6px',
      height: '6px',
      borderRadius: '50%',
      background: 'currentColor',
      flexShrink: 0
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher content card. Optional accent stripe (top or left), optional
 * hover lift. The brand's feature/problem/link cards all derive from this.
 */
function Card({
  accent = false,
  accentSide = 'top',
  hover = false,
  dark = false,
  children,
  style,
  ...rest
}) {
  const [lifted, setLifted] = React.useState(false);
  const base = {
    position: 'relative',
    background: dark ? 'var(--navy)' : 'var(--surface-card)',
    color: dark ? '#fff' : 'inherit',
    border: dark ? 'none' : '1px solid var(--border-default)',
    borderRadius: 'var(--radius-xl)',
    padding: '32px 28px',
    overflow: 'hidden',
    transition: 'transform var(--dur-fast), box-shadow var(--dur-base), border-color var(--dur-base)',
    transform: hover && lifted ? 'var(--hover-lift)' : 'none',
    boxShadow: hover && lifted ? 'var(--shadow-sm)' : 'none',
    borderColor: hover && lifted ? 'var(--teal)' : dark ? 'none' : 'var(--border-default)',
    ...style
  };
  const stripe = accentSide === 'left' ? {
    top: 0,
    bottom: 0,
    left: 0,
    width: 'var(--border-accent-width)'
  } : {
    top: 0,
    left: 0,
    right: 0,
    height: 'var(--border-accent-width)'
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: base,
    onMouseEnter: () => hover && setLifted(true),
    onMouseLeave: () => hover && setLifted(false)
  }, rest), accent && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      background: 'var(--teal)',
      ...stripe
    }
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Card.jsx", error: String((e && e.message) || e) }); }

// components/data/MintAddress.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher mint-address bar — a navy panel showing a mono blockchain
 * address with a copy button. Mirrors the site's tokenomics mint bar.
 */
function MintAddress({
  address,
  label = 'Mint Address',
  style,
  ...rest
}) {
  const [copied, setCopied] = React.useState(false);
  const copy = () => {
    try {
      navigator.clipboard?.writeText(address);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch (e) {/* noop */}
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--navy)',
      padding: '20px 32px',
      borderRadius: 'var(--radius-lg)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '16px',
      flexWrap: 'wrap',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-3xs)',
      color: 'rgba(255,255,255,0.45)',
      fontWeight: 'var(--fw-semibold)',
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      marginBottom: '4px'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--fs-xs)',
      color: 'var(--teal-mid)',
      letterSpacing: '0.03em',
      wordBreak: 'break-all'
    }
  }, address)), /*#__PURE__*/React.createElement("button", {
    onClick: copy,
    style: {
      background: 'rgba(29,158,117,0.15)',
      border: '1px solid rgba(29,158,117,0.3)',
      color: 'var(--teal-mid)',
      borderRadius: 'var(--radius-md)',
      padding: '8px 16px',
      fontSize: 'var(--fs-xs)',
      cursor: 'pointer',
      fontFamily: 'var(--font-sans)',
      whiteSpace: 'nowrap',
      flexShrink: 0,
      transition: 'background var(--dur-base)'
    },
    onMouseEnter: e => e.currentTarget.style.background = 'rgba(29,158,117,0.25)',
    onMouseLeave: e => e.currentTarget.style.background = 'rgba(29,158,117,0.15)'
  }, copied ? 'Copied ✓' : 'Copy Address'));
}
Object.assign(__ds_scope, { MintAddress });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/MintAddress.jsx", error: String((e && e.message) || e) }); }

// components/data/StatCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher stat card — large serif value over an all-caps label and a
 * teal sub-line. Used in the hero stat cluster.
 */
function StatCard({
  value,
  label,
  sub,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--surface-card)',
      padding: '28px 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-display-md)',
      color: 'var(--navy)',
      lineHeight: 1
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-2xs)',
      color: 'var(--text-muted)',
      fontWeight: 'var(--fw-medium)',
      textTransform: 'uppercase',
      letterSpacing: '0.06em'
    }
  }, label), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-3xs)',
      color: 'var(--teal)',
      fontWeight: 'var(--fw-medium)'
    }
  }, sub));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/data/Table.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher data table. Hairline rows, all-caps muted header, optional row
 * hover/click, and an optional navy header treatment. Columns drive
 * alignment and custom cell rendering.
 */
function Table({
  columns = [],
  rows = [],
  onRowClick,
  headerStyle = 'plain',
  dense = false,
  style,
  ...rest
}) {
  const navy = headerStyle === 'navy';
  const cellPadY = dense ? 9 : 13;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      overflowX: 'auto',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 'var(--fs-xs)',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: navy ? {
      background: 'var(--navy)'
    } : undefined
  }, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      padding: '11px 14px',
      whiteSpace: 'nowrap',
      font: 'var(--type-eyebrow)',
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: navy ? 'rgba(255,255,255,0.6)' : 'var(--text-muted)',
      borderBottom: navy ? 'none' : '1px solid var(--border-default)',
      borderTopLeftRadius: navy && c === columns[0] ? 'var(--radius-md)' : 0,
      borderTopRightRadius: navy && c === columns[columns.length - 1] ? 'var(--radius-md)' : 0
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    onClick: onRowClick ? () => onRowClick(r, i) : undefined,
    style: {
      cursor: onRowClick ? 'pointer' : 'default',
      transition: 'background var(--dur-fast)'
    },
    onMouseEnter: e => onRowClick && (e.currentTarget.style.background = 'var(--surface-tint, var(--teal-light))'),
    onMouseLeave: e => onRowClick && (e.currentTarget.style.background = 'transparent')
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      padding: `${cellPadY}px 14px`,
      color: 'var(--text-body)',
      whiteSpace: c.wrap ? 'normal' : 'nowrap',
      borderBottom: i < rows.length - 1 ? '1px solid var(--border-default)' : 'none'
    }
  }, c.render ? c.render(r, i) : r[c.key])))))));
}
Object.assign(__ds_scope, { Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Table.jsx", error: String((e && e.message) || e) }); }

// components/disclosure/Accordion.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher accordion / disclosure list. Mirrors the site's FAQ pattern:
 * bordered rows, teal "+" well that rotates to "×" when open.
 */
function Accordion({
  items = [],
  defaultOpen = 0,
  allowMultiple = false,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(allowMultiple ? defaultOpen === -1 ? [] : [defaultOpen] : defaultOpen);
  const isOpen = i => allowMultiple ? open.includes(i) : open === i;
  const toggle = i => {
    if (allowMultiple) {
      setOpen(cur => cur.includes(i) ? cur.filter(x => x !== i) : [...cur, i]);
    } else {
      setOpen(cur => cur === i ? -1 : i);
    }
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      ...style
    }
  }, rest), items.map((it, i) => {
    const o = isOpen(i);
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        background: 'var(--surface-card)',
        border: '1px solid var(--border-default)',
        borderRadius: 'var(--radius-lg)',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => toggle(i),
      "aria-expanded": o,
      style: {
        width: '100%',
        background: 'none',
        border: 'none',
        padding: '22px 28px',
        textAlign: 'left',
        fontSize: 'var(--fs-body)',
        fontWeight: 'var(--fw-medium)',
        color: 'var(--navy)',
        cursor: 'pointer',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: 16,
        fontFamily: 'var(--font-sans)',
        transition: 'background var(--dur-fast)'
      },
      onMouseEnter: e => e.currentTarget.style.background = 'var(--bg)',
      onMouseLeave: e => e.currentTarget.style.background = 'none'
    }, it.q, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 24,
        height: 24,
        borderRadius: '50%',
        background: 'var(--teal-light)',
        color: 'var(--teal)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 16,
        flexShrink: 0,
        lineHeight: 1,
        transition: 'transform var(--dur-base)',
        transform: o ? 'rotate(45deg)' : 'none'
      }
    }, "+")), o && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '0 28px 22px',
        fontSize: 'var(--fs-sm)',
        color: 'var(--slate)',
        lineHeight: 1.7
      }
    }, it.a));
  }));
}
Object.assign(__ds_scope, { Accordion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/disclosure/Accordion.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  success: {
    dot: 'var(--teal)',
    icon: '✓',
    tint: 'var(--teal-light)',
    iconColor: 'var(--teal)'
  },
  info: {
    dot: 'var(--navy)',
    icon: 'i',
    tint: '#EFF4FB',
    iconColor: 'var(--navy)'
  },
  warn: {
    dot: '#F59E0B',
    icon: '!',
    tint: 'var(--amber-bg)',
    iconColor: 'var(--amber-fg)'
  },
  error: {
    dot: '#DC2626',
    icon: '×',
    tint: '#FEF2F2',
    iconColor: '#DC2626'
  }
};

/**
 * Zypher toast — a white card with a soft shadow, a tinted status icon
 * well, title/message and a dismiss control. Use directly, or drive a
 * stack with ToastViewport + useToast.
 */
function Toast({
  tone = 'success',
  title,
  message,
  icon,
  onClose,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.success;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12,
      width: 360,
      maxWidth: '90vw',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-lg)',
      padding: '14px 16px',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 28,
      height: 28,
      borderRadius: 'var(--radius-md)',
      background: t.tint,
      color: t.iconColor,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0,
      fontWeight: 700,
      fontSize: 15
    }
  }, icon || t.icon), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-sm)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--navy)',
      marginBottom: message ? 2 : 0
    }
  }, title), message && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-xs)',
      color: 'var(--slate)',
      lineHeight: 1.5
    }
  }, message)), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Dismiss",
    style: {
      background: 'none',
      border: 'none',
      color: 'var(--muted)',
      cursor: 'pointer',
      fontSize: 18,
      lineHeight: 1,
      padding: 0,
      flexShrink: 0
    }
  }, "\xD7"));
}

/** Fixed-position stack of toasts. */
function ToastViewport({
  toasts = [],
  onDismiss,
  position = 'bottom-right'
}) {
  const pos = {
    'bottom-right': {
      bottom: 24,
      right: 24,
      alignItems: 'flex-end'
    },
    'bottom-left': {
      bottom: 24,
      left: 24,
      alignItems: 'flex-start'
    },
    'top-right': {
      top: 24,
      right: 24,
      alignItems: 'flex-end'
    },
    'top-center': {
      top: 24,
      left: '50%',
      transform: 'translateX(-50%)',
      alignItems: 'center'
    }
  }[position];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      zIndex: 'var(--z-overlay)',
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      ...pos
    }
  }, toasts.map(t => /*#__PURE__*/React.createElement(Toast, _extends({
    key: t.id
  }, t, {
    onClose: onDismiss ? () => onDismiss(t.id) : undefined
  }))));
}

/** Minimal toast queue hook: { toasts, notify, dismiss }. */
function useToast(autoDismiss = 3500) {
  const [toasts, setToasts] = React.useState([]);
  const dismiss = React.useCallback(id => setToasts(cur => cur.filter(t => t.id !== id)), []);
  const notify = React.useCallback(toast => {
    const id = Math.random().toString(36).slice(2);
    setToasts(cur => [...cur, {
      id,
      ...toast
    }]);
    if (autoDismiss) setTimeout(() => dismiss(id), autoDismiss);
    return id;
  }, [autoDismiss, dismiss]);
  return {
    toasts,
    notify,
    dismiss
  };
}
Object.assign(__ds_scope, { Toast, ToastViewport, useToast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher primary action button. Teal fill by default; secondary is a
 * bordered white pill; ghost is text-only. Lifts 1px on hover.
 */
function Button({
  variant = 'primary',
  size = 'md',
  href,
  trailingIcon,
  leadingIcon,
  disabled = false,
  children,
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '8px 16px',
      fontSize: '13px'
    },
    md: {
      padding: '13px 24px',
      fontSize: '15px'
    },
    lg: {
      padding: '16px 30px',
      fontSize: '16px'
    }
  };
  const variants = {
    primary: {
      background: 'var(--teal)',
      color: '#fff',
      border: '1px solid var(--teal)'
    },
    secondary: {
      background: 'var(--surface-card)',
      color: 'var(--navy)',
      border: '1px solid var(--border-default)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--teal)',
      border: '1px solid transparent'
    },
    dark: {
      background: 'rgba(29,158,117,0.15)',
      color: 'var(--teal-mid)',
      border: '1px solid rgba(29,158,117,0.3)'
    }
  };
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    borderRadius: 'var(--radius-lg)',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--fw-medium)',
    lineHeight: 1,
    textDecoration: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    transition: 'background var(--dur-base), border-color var(--dur-base), transform var(--dur-fast)',
    whiteSpace: 'nowrap',
    ...sizes[size],
    ...variants[variant],
    ...style
  };
  const onEnter = e => {
    if (disabled) return;
    e.currentTarget.style.transform = 'translateY(-1px)';
    if (variant === 'primary') e.currentTarget.style.background = 'var(--teal-dark)';
    if (variant === 'secondary') {
      e.currentTarget.style.borderColor = 'var(--teal)';
      e.currentTarget.style.color = 'var(--teal)';
    }
    if (variant === 'ghost') e.currentTarget.style.background = 'var(--teal-light)';
    if (variant === 'dark') e.currentTarget.style.background = 'rgba(29,158,117,0.25)';
  };
  const onLeave = e => {
    if (disabled) return;
    e.currentTarget.style.transform = 'none';
    e.currentTarget.style.background = variants[variant].background;
    e.currentTarget.style.borderColor = variants[variant].border.split(' ').pop();
    if (variant === 'secondary') e.currentTarget.style.color = 'var(--navy)';
  };
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, leadingIcon, children, trailingIcon);
  const Tag = href ? 'a' : 'button';
  const tagProps = href ? {
    href
  } : {
    disabled
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: base,
    onMouseEnter: onEnter,
    onMouseLeave: onLeave
  }, tagProps, rest), content);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher text input with optional label. Cool border, teal focus ring.
 */
function Input({
  label,
  hint,
  error,
  prefix,
  id,
  style,
  ...rest
}) {
  const inputId = id || (label ? `zy-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  const wrap = {
    display: 'flex',
    flexDirection: 'column',
    gap: '6px',
    fontFamily: 'var(--font-sans)'
  };
  const labelStyle = {
    font: 'var(--type-label)',
    color: 'var(--text-strong)',
    fontWeight: 'var(--fw-semibold)'
  };
  const field = {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    background: 'var(--surface-card)',
    border: `1px solid ${error ? '#DC2626' : 'var(--border-default)'}`,
    borderRadius: 'var(--radius-md)',
    padding: '0 14px',
    transition: 'border-color var(--dur-base), box-shadow var(--dur-base)'
  };
  const input = {
    flex: 1,
    border: 'none',
    outline: 'none',
    background: 'transparent',
    padding: '11px 0',
    fontSize: 'var(--fs-sm)',
    color: 'var(--text-strong)',
    fontFamily: 'var(--font-sans)',
    ...style
  };
  return /*#__PURE__*/React.createElement("label", {
    style: wrap,
    htmlFor: inputId
  }, label && /*#__PURE__*/React.createElement("span", {
    style: labelStyle
  }, label), /*#__PURE__*/React.createElement("span", {
    style: field,
    onFocus: e => {
      e.currentTarget.style.borderColor = 'var(--teal)';
      e.currentTarget.style.boxShadow = '0 0 0 3px var(--focus-ring)';
    },
    onBlur: e => {
      e.currentTarget.style.borderColor = error ? '#DC2626' : 'var(--border-default)';
      e.currentTarget.style.boxShadow = 'none';
    }
  }, prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 'var(--fs-sm)'
    }
  }, prefix), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    style: input
  }, rest))), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-2xs)',
      color: error ? '#DC2626' : 'var(--text-muted)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/layout/Callout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher callout — a tinted box with a left accent bar for inline notes.
 * `info` = teal, `warn` = amber. Mirrors the "how to buy" callouts.
 */
function Callout({
  tone = 'info',
  icon,
  children,
  style,
  ...rest
}) {
  const tones = {
    info: {
      background: 'var(--teal-light)',
      border: 'var(--teal)',
      color: 'var(--teal-dark)'
    },
    warn: {
      background: 'var(--amber-bg)',
      border: '#F59E0B',
      color: '#92400E'
    }
  };
  const t = tones[tone];
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '10px',
      background: t.background,
      borderLeft: `3px solid ${t.border}`,
      borderRadius: '0 var(--radius-lg) var(--radius-lg) 0',
      padding: '12px 16px',
      fontSize: 'var(--fs-xs)',
      color: t.color,
      lineHeight: 1.6,
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      flexShrink: 0,
      fontSize: '15px',
      lineHeight: 1.4
    }
  }, icon), /*#__PURE__*/React.createElement("div", null, children));
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Callout.jsx", error: String((e && e.message) || e) }); }

// components/layout/SectionHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher section heading: teal eyebrow label, large serif title, light
 * lede subtitle. The standard opener for every page section.
 */
function SectionHeading({
  label,
  title,
  sub,
  align = 'left',
  onDark = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      textAlign: align,
      ...style
    }
  }, rest), label && /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-eyebrow)',
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--teal)',
      marginBottom: '12px'
    }
  }, label), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-display-lg)',
      color: onDark ? '#fff' : 'var(--navy)',
      lineHeight: 1.15,
      letterSpacing: '-0.5px',
      margin: 0,
      fontWeight: 400
    }
  }, title), sub && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-lede)',
      color: onDark ? 'rgba(255,255,255,0.6)' : 'var(--slate)',
      fontWeight: 'var(--fw-light)',
      maxWidth: '560px',
      lineHeight: 1.75,
      marginTop: '16px',
      marginLeft: align === 'center' ? 'auto' : 0,
      marginRight: align === 'center' ? 'auto' : 0,
      marginBottom: 0
    }
  }, sub));
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/layout/Stepper.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher process stepper. Horizontal = the "How it works" numbered row
 * (teal circles on a connector line). Vertical = the "How to buy" flow
 * (numbered nodes joined by a vertical rule). Numerals use the serif face.
 */
function Stepper({
  steps = [],
  orientation = 'horizontal',
  style,
  ...rest
}) {
  const Num = ({
    n
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      width: orientation === 'horizontal' ? 56 : 48,
      height: orientation === 'horizontal' ? 56 : 48,
      background: 'var(--teal)',
      borderRadius: '50%',
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-display)',
      fontSize: 20,
      flexShrink: 0,
      zIndex: 1
    }
  }, n);
  if (orientation === 'vertical') {
    return /*#__PURE__*/React.createElement("div", _extends({
      style: {
        display: 'flex',
        flexDirection: 'column',
        ...style
      }
    }, rest), steps.map((s, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 32,
        paddingBottom: i < steps.length - 1 ? 40 : 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(Num, {
      n: i + 1
    }), i < steps.length - 1 && /*#__PURE__*/React.createElement("div", {
      style: {
        width: 2,
        flex: 1,
        background: 'var(--border)',
        margin: '8px 0',
        minHeight: 40
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        paddingTop: 10,
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 18,
        fontWeight: 600,
        color: 'var(--navy)',
        marginBottom: 10,
        lineHeight: 1.3
      }
    }, s.title), s.desc && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        color: 'var(--slate)',
        lineHeight: 1.75
      }
    }, s.desc), s.children))));
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${steps.length}, 1fr)`,
      position: 'relative',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 28,
      left: '10%',
      right: '10%',
      height: 1,
      background: 'var(--border)',
      zIndex: 0
    }
  }), steps.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      padding: '0 16px',
      position: 'relative',
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Num, {
    n: i + 1
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: 'var(--navy)',
      marginBottom: 8
    }
  }, s.title), s.desc && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--slate)',
      lineHeight: 1.6
    }
  }, s.desc))));
}
Object.assign(__ds_scope, { Stepper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Stepper.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Menu.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher dropdown menu. A trigger element + a popover list. Click to open,
 * click-outside / Escape to close. Items support icons, dividers and a
 * `danger` tone. Align the popover left (default) or right of the trigger.
 */
function Menu({
  trigger,
  items = [],
  align = 'left',
  width = 200,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const onDoc = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    const onKey = e => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);
  return /*#__PURE__*/React.createElement("span", _extends({
    ref: ref,
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => setOpen(o => !o),
    style: {
      display: 'inline-flex',
      cursor: 'pointer'
    }
  }, trigger), open && /*#__PURE__*/React.createElement("div", {
    role: "menu",
    style: {
      position: 'absolute',
      top: '100%',
      [align]: 0,
      marginTop: 8,
      width,
      zIndex: 'var(--z-overlay, 200)',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-lg)',
      padding: 6,
      fontFamily: 'var(--font-sans)'
    }
  }, items.map((it, i) => it.divider ? /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      height: 1,
      background: 'var(--border-default)',
      margin: '6px 0'
    }
  }) : /*#__PURE__*/React.createElement("button", {
    key: i,
    role: "menuitem",
    disabled: it.disabled,
    onClick: () => {
      setOpen(false);
      it.onClick && it.onClick();
    },
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '9px 11px',
      borderRadius: 'var(--radius-md)',
      border: 'none',
      background: 'transparent',
      cursor: it.disabled ? 'not-allowed' : 'pointer',
      textAlign: 'left',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-sm)',
      fontWeight: 'var(--fw-medium)',
      color: it.disabled ? 'var(--text-muted)' : it.danger ? '#DC2626' : 'var(--text-body)',
      opacity: it.disabled ? 0.6 : 1
    },
    onMouseEnter: e => {
      if (!it.disabled) e.currentTarget.style.background = it.danger ? '#FEF2F2' : 'var(--surface-tint, var(--teal-light))';
    },
    onMouseLeave: e => e.currentTarget.style.background = 'transparent'
  }, it.icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flexShrink: 0
    }
  }, it.icon), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, it.label), it.shortcut && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)'
    }
  }, it.shortcut)))));
}
Object.assign(__ds_scope, { Menu });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Menu.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher tabs. `underline` (default) = a row of labels with a teal active
 * underline; `segment` = a pill segmented control on a tinted track.
 * Controlled (pass value + onChange) or uncontrolled (defaultValue).
 */
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onChange,
  variant = 'underline',
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultValue ?? (tabs[0] && tabs[0].id));
  const active = value !== undefined ? value : internal;
  const select = id => {
    if (value === undefined) setInternal(id);
    onChange && onChange(id);
  };
  if (variant === 'segment') {
    return /*#__PURE__*/React.createElement("div", _extends({
      role: "tablist",
      style: {
        display: 'inline-flex',
        gap: 4,
        background: 'var(--surface-tint, var(--teal-light))',
        borderRadius: 'var(--radius-lg)',
        padding: 3,
        ...style
      }
    }, rest), tabs.map(t => {
      const on = active === t.id;
      return /*#__PURE__*/React.createElement("button", {
        key: t.id,
        role: "tab",
        "aria-selected": on,
        onClick: () => select(t.id),
        style: {
          border: 'none',
          cursor: 'pointer',
          padding: '7px 16px',
          borderRadius: 'var(--radius-md)',
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--fs-xs)',
          fontWeight: 'var(--fw-semibold)',
          background: on ? 'var(--surface-card)' : 'transparent',
          color: on ? 'var(--color-primary)' : 'var(--text-muted)',
          boxShadow: on ? 'var(--shadow-xs)' : 'none',
          transition: 'color var(--dur-fast)',
          display: 'inline-flex',
          alignItems: 'center',
          gap: 7
        }
      }, t.icon, t.label, t.count != null && /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 11,
          opacity: 0.7
        }
      }, t.count));
    }));
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: 'flex',
      gap: 4,
      borderBottom: '1px solid var(--border-default)',
      ...style
    }
  }, rest), tabs.map(t => {
    const on = active === t.id;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      role: "tab",
      "aria-selected": on,
      onClick: () => select(t.id),
      style: {
        border: 'none',
        background: 'none',
        cursor: 'pointer',
        padding: '12px 14px',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-sm)',
        fontWeight: on ? 'var(--fw-semibold)' : 'var(--fw-medium)',
        color: on ? 'var(--color-primary)' : 'var(--text-muted)',
        position: 'relative',
        marginBottom: -1,
        borderBottom: `2px solid ${on ? 'var(--color-primary)' : 'transparent'}`,
        transition: 'color var(--dur-fast)',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8
      }
    }, t.icon, t.label, t.count != null && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 600,
        color: on ? 'var(--color-primary)' : 'var(--text-muted)',
        background: on ? 'var(--color-primary-tint, var(--teal-light))' : 'var(--surface-tint, var(--bg))',
        borderRadius: 999,
        padding: '1px 7px'
      }
    }, t.count));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher modal dialog. Backdrop blur + centered card. Controlled via
 * `open` + `onClose`. Closes on backdrop click and Escape. Compose the
 * footer with Button(s).
 */
function Dialog({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  width = 460,
  style,
  ...rest
}) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = e => {
      if (e.key === 'Escape') onClose && onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: e => {
      if (e.target === e.currentTarget) onClose && onClose();
    },
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 'var(--z-overlay, 200)',
      background: 'rgba(12,35,64,0.45)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", _extends({
    role: "dialog",
    "aria-modal": "true",
    style: {
      width,
      maxWidth: '100%',
      maxHeight: '90vh',
      overflowY: 'auto',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-2xl)',
      boxShadow: 'var(--shadow-lg)',
      padding: 28,
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, title && /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-display-sm)',
      color: 'var(--text-strong)',
      margin: 0,
      fontWeight: 400,
      lineHeight: 1.2
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-sm)',
      color: 'var(--text-muted)',
      margin: '8px 0 0',
      lineHeight: 1.55
    }
  }, description)), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Close",
    style: {
      background: 'none',
      border: 'none',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      fontSize: 22,
      lineHeight: 1,
      padding: 0,
      flexShrink: 0
    }
  }, "\xD7")), children && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: title || description ? 20 : 0,
      fontSize: 'var(--fs-sm)',
      color: 'var(--text-body)',
      lineHeight: 1.6
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 10,
      marginTop: 24
    }
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zypher tooltip. Wraps a trigger; shows a small navy bubble on hover/focus.
 * Good for the brand's technical terms (NPI, SPL, TGE). Position: top
 * (default), bottom, left, right.
 */
function Tooltip({
  label,
  position = 'top',
  delay = 80,
  children,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const timer = React.useRef(null);
  const show = () => {
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setOpen(true), delay);
  };
  const hide = () => {
    clearTimeout(timer.current);
    setOpen(false);
  };
  const pos = {
    top: {
      bottom: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginBottom: 8
    },
    bottom: {
      top: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginTop: 8
    },
    left: {
      right: '100%',
      top: '50%',
      transform: 'translateY(-50%)',
      marginRight: 8
    },
    right: {
      left: '100%',
      top: '50%',
      transform: 'translateY(-50%)',
      marginLeft: 8
    }
  }[position];
  const arrowBase = {
    position: 'absolute',
    width: 7,
    height: 7,
    background: 'var(--navy)',
    transform: 'rotate(45deg)'
  };
  const arrow = {
    top: {
      ...arrowBase,
      bottom: -3,
      left: '50%',
      marginLeft: -3.5
    },
    bottom: {
      ...arrowBase,
      top: -3,
      left: '50%',
      marginLeft: -3.5
    },
    left: {
      ...arrowBase,
      right: -3,
      top: '50%',
      marginTop: -3.5
    },
    right: {
      ...arrowBase,
      left: -3,
      top: '50%',
      marginTop: -3.5
    }
  }[position];
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    },
    onMouseEnter: show,
    onMouseLeave: hide,
    onFocus: show,
    onBlur: hide
  }, rest), children, /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      zIndex: 'var(--z-overlay, 200)',
      ...pos,
      background: 'var(--navy)',
      color: '#fff',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-2xs)',
      fontWeight: 'var(--fw-medium)',
      lineHeight: 1.45,
      padding: '7px 11px',
      borderRadius: 'var(--radius-md)',
      whiteSpace: 'nowrap',
      maxWidth: 240,
      boxShadow: 'var(--shadow-md)',
      pointerEvents: 'none',
      opacity: open ? 1 : 0,
      visibility: open ? 'visible' : 'hidden',
      transition: 'opacity var(--dur-fast)'
    }
  }, label, /*#__PURE__*/React.createElement("span", {
    style: arrow
  })));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Tooltip.jsx", error: String((e && e.message) || e) }); }

// ui_kits/zypher-app/app.jsx
try { (() => {
/* Zypher Holder Dashboard — App root: routing, theme, toasts. */
const {
  ToastViewport: AppToastViewport
} = window.ZypherDesignSystem_7d1dbd;
function useToast(autoDismiss = 3800) {
  const [toasts, setToasts] = React.useState([]);
  const dismiss = React.useCallback(id => setToasts(c => c.filter(t => t.id !== id)), []);
  const notify = React.useCallback(t => {
    const id = Math.random().toString(36).slice(2);
    setToasts(c => [...c, {
      id,
      ...t
    }]);
    if (autoDismiss) setTimeout(() => dismiss(id), autoDismiss);
    return id;
  }, [autoDismiss, dismiss]);
  return {
    toasts,
    notify,
    dismiss
  };
}
const TITLES = {
  overview: ['Overview', 'Good morning — here\u2019s your ZPH at a glance'],
  wallet: ['Wallet', 'Manage your ZPH balance and transactions'],
  staking: ['Staking', 'Earn rewards by securing the Zypher network'],
  governance: ['Governance', 'Shape the protocol with your voting power'],
  providers: ['Providers', 'Search the verified on-chain provider registry'],
  settings: ['Settings', 'Account, wallets and preferences']
};
function App() {
  const [theme, setThemeState] = React.useState(() => {
    try {
      return localStorage.getItem('zy-app-theme') || 'light';
    } catch (e) {
      return 'light';
    }
  });
  const [screen, setScreen] = React.useState('overview');
  const [provider, setProvider] = React.useState(null);
  const {
    toasts,
    notify,
    dismiss
  } = useToast();
  const setTheme = React.useCallback(t => {
    setThemeState(t);
    try {
      localStorage.setItem('zy-app-theme', t);
    } catch (e) {}
  }, []);
  const toggleTheme = () => setTheme(theme === 'dark' ? 'light' : 'dark');
  const nav = id => {
    setProvider(null);
    setScreen(id);
  };
  let body;
  if (screen === 'overview') body = /*#__PURE__*/React.createElement(Overview, {
    onNav: nav
  });else if (screen === 'wallet') body = /*#__PURE__*/React.createElement(Wallet, {
    notify: notify
  });else if (screen === 'staking') body = /*#__PURE__*/React.createElement(Staking, {
    notify: notify
  });else if (screen === 'governance') body = /*#__PURE__*/React.createElement(Governance, {
    notify: notify
  });else if (screen === 'providers') body = provider ? /*#__PURE__*/React.createElement(ProviderDetail, {
    provider: provider,
    onBack: () => setProvider(null),
    notify: notify
  }) : /*#__PURE__*/React.createElement(Providers, {
    onOpen: setProvider
  });else if (screen === 'settings') body = /*#__PURE__*/React.createElement(Settings, {
    theme: theme,
    setTheme: setTheme,
    notify: notify
  });
  const [title, subtitle] = provider && screen === 'providers' ? ['Provider Record', 'Verified on-chain provider detail'] : TITLES[screen] || ['', ''];
  return /*#__PURE__*/React.createElement("div", {
    "data-theme": theme,
    className: "zy-app",
    style: {
      display: 'flex',
      minHeight: '100vh',
      background: 'var(--surface-page)',
      color: 'var(--text-strong)',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement(Sidebar, {
    active: screen,
    onNav: nav
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(Topbar, {
    title: title,
    subtitle: subtitle,
    theme: theme,
    onToggleTheme: toggleTheme,
    onNotify: () => notify({
      tone: 'info',
      title: '2 new notifications',
      message: 'Staking reward received · ZIP-016 is now open for voting.'
    })
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      padding: 32
    },
    className: "zy-main"
  }, body)), /*#__PURE__*/React.createElement(AppToastViewport, {
    toasts: toasts,
    onDismiss: dismiss,
    position: "bottom-right"
  }));
}
window.ZypherApp = App;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/zypher-app/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/zypher-app/charts.jsx
try { (() => {
/* Zypher app — dependency-free SVG charts. Theme-aware via CSS tokens.
   Exported to window for the app screens. */

function _path(points) {
  return points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
}

/* Smooth area chart with gradient fill. data = array of numbers. */
function AreaChart({
  data = [],
  height = 220,
  stroke = 'var(--teal)',
  fill = 'var(--teal)',
  showAxis = true
}) {
  const w = 800,
    h = height,
    padX = 8,
    padY = 16;
  const max = Math.max(...data) * 1.08,
    min = Math.min(...data) * 0.92;
  const span = max - min || 1;
  const pts = data.map((d, i) => [padX + i / (data.length - 1) * (w - padX * 2), padY + (1 - (d - min) / span) * (h - padY * 2)]);
  const id = React.useMemo(() => 'ag' + Math.random().toString(36).slice(2, 7), []);
  const line = _path(pts);
  const area = `${line} L ${pts[pts.length - 1][0].toFixed(1)} ${h} L ${pts[0][0].toFixed(1)} ${h} Z`;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${w} ${h}`,
    preserveAspectRatio: "none",
    style: {
      width: '100%',
      height,
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: id,
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: fill,
    stopOpacity: "0.28"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: fill,
    stopOpacity: "0"
  }))), showAxis && [0.25, 0.5, 0.75].map(g => /*#__PURE__*/React.createElement("line", {
    key: g,
    x1: padX,
    x2: w - padX,
    y1: padY + g * (h - padY * 2),
    y2: padY + g * (h - padY * 2),
    stroke: "var(--border-default)",
    strokeWidth: "1",
    strokeDasharray: "3 5"
  })), /*#__PURE__*/React.createElement("path", {
    d: area,
    fill: `url(#${id})`
  }), /*#__PURE__*/React.createElement("path", {
    d: line,
    fill: "none",
    stroke: stroke,
    strokeWidth: "2.5",
    strokeLinejoin: "round",
    strokeLinecap: "round"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: pts[pts.length - 1][0],
    cy: pts[pts.length - 1][1],
    r: "4.5",
    fill: stroke
  }));
}

/* Tiny inline sparkline. */
function Sparkline({
  data = [],
  width = 88,
  height = 28,
  color = 'var(--teal)',
  up = true
}) {
  const max = Math.max(...data),
    min = Math.min(...data),
    span = max - min || 1;
  const pts = data.map((d, i) => [i / (data.length - 1) * width, height - 2 - (d - min) / span * (height - 4)]);
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${width} ${height}`,
    style: {
      width,
      height,
      display: 'block',
      overflow: 'visible'
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: _path(pts),
    fill: "none",
    stroke: up ? color : '#DC2626',
    strokeWidth: "2",
    strokeLinejoin: "round",
    strokeLinecap: "round"
  }));
}

/* Donut for allocation. segments = [{label, value, color}]. */
function Donut({
  segments = [],
  size = 140,
  thickness = 18,
  centerLabel,
  centerSub
}) {
  const r = (size - thickness) / 2,
    c = size / 2,
    circ = 2 * Math.PI * r;
  const total = segments.reduce((s, x) => s + x.value, 0) || 1;
  let offset = 0;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: size,
      height: size
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${size} ${size}`,
    style: {
      width: size,
      height: size,
      transform: 'rotate(-90deg)'
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: c,
    cy: c,
    r: r,
    fill: "none",
    stroke: "var(--border-default)",
    strokeWidth: thickness
  }), segments.map((s, i) => {
    const len = s.value / total * circ;
    const el = /*#__PURE__*/React.createElement("circle", {
      key: i,
      cx: c,
      cy: c,
      r: r,
      fill: "none",
      stroke: s.color,
      strokeWidth: thickness,
      strokeDasharray: `${len} ${circ - len}`,
      strokeDashoffset: -offset,
      strokeLinecap: "butt"
    });
    offset += len;
    return el;
  })), centerLabel && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 24,
      color: 'var(--text-strong)',
      lineHeight: 1
    }
  }, centerLabel), centerSub && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      marginTop: 3
    }
  }, centerSub)));
}

/* Horizontal vote/progress bar. */
function VoteBar({
  value = 0,
  max = 100,
  color = 'var(--teal)',
  height = 8
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--border-default)',
      borderRadius: 999,
      height,
      overflow: 'hidden',
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${Math.min(100, value / max * 100)}%`,
      background: color,
      height: '100%',
      borderRadius: 999,
      transition: 'width var(--dur-slow)'
    }
  }));
}

/* Mini vertical bars (e.g. weekly query-fee usage). */
function BarMini({
  data = [],
  height = 64,
  color = 'var(--teal)'
}) {
  const max = Math.max(...data) || 1;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 6,
      height
    }
  }, data.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    title: String(d),
    style: {
      flex: 1,
      height: `${d / max * 100}%`,
      minHeight: 3,
      background: i === data.length - 1 ? color : 'var(--color-primary-tint)',
      borderRadius: 3
    }
  })));
}
Object.assign(window, {
  AreaChart,
  Sparkline,
  Donut,
  VoteBar,
  BarMini
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/zypher-app/charts.jsx", error: String((e && e.message) || e) }); }

// ui_kits/zypher-app/screens-a.jsx
try { (() => {
/* Zypher Holder Dashboard — shared screen helpers + Overview + Wallet. */
const {
  Button: AppButton,
  Badge: AppBadge,
  MintAddress
} = window.ZypherDesignSystem_7d1dbd;

/* ---------- shared bits ---------- */
function StatTile({
  label,
  value,
  sub,
  change,
  up = true,
  spark,
  icon
}) {
  return /*#__PURE__*/React.createElement(Panel, {
    pad: 20,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, label), icon && /*#__PURE__*/React.createElement(IconWell, {
    name: icon,
    size: 32
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 30,
      color: 'var(--text-strong)',
      lineHeight: 1
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, change != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: up ? 'var(--teal)' : '#DC2626',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: up ? 'trending-up' : 'trending-down',
    size: 13
  }), " ", change), sub && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, sub)), spark && /*#__PURE__*/React.createElement(Sparkline, {
    data: spark,
    up: up
  })));
}
function StatusPill({
  status
}) {
  const map = {
    confirmed: ['done', 'Confirmed'],
    anchored: ['done', 'Anchored'],
    active: ['done', 'Active'],
    pending: ['active', 'Pending'],
    voting: ['active', 'Voting'],
    passed: ['done', 'Passed'],
    rejected: ['future', 'Rejected'],
    failed: ['future', 'Failed'],
    stale: ['future', 'Re-verify']
  };
  const [tone, label] = map[status] || ['future', status];
  return /*#__PURE__*/React.createElement(AppBadge, {
    tone: tone
  }, label);
}
function DataTable({
  columns,
  rows,
  onRowClick
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      overflowX: 'auto'
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      padding: '10px 14px',
      font: 'var(--type-eyebrow)',
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      borderBottom: '1px solid var(--border-default)',
      whiteSpace: 'nowrap'
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    onClick: onRowClick ? () => onRowClick(r) : undefined,
    style: {
      cursor: onRowClick ? 'pointer' : 'default',
      transition: 'background var(--dur-fast)'
    },
    onMouseEnter: e => onRowClick && (e.currentTarget.style.background = 'var(--surface-tint)'),
    onMouseLeave: e => onRowClick && (e.currentTarget.style.background = 'transparent')
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      padding: '13px 14px',
      color: 'var(--text-body)',
      borderBottom: i < rows.length - 1 ? '1px solid var(--border-default)' : 'none',
      whiteSpace: c.wrap ? 'normal' : 'nowrap'
    }
  }, c.render ? c.render(r) : r[c.key])))))));
}
function TxIcon({
  type
}) {
  const m = {
    send: 'arrow-up-right',
    receive: 'arrow-down-left',
    stake: 'coins',
    reward: 'gift',
    query: 'search',
    vote: 'vote'
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 8,
      background: 'var(--surface-tint)',
      color: 'var(--color-primary)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: m[type] || 'circle',
    size: 15
  }));
}
function SectionTitle({
  children,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 20,
      color: 'var(--text-strong)',
      margin: 0,
      fontWeight: 400
    }
  }, children), action);
}

/* timeframe pills */
function Timeframe({
  value,
  onChange
}) {
  const opts = ['24H', '7D', '30D', '1Y'];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4,
      background: 'var(--surface-tint)',
      borderRadius: 8,
      padding: 3
    }
  }, opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o,
    onClick: () => onChange(o),
    style: {
      border: 'none',
      cursor: 'pointer',
      padding: '5px 12px',
      borderRadius: 6,
      fontFamily: 'var(--font-sans)',
      fontSize: 12,
      fontWeight: 600,
      background: value === o ? 'var(--surface-card)' : 'transparent',
      color: value === o ? 'var(--color-primary)' : 'var(--text-muted)',
      boxShadow: value === o ? 'var(--shadow-xs)' : 'none'
    }
  }, o)));
}

/* ---------- OVERVIEW ---------- */
const SERIES = {
  '24H': [41, 41.4, 40.9, 41.8, 42.6, 42.1, 43, 43.8, 43.4, 44.2, 45.1, 44.8],
  '7D': [38, 39.5, 39, 41, 42.5, 41.8, 44.8],
  '30D': [31, 33, 32, 35, 34, 37, 39, 38, 41, 40, 43, 44.8],
  '1Y': [12, 16, 14, 19, 24, 22, 28, 31, 29, 36, 41, 44.8]
};
function Overview({
  onNav
}) {
  const [tf, setTf] = React.useState('30D');
  const alloc = [{
    label: 'Liquid',
    value: 12500,
    color: 'var(--teal)'
  }, {
    label: 'Staked',
    value: 28000,
    color: 'var(--navy-mid)'
  }, {
    label: 'Gov-locked',
    value: 5000,
    color: 'var(--teal-bright)'
  }];
  const activity = [{
    type: 'reward',
    detail: 'Staking reward',
    amount: '+182.4 ZPH',
    status: 'confirmed',
    time: '2m ago',
    pos: true
  }, {
    type: 'query',
    detail: 'Provider query fee',
    amount: '-1.20 ZPH',
    status: 'confirmed',
    time: '1h ago'
  }, {
    type: 'vote',
    detail: 'Voted on ZIP-014',
    amount: '5,000 ZPH',
    status: 'confirmed',
    time: '3h ago'
  }, {
    type: 'receive',
    detail: 'From 9aB2…3f12',
    amount: '+2,400 ZPH',
    status: 'confirmed',
    time: 'Yesterday',
    pos: true
  }, {
    type: 'stake',
    detail: 'Staked to Helius',
    amount: '-8,000 ZPH',
    status: 'confirmed',
    time: '2d ago'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 16
    },
    className: "zy-grid4"
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "Portfolio Value",
    value: "$44,820",
    change: "+8.4%",
    up: true,
    sub: "30d",
    icon: "wallet",
    spark: SERIES['30D']
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "ZPH Balance",
    value: "45,500",
    change: "+2,400",
    up: true,
    sub: "ZPH",
    icon: "circle-dollar-sign",
    spark: SERIES['7D']
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Staked",
    value: "28,000",
    change: "6.2% APY",
    up: true,
    sub: "ZPH",
    icon: "coins",
    spark: [20, 22, 24, 25, 27, 28]
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Query Fees (30d)",
    value: "142.6",
    change: "-12%",
    up: false,
    sub: "ZPH spent",
    icon: "search",
    spark: [8, 6, 7, 5, 4, 5, 3]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.7fr 1fr',
      gap: 24
    },
    className: "zy-grid-main"
  }, /*#__PURE__*/React.createElement(Panel, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Portfolio Value"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 32,
      color: 'var(--text-strong)',
      lineHeight: 1.2
    }
  }, "$44,820.18")), /*#__PURE__*/React.createElement(Timeframe, {
    value: tf,
    onChange: setTf
  })), /*#__PURE__*/React.createElement(AreaChart, {
    data: SERIES[tf],
    height: 230
  })), /*#__PURE__*/React.createElement(Panel, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Allocation"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Donut, {
    segments: alloc,
    centerLabel: "45.5K",
    centerSub: "Total ZPH"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      flex: 1
    }
  }, alloc.map(a => /*#__PURE__*/React.createElement("div", {
    key: a.label,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: 3,
      background: a.color
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-body)',
      flex: 1
    }
  }, a.label), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-strong)',
      fontWeight: 600
    }
  }, a.value.toLocaleString()))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr 1fr',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(AppButton, {
    size: "sm",
    onClick: () => onNav('wallet'),
    leadingIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-up-right",
      size: 15
    })
  }, "Send"), /*#__PURE__*/React.createElement(AppButton, {
    size: "sm",
    variant: "secondary",
    onClick: () => onNav('staking'),
    leadingIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "coins",
      size: 15
    })
  }, "Stake"), /*#__PURE__*/React.createElement(AppButton, {
    size: "sm",
    variant: "secondary",
    onClick: () => onNav('governance'),
    leadingIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "vote",
      size: 15
    })
  }, "Vote")))), /*#__PURE__*/React.createElement(Panel, {
    pad: 0
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 24px 4px'
    }
  }, /*#__PURE__*/React.createElement(SectionTitle, {
    action: /*#__PURE__*/React.createElement(AppButton, {
      size: "sm",
      variant: "ghost",
      onClick: () => onNav('wallet')
    }, "View all \u2192")
  }, "Recent Activity")), /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'detail',
      label: 'Activity',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'inline-flex',
          alignItems: 'center',
          gap: 12
        }
      }, /*#__PURE__*/React.createElement(TxIcon, {
        type: r.type
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-strong)',
          fontWeight: 500
        }
      }, r.detail))
    }, {
      key: 'amount',
      label: 'Amount',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)',
          color: r.pos ? 'var(--teal)' : 'var(--text-strong)'
        }
      }, r.amount)
    }, {
      key: 'status',
      label: 'Status',
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        status: r.status
      })
    }, {
      key: 'time',
      label: 'Time',
      align: 'right',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-muted)'
        }
      }, r.time)
    }],
    rows: activity
  })));
}

/* ---------- WALLET ---------- */
function Wallet({
  notify
}) {
  const [amount, setAmount] = React.useState('');
  const [to, setTo] = React.useState('');
  const txns = [{
    type: 'reward',
    detail: 'Staking reward · Helius',
    amount: '+182.4 ZPH',
    status: 'confirmed',
    time: '2m ago',
    pos: true
  }, {
    type: 'query',
    detail: 'Provider query · NPI 1487…',
    amount: '-1.20 ZPH',
    status: 'confirmed',
    time: '1h ago'
  }, {
    type: 'receive',
    detail: 'From 9aB2…3f12',
    amount: '+2,400 ZPH',
    status: 'confirmed',
    time: 'Yesterday',
    pos: true
  }, {
    type: 'send',
    detail: 'To 4Kp9…a7d1',
    amount: '-500 ZPH',
    status: 'confirmed',
    time: '2d ago'
  }, {
    type: 'stake',
    detail: 'Staked to Helius',
    amount: '-8,000 ZPH',
    status: 'confirmed',
    time: '2d ago'
  }, {
    type: 'query',
    detail: 'Provider query · NPI 1992…',
    amount: '-1.20 ZPH',
    status: 'confirmed',
    time: '3d ago'
  }];
  const send = () => {
    if (!amount) {
      notify({
        tone: 'warn',
        title: 'Enter an amount',
        message: 'Specify how much ZPH to send.'
      });
      return;
    }
    notify({
      tone: 'success',
      title: 'Transaction submitted',
      message: `Sending ${amount} ZPH${to ? ' to ' + to.slice(0, 6) + '…' : ''}. Awaiting confirmation.`
    });
    setAmount('');
    setTo('');
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr',
      gap: 24
    },
    className: "zy-grid-main"
  }, /*#__PURE__*/React.createElement(Panel, {
    style: {
      background: 'var(--navy)',
      border: 'none',
      color: '#fff',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      minHeight: 200,
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: -30,
      top: -50,
      fontFamily: 'var(--font-display)',
      fontSize: 180,
      color: 'rgba(255,255,255,0.03)',
      lineHeight: 1
    }
  }, "Z"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-eyebrow)',
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--teal-mid)',
      marginBottom: 10
    }
  }, "Total Balance"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 44,
      lineHeight: 1
    }
  }, "45,500 ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 24,
      color: 'rgba(255,255,255,0.6)'
    }
  }, "ZPH")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'rgba(255,255,255,0.55)',
      marginTop: 8
    }
  }, "\u2248 $44,820.18 USD")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 24,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(AppButton, {
    onClick: () => document.getElementById('zy-send')?.scrollIntoView({
      block: 'nearest'
    }),
    leadingIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-up-right",
      size: 16,
      color: "#fff"
    })
  }, "Send"), /*#__PURE__*/React.createElement(AppButton, {
    variant: "dark",
    onClick: () => notify({
      tone: 'info',
      title: 'Receive ZPH',
      message: 'Your wallet address has been copied.'
    }),
    leadingIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-down-left",
      size: 16
    })
  }, "Receive"))), /*#__PURE__*/React.createElement(Panel, {
    id: "zy-send",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(SectionTitle, null, "Send ZPH"), /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--text-body)'
    }
  }, "Recipient"), /*#__PURE__*/React.createElement("input", {
    value: to,
    onChange: e => setTo(e.target.value),
    placeholder: "Solana address",
    style: inp()
  })), /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--text-body)'
    }
  }, "Amount (ZPH)"), /*#__PURE__*/React.createElement("input", {
    value: amount,
    onChange: e => setAmount(e.target.value.replace(/[^0-9.]/g, '')),
    placeholder: "0.00",
    inputMode: "decimal",
    style: inp()
  })), /*#__PURE__*/React.createElement(AppButton, {
    onClick: send,
    style: {
      width: '100%',
      marginTop: 4
    }
  }, "Send ZPH"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 24
    },
    className: "zy-grid2"
  }, /*#__PURE__*/React.createElement(Panel, null, /*#__PURE__*/React.createElement(SectionTitle, null, "Query-Fee Usage"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 28,
      color: 'var(--text-strong)'
    }
  }, "142.6 ZPH"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, "spent this month \xB7 118 queries")), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--teal)'
    }
  }, "\u221212% vs last")), /*#__PURE__*/React.createElement(BarMini, {
    data: [14, 11, 18, 9, 22, 16, 13, 19, 24, 12, 17, 21],
    height: 72
  })), /*#__PURE__*/React.createElement(Panel, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(SectionTitle, null, "ZPH Token"), /*#__PURE__*/React.createElement(MintAddress, {
    address: "8sG1MjujqWKNZKkkGQQdekuMTLJvFdP3hoohyEiUr82t",
    label: "Mint Address"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 24,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "Network: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)'
    }
  }, "Solana")), /*#__PURE__*/React.createElement("span", null, "Decimals: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)'
    }
  }, "9")), /*#__PURE__*/React.createElement("span", null, "Standard: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)'
    }
  }, "SPL"))))), /*#__PURE__*/React.createElement(Panel, {
    pad: 0
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 24px 4px'
    }
  }, /*#__PURE__*/React.createElement(SectionTitle, null, "Transaction History")), /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'detail',
      label: 'Transaction',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'inline-flex',
          alignItems: 'center',
          gap: 12
        }
      }, /*#__PURE__*/React.createElement(TxIcon, {
        type: r.type
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-strong)',
          fontWeight: 500
        }
      }, r.detail))
    }, {
      key: 'amount',
      label: 'Amount',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)',
          color: r.pos ? 'var(--teal)' : 'var(--text-strong)'
        }
      }, r.amount)
    }, {
      key: 'status',
      label: 'Status',
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        status: r.status
      })
    }, {
      key: 'time',
      label: 'Time',
      align: 'right',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-muted)'
        }
      }, r.time)
    }],
    rows: txns
  })));
}
function inp() {
  return {
    border: '1px solid var(--border-default)',
    background: 'var(--surface-page)',
    borderRadius: 8,
    padding: '11px 14px',
    fontFamily: 'var(--font-sans)',
    fontSize: 14,
    color: 'var(--text-strong)',
    outline: 'none',
    width: '100%',
    boxSizing: 'border-box'
  };
}
Object.assign(window, {
  StatTile,
  StatusPill,
  DataTable,
  TxIcon,
  SectionTitle,
  Timeframe,
  Overview,
  Wallet,
  inp
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/zypher-app/screens-a.jsx", error: String((e && e.message) || e) }); }

// ui_kits/zypher-app/screens-b.jsx
try { (() => {
/* Zypher Holder Dashboard — Staking + Governance screens. */
const {
  Button: AB,
  Badge: ABadge
} = window.ZypherDesignSystem_7d1dbd;

/* ---------- STAKING ---------- */
function Staking({
  notify
}) {
  const [amount, setAmount] = React.useState('');
  const [mode, setMode] = React.useState('stake');
  const validators = [{
    name: 'Helius',
    status: 'active',
    apy: '6.2%',
    stake: '8,000',
    uptime: '99.98%',
    you: true
  }, {
    name: 'Triton One',
    status: 'active',
    apy: '6.0%',
    stake: '12,000',
    uptime: '99.95%',
    you: true
  }, {
    name: 'Figment',
    status: 'active',
    apy: '5.8%',
    stake: '8,000',
    uptime: '99.91%',
    you: true
  }, {
    name: 'Chorus One',
    status: 'active',
    apy: '5.9%',
    stake: '—',
    uptime: '99.97%',
    you: false
  }, {
    name: 'Everstake',
    status: 'active',
    apy: '6.1%',
    stake: '—',
    uptime: '99.93%',
    you: false
  }];
  const submit = () => {
    if (!amount) {
      notify({
        tone: 'warn',
        title: 'Enter an amount',
        message: `Specify how much ZPH to ${mode}.`
      });
      return;
    }
    notify({
      tone: 'success',
      title: mode === 'stake' ? 'Stake submitted' : 'Unstake requested',
      message: mode === 'stake' ? `Staking ${amount} ZPH. Rewards begin next epoch.` : `Unstaking ${amount} ZPH. Available after the cooldown.`
    });
    setAmount('');
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 16
    },
    className: "zy-grid4"
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "Total Staked",
    value: "28,000",
    sub: "ZPH",
    icon: "coins",
    change: "61% of holdings",
    up: true
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Rewards Earned",
    value: "1,842",
    sub: "ZPH all-time",
    icon: "gift",
    change: "+182 / epoch",
    up: true,
    spark: [120, 140, 150, 165, 172, 182]
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Avg APY",
    value: "6.0%",
    sub: "across 3 validators",
    icon: "percent",
    change: "+0.2%",
    up: true
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Next Reward",
    value: "~14h",
    sub: "epoch 642",
    icon: "clock"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1.6fr',
      gap: 24
    },
    className: "zy-grid-main"
  }, /*#__PURE__*/React.createElement(Panel, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4,
      background: 'var(--surface-tint)',
      borderRadius: 9,
      padding: 3
    }
  }, ['stake', 'unstake'].map(m => /*#__PURE__*/React.createElement("button", {
    key: m,
    onClick: () => setMode(m),
    style: {
      flex: 1,
      border: 'none',
      cursor: 'pointer',
      padding: '9px 0',
      borderRadius: 7,
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      fontWeight: 600,
      textTransform: 'capitalize',
      background: mode === m ? 'var(--surface-card)' : 'transparent',
      color: mode === m ? 'var(--color-primary)' : 'var(--text-muted)',
      boxShadow: mode === m ? 'var(--shadow-xs)' : 'none'
    }
  }, m))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 12,
      color: 'var(--text-muted)',
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("span", null, "Amount"), /*#__PURE__*/React.createElement("span", null, "Available: ", mode === 'stake' ? '17,500' : '28,000', " ZPH")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: amount,
    onChange: e => setAmount(e.target.value.replace(/[^0-9.]/g, '')),
    placeholder: "0.00",
    inputMode: "decimal",
    style: {
      ...inp(),
      paddingRight: 60
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => setAmount(mode === 'stake' ? '17500' : '28000'),
    style: {
      position: 'absolute',
      right: 8,
      top: '50%',
      transform: 'translateY(-50%)',
      background: 'var(--color-primary-tint)',
      color: 'var(--color-primary)',
      border: 'none',
      borderRadius: 6,
      padding: '4px 8px',
      fontSize: 11,
      fontWeight: 700,
      cursor: 'pointer',
      fontFamily: 'var(--font-sans)'
    }
  }, "MAX"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      fontSize: 13,
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement(Row, {
    k: "Est. APY",
    v: "6.2%"
  }), /*#__PURE__*/React.createElement(Row, {
    k: "Est. yearly reward",
    v: amount ? `${(parseFloat(amount) * 0.062).toFixed(0)} ZPH` : '—'
  }), /*#__PURE__*/React.createElement(Row, {
    k: mode === 'stake' ? 'Activation' : 'Cooldown',
    v: mode === 'stake' ? 'Next epoch (~14h)' : '~2.5 days'
  })), /*#__PURE__*/React.createElement(AB, {
    onClick: submit,
    style: {
      width: '100%',
      textTransform: 'capitalize'
    }
  }, mode, " ZPH")), /*#__PURE__*/React.createElement(Panel, {
    pad: 0
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 24px 4px'
    }
  }, /*#__PURE__*/React.createElement(SectionTitle, {
    action: /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: 'var(--text-muted)'
      }
    }, "5 validators")
  }, "Validators")), /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'name',
      label: 'Validator',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'inline-flex',
          alignItems: 'center',
          gap: 10
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 28,
          height: 28,
          borderRadius: 7,
          background: 'var(--surface-tint)',
          color: 'var(--color-primary)',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: 'var(--font-display)',
          fontSize: 13
        }
      }, r.name[0]), /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-strong)',
          fontWeight: 500
        }
      }, r.name), r.you && /*#__PURE__*/React.createElement(ABadge, {
        tone: "done"
      }, "Staked"))
    }, {
      key: 'apy',
      label: 'APY',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--teal)',
          fontWeight: 600
        }
      }, r.apy)
    }, {
      key: 'stake',
      label: 'Your Stake',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)',
          color: 'var(--text-body)'
        }
      }, r.stake)
    }, {
      key: 'uptime',
      label: 'Uptime',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-muted)'
        }
      }, r.uptime)
    }, {
      key: 'act',
      label: '',
      align: 'right',
      render: r => /*#__PURE__*/React.createElement(AB, {
        size: "sm",
        variant: r.you ? 'ghost' : 'secondary',
        onClick: () => notify({
          tone: 'info',
          title: `${r.name}`,
          message: r.you ? 'Manage your stake with this validator.' : `Open a stake with ${r.name}.`
        })
      }, r.you ? 'Manage' : 'Stake')
    }],
    rows: validators
  }))), /*#__PURE__*/React.createElement(Panel, null, /*#__PURE__*/React.createElement(SectionTitle, {
    action: /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: 'var(--text-muted)'
      }
    }, "Last 12 epochs")
  }, "Rewards History"), /*#__PURE__*/React.createElement(AreaChart, {
    data: [120, 132, 128, 140, 145, 150, 148, 160, 165, 172, 176, 182],
    height: 170
  })));
}
function Row({
  k,
  v
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-strong)',
      fontWeight: 500
    }
  }, v));
}

/* ---------- GOVERNANCE ---------- */
function Governance({
  notify
}) {
  const [props, setProps] = React.useState([{
    id: 'ZIP-016',
    title: 'Add HRSA workforce dataset to ingestion pipeline',
    desc: 'Extend federal data coverage to include HRSA health workforce shortage data for richer provider context.',
    status: 'voting',
    forV: 41200000,
    against: 8600000,
    quorum: 60000000,
    ends: '2d 6h',
    voted: null
  }, {
    id: 'ZIP-015',
    title: 'Reduce base query fee from 1.2 to 1.0 ZPH',
    desc: 'Lower the per-query fee to improve accessibility for smaller clearinghouses while maintaining validator incentives.',
    status: 'voting',
    forV: 52000000,
    against: 14000000,
    quorum: 60000000,
    ends: '5d 1h',
    voted: null
  }]);
  const past = [{
    id: 'ZIP-014',
    title: 'Treasury allocation for Q3 pilot partnerships',
    status: 'passed',
    result: '82% For'
  }, {
    id: 'ZIP-013',
    title: 'Onboard Triton One as a verified validator',
    status: 'passed',
    result: '91% For'
  }, {
    id: 'ZIP-012',
    title: 'Increase governance lock multiplier to 1.5×',
    status: 'rejected',
    result: '38% For'
  }];
  const vote = (id, dir) => {
    setProps(cur => cur.map(p => {
      if (p.id !== id || p.voted) return p;
      return {
        ...p,
        voted: dir,
        [dir === 'for' ? 'forV' : 'against']: p[dir === 'for' ? 'forV' : 'against'] + 5000000
      };
    }));
    notify({
      tone: 'success',
      title: `Vote cast on ${id}`,
      message: `You voted ${dir === 'for' ? 'For' : 'Against'} with 5,000,000 ZPH voting power.`
    });
  };
  const fmt = n => (n / 1e6).toFixed(1) + 'M';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 16
    },
    className: "zy-grid3"
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "Voting Power",
    value: "5.0M",
    sub: "ZPH (incl. staked)",
    icon: "gavel"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Active Proposals",
    value: "2",
    sub: "open for voting",
    icon: "vote"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Participation",
    value: "68%",
    sub: "your voting rate",
    icon: "users",
    change: "+5%",
    up: true
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionTitle, null, "Active Proposals"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, props.map(p => {
    const total = p.forV + p.against;
    const forPct = Math.round(p.forV / total * 100);
    const quorumPct = Math.min(100, Math.round(total / p.quorum * 100));
    return /*#__PURE__*/React.createElement(Panel, {
      key: p.id
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        gap: 16,
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 14,
        alignItems: 'flex-start'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 12,
        color: 'var(--color-primary)',
        background: 'var(--color-primary-tint)',
        padding: '4px 8px',
        borderRadius: 6,
        flexShrink: 0
      }
    }, p.id), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 600,
        color: 'var(--text-strong)',
        marginBottom: 4
      }
    }, p.title), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: 'var(--text-muted)',
        lineHeight: 1.55,
        maxWidth: 620
      }
    }, p.desc))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-end',
        gap: 6,
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(StatusPill, {
      status: p.status
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: 'var(--text-muted)',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "clock",
      size: 12
    }), " ", p.ends, " left"))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        fontSize: 12,
        marginBottom: 6
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--teal)',
        fontWeight: 600
      }
    }, "For \xB7 ", fmt(p.forV), " (", forPct, "%)"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--text-muted)',
        fontWeight: 600
      }
    }, "Against \xB7 ", fmt(p.against), " (", 100 - forPct, "%)")), /*#__PURE__*/React.createElement(VoteBar, {
      value: forPct,
      max: 100
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginTop: 14,
        gap: 16,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: 'var(--text-muted)'
      }
    }, "Quorum ", quorumPct, "% of ", fmt(p.quorum), " ZPH"), p.voted ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: 'var(--teal)',
        fontWeight: 600,
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "check-circle-2",
      size: 15
    }), " You voted ", p.voted === 'for' ? 'For' : 'Against') : /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(AB, {
      size: "sm",
      onClick: () => vote(p.id, 'for')
    }, "Vote For"), /*#__PURE__*/React.createElement(AB, {
      size: "sm",
      variant: "secondary",
      onClick: () => vote(p.id, 'against')
    }, "Vote Against"))));
  }))), /*#__PURE__*/React.createElement(Panel, {
    pad: 0
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 24px 4px'
    }
  }, /*#__PURE__*/React.createElement(SectionTitle, null, "Past Proposals")), /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'id',
      label: 'ID',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)',
          color: 'var(--text-muted)'
        }
      }, r.id)
    }, {
      key: 'title',
      label: 'Proposal',
      wrap: true,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-strong)',
          fontWeight: 500
        }
      }, r.title)
    }, {
      key: 'result',
      label: 'Result',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-body)'
        }
      }, r.result)
    }, {
      key: 'status',
      label: 'Status',
      align: 'right',
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        status: r.status
      })
    }],
    rows: past
  })));
}
Object.assign(window, {
  Staking,
  Governance,
  Row
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/zypher-app/screens-b.jsx", error: String((e && e.message) || e) }); }

// ui_kits/zypher-app/screens-c.jsx
try { (() => {
/* Zypher Holder Dashboard — Providers (list + detail) + Settings. */
const {
  Button: CB,
  Badge: CBadge,
  MintAddress: CMint,
  Accordion: CAccordion
} = window.ZypherDesignSystem_7d1dbd;
const PROVIDERS = [{
  npi: '1487654320',
  name: 'Mercy General Hospital',
  specialty: 'General Acute Care',
  loc: 'Sacramento, CA',
  status: 'anchored',
  updated: '2h ago'
}, {
  npi: '1992847163',
  name: 'Dr. Elena Park, MD',
  specialty: 'Cardiology',
  loc: 'Boston, MA',
  status: 'anchored',
  updated: '6h ago'
}, {
  npi: '1730495862',
  name: 'Cascade Family Clinic',
  specialty: 'Family Medicine',
  loc: 'Portland, OR',
  status: 'pending',
  updated: '1d ago'
}, {
  npi: '1558372049',
  name: 'Dr. Marcus Hill, DO',
  specialty: 'Orthopedics',
  loc: 'Austin, TX',
  status: 'anchored',
  updated: '2d ago'
}, {
  npi: '1209384756',
  name: 'Northside Pediatrics',
  specialty: 'Pediatrics',
  loc: 'Atlanta, GA',
  status: 'stale',
  updated: '9d ago'
}];
function Providers({
  onOpen
}) {
  const [q, setQ] = React.useState('');
  const rows = PROVIDERS.filter(p => (p.name + p.npi + p.specialty + p.loc).toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 16
    },
    className: "zy-grid3"
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "Verified Records",
    value: "2.4M",
    sub: "anchored on Solana",
    icon: "shield-check",
    change: "+18K / day",
    up: true
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Your Queries (30d)",
    value: "118",
    sub: "142.6 ZPH spent",
    icon: "search"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Avg Anchor Time",
    value: "0.4s",
    sub: "ingest \u2192 on-chain",
    icon: "zap",
    change: "\u22120.1s",
    up: true
  })), /*#__PURE__*/React.createElement(Panel, {
    pad: 0
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 24px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(SectionTitle, null, "Provider Registry"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      background: 'var(--surface-page)',
      border: '1px solid var(--border-default)',
      borderRadius: 9,
      padding: '8px 12px',
      minWidth: 260
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 16,
    color: "var(--text-muted)"
  }), /*#__PURE__*/React.createElement("input", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Search name, NPI, specialty\u2026",
    style: {
      border: 'none',
      background: 'transparent',
      outline: 'none',
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      color: 'var(--text-strong)',
      width: '100%'
    }
  }))), /*#__PURE__*/React.createElement(DataTable, {
    onRowClick: onOpen,
    columns: [{
      key: 'name',
      label: 'Provider',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'inline-flex',
          alignItems: 'center',
          gap: 12
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 32,
          height: 32,
          borderRadius: 8,
          background: 'var(--surface-tint)',
          color: 'var(--color-primary)',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center'
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "building-2",
        size: 16
      })), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'block',
          color: 'var(--text-strong)',
          fontWeight: 500
        }
      }, r.name), /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'block',
          color: 'var(--text-muted)',
          fontSize: 12
        }
      }, r.specialty)))
    }, {
      key: 'npi',
      label: 'NPI',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)',
          color: 'var(--text-body)'
        }
      }, r.npi)
    }, {
      key: 'loc',
      label: 'Location',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-body)'
        }
      }, r.loc)
    }, {
      key: 'status',
      label: 'Status',
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        status: r.status
      })
    }, {
      key: 'open',
      label: '',
      align: 'right',
      render: () => /*#__PURE__*/React.createElement(Icon, {
        name: "chevron-right",
        size: 16,
        color: "var(--text-muted)"
      })
    }],
    rows: rows
  })));
}
function ProviderDetail({
  provider,
  onBack,
  notify
}) {
  const p = provider || PROVIDERS[0];
  const trail = [{
    icon: 'database',
    t: 'Record ingested from NPPES',
    d: 'Federal NPI record pulled from the NPPES batch feed.',
    time: 'Jun 16, 2026 · 09:42 UTC',
    tone: 'done'
  }, {
    icon: 'check-check',
    t: 'Normalized & validated',
    d: 'Address, taxonomy and credential fields normalized; 0 conflicts.',
    time: 'Jun 16, 2026 · 09:42 UTC',
    tone: 'done'
  }, {
    icon: 'hash',
    t: 'SHA-256 hash computed',
    d: 'Canonical record hashed for tamper-evident anchoring.',
    time: 'Jun 16, 2026 · 09:42 UTC',
    tone: 'done'
  }, {
    icon: 'link',
    t: 'Anchored to Solana',
    d: 'Hash written on-chain in slot 287,449,201.',
    time: 'Jun 16, 2026 · 09:42 UTC',
    tone: 'done'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      background: 'none',
      border: 'none',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      fontWeight: 500,
      padding: 0,
      alignSelf: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-left",
    size: 15
  }), " Back to registry"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.5fr 1fr',
      gap: 24
    },
    className: "zy-grid-main"
  }, /*#__PURE__*/React.createElement(Panel, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 16,
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 12,
      background: 'var(--surface-tint)',
      color: 'var(--color-primary)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "building-2",
    size: 26
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 24,
      color: 'var(--text-strong)',
      margin: 0,
      fontWeight: 400
    }
  }, p.name), /*#__PURE__*/React.createElement(StatusPill, {
    status: p.status
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, p.specialty, " \xB7 ", p.loc))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(Field, {
    k: "NPI",
    v: p.npi,
    mono: true
  }), /*#__PURE__*/React.createElement(Field, {
    k: "Taxonomy",
    v: "207RC0000X",
    mono: true
  }), /*#__PURE__*/React.createElement(Field, {
    k: "Enumeration",
    v: "2008-05-23"
  }), /*#__PURE__*/React.createElement(Field, {
    k: "Last verified",
    v: p.updated
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-default)',
      marginTop: 8,
      paddingTop: 18
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: 12
    }
  }, "On-Chain Anchoring"), /*#__PURE__*/React.createElement(CMint, {
    address: "3xMz9Kp2vQ7Lr8sN1tWfYbHcEdJgUaRkPpZ4nVqB6mT",
    label: "Anchor Transaction"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 24,
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 14,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", null, "Slot: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)',
      fontFamily: 'var(--font-mono)'
    }
  }, "287,449,201")), /*#__PURE__*/React.createElement("span", null, "SHA-256: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)',
      fontFamily: 'var(--font-mono)'
    }
  }, "a3f9\u20267e21"))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(CB, {
    size: "sm",
    variant: "secondary",
    onClick: () => notify({
      tone: 'info',
      title: 'Opening explorer',
      message: 'View this anchor transaction on Solana Explorer.'
    }),
    trailingIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "external-link",
      size: 14
    })
  }, "View on Solana Explorer")))), /*#__PURE__*/React.createElement(Panel, null, /*#__PURE__*/React.createElement(SectionTitle, null, "Audit Trail"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, trail.map((e, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: '50%',
      background: 'var(--color-primary-tint)',
      color: 'var(--color-primary)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: e.icon,
    size: 16
  })), i < trail.length - 1 && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 2,
      flex: 1,
      minHeight: 24,
      background: 'var(--border-default)',
      margin: '4px 0'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--text-strong)'
    }
  }, e.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-muted)',
      lineHeight: 1.5,
      margin: '2px 0 4px'
    }
  }, e.d), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)'
    }
  }, e.time))))))));
}
function Field({
  k,
  v,
  mono
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      textTransform: 'uppercase',
      letterSpacing: '0.06em',
      fontWeight: 600,
      marginBottom: 4
    }
  }, k), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--text-strong)',
      fontWeight: 500,
      fontFamily: mono ? 'var(--font-mono)' : 'inherit'
    }
  }, v));
}

/* ---------- SETTINGS ---------- */
function Settings({
  theme,
  setTheme,
  notify
}) {
  const [name, setName] = React.useState('zypher.holder');
  const [notifs, setNotifs] = React.useState({
    rewards: true,
    governance: true,
    queries: false,
    security: true
  });
  const wallets = [{
    label: 'Phantom',
    addr: '8sG1…r82t',
    primary: true
  }, {
    label: 'Solflare',
    addr: '4Kp9…a7d1',
    primary: false
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
      maxWidth: 860
    }
  }, /*#__PURE__*/React.createElement(Panel, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(SectionTitle, null, "Account"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 56,
      height: 56,
      borderRadius: '50%',
      background: 'var(--teal)',
      color: '#fff',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-display)',
      fontSize: 24
    }
  }, "Z"), /*#__PURE__*/React.createElement("label", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--text-body)'
    }
  }, "Display name"), /*#__PURE__*/React.createElement("input", {
    value: name,
    onChange: e => setName(e.target.value),
    style: {
      ...inp(),
      maxWidth: 320
    }
  })))), /*#__PURE__*/React.createElement(Panel, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(SectionTitle, {
    action: /*#__PURE__*/React.createElement(CB, {
      size: "sm",
      variant: "secondary",
      onClick: () => notify({
        tone: 'info',
        title: 'Connect wallet',
        message: 'Choose a wallet provider to link.'
      })
    }, "Connect wallet")
  }, "Connected Wallets"), wallets.map(w => /*#__PURE__*/React.createElement("div", {
    key: w.label,
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '12px 14px',
      border: '1px solid var(--border-default)',
      borderRadius: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 32,
      height: 32,
      borderRadius: 8,
      background: 'var(--surface-tint)',
      color: 'var(--color-primary)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "wallet",
    size: 16
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--text-strong)'
    }
  }, w.label, " ", w.primary && /*#__PURE__*/React.createElement(CBadge, {
    tone: "done"
  }, "Primary")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)'
    }
  }, w.addr))), /*#__PURE__*/React.createElement("button", {
    onClick: () => notify({
      tone: 'warn',
      title: 'Disconnect wallet',
      message: `${w.label} would be unlinked.`
    }),
    style: {
      background: 'none',
      border: 'none',
      color: 'var(--text-muted)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 18
  }))))), /*#__PURE__*/React.createElement(Panel, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(SectionTitle, null, "Appearance"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, [['light', 'sun', 'Light'], ['dark', 'moon', 'Dark']].map(([val, icon, label]) => /*#__PURE__*/React.createElement("button", {
    key: val,
    onClick: () => setTheme(val),
    style: {
      flex: 1,
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '14px 18px',
      borderRadius: 12,
      cursor: 'pointer',
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      fontWeight: 600,
      border: `2px solid ${theme === val ? 'var(--color-primary)' : 'var(--border-default)'}`,
      background: theme === val ? 'var(--color-primary-tint)' : 'var(--surface-card)',
      color: theme === val ? 'var(--color-primary)' : 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 18
  }), " ", label, theme === val && /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 16,
    style: {
      marginLeft: 'auto'
    }
  }))))), /*#__PURE__*/React.createElement(Panel, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(SectionTitle, null, "Notifications"), [['rewards', 'Staking rewards'], ['governance', 'Governance proposals'], ['queries', 'Query-fee receipts'], ['security', 'Security alerts']].map(([k, label]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '12px 0',
      borderBottom: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-body)'
    }
  }, label), /*#__PURE__*/React.createElement(Switch, {
    on: notifs[k],
    onToggle: () => setNotifs(s => ({
      ...s,
      [k]: !s[k]
    }))
  })))));
}
function Switch({
  on,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    "aria-pressed": on,
    style: {
      width: 42,
      height: 24,
      borderRadius: 999,
      border: 'none',
      cursor: 'pointer',
      padding: 2,
      transition: 'background var(--dur-base)',
      background: on ? 'var(--teal)' : 'var(--border-strong)',
      display: 'flex',
      justifyContent: on ? 'flex-end' : 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: '50%',
      background: '#fff',
      boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
      transition: 'all var(--dur-base)'
    }
  }));
}
Object.assign(window, {
  Providers,
  ProviderDetail,
  Field,
  Settings,
  Switch,
  PROVIDERS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/zypher-app/screens-c.jsx", error: String((e && e.message) || e) }); }

// ui_kits/zypher-app/shell.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Zypher Holder Dashboard — app shell (sidebar, topbar, theme, primitives).
   Composes design-system components from window.ZypherDesignSystem_7d1dbd. */
const ZDS = window.ZypherDesignSystem_7d1dbd;
const {
  Button,
  Badge,
  WalletButton
} = ZDS;

/* ---- Lucide icon helper ---- */
function Icon({
  name,
  size = 18,
  color = 'currentColor',
  strokeWidth = 1.75,
  style
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = '';
      const i = document.createElement('i');
      i.setAttribute('data-lucide', name);
      ref.current.appendChild(i);
      window.lucide.createIcons({
        attrs: {
          width: size,
          height: size,
          stroke: color,
          'stroke-width': strokeWidth
        }
      });
    }
  }, [name, size, color, strokeWidth]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    style: {
      display: 'inline-flex',
      lineHeight: 0,
      ...style
    }
  });
}

/* ---- Panel: the app's base surface (themed) ---- */
function Panel({
  children,
  style,
  pad = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 16,
      padding: pad,
      ...style
    }
  }, rest), children);
}

/* ---- Section label ---- */
function Eyebrow({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-eyebrow)',
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      ...style
    }
  }, children);
}

/* ---- Themed icon well ---- */
function IconWell({
  name,
  tone = 'teal',
  size = 38
}) {
  const bg = tone === 'teal' ? 'var(--color-primary-tint)' : 'var(--surface-tint)';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      borderRadius: 10,
      background: bg,
      color: 'var(--color-primary)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: name,
    size: Math.round(size * 0.5)
  }));
}

/* ---- Theme toggle ---- */
function ThemeToggle({
  theme,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    "aria-label": "Toggle theme",
    style: {
      width: 38,
      height: 38,
      borderRadius: 10,
      border: '1px solid var(--border-default)',
      background: 'var(--surface-card)',
      color: 'var(--text-body)',
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: theme === 'dark' ? 'sun' : 'moon',
    size: 18
  }));
}

/* ---- Sidebar ---- */
const NAV = [{
  id: 'overview',
  label: 'Overview',
  icon: 'layout-dashboard'
}, {
  id: 'wallet',
  label: 'Wallet',
  icon: 'wallet'
}, {
  id: 'staking',
  label: 'Staking',
  icon: 'coins'
}, {
  id: 'governance',
  label: 'Governance',
  icon: 'vote'
}, {
  id: 'providers',
  label: 'Providers',
  icon: 'shield-check'
}, {
  id: 'settings',
  label: 'Settings',
  icon: 'settings'
}];
function Sidebar({
  active,
  onNav
}) {
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 240,
      flexShrink: 0,
      background: 'var(--surface-sidebar)',
      borderRight: '1px solid var(--border-default)',
      display: 'flex',
      flexDirection: 'column',
      padding: '20px 16px',
      position: 'sticky',
      top: 0,
      height: '100vh'
    },
    className: "zy-sidebar"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '6px 8px 22px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      background: 'var(--teal)',
      borderRadius: 8,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#fff',
      fontFamily: 'var(--font-display)',
      fontSize: 17,
      letterSpacing: '-0.5px'
    }
  }, "Z"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: 'var(--text-strong)',
      letterSpacing: '-0.3px'
    }
  }, "Zypher"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--color-primary)',
      background: 'var(--color-primary-tint)',
      padding: '2px 7px',
      borderRadius: 4,
      fontWeight: 500
    }
  }, "ZPH")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, NAV.map(n => {
    const on = active === n.id;
    return /*#__PURE__*/React.createElement("button", {
      key: n.id,
      onClick: () => onNav(n.id),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '10px 12px',
        borderRadius: 9,
        border: 'none',
        cursor: 'pointer',
        background: on ? 'var(--color-primary-tint)' : 'transparent',
        color: on ? 'var(--color-primary)' : 'var(--text-body)',
        fontFamily: 'var(--font-sans)',
        fontSize: 14,
        fontWeight: on ? 600 : 500,
        textAlign: 'left',
        transition: 'background var(--dur-fast)'
      },
      onMouseEnter: e => {
        if (!on) e.currentTarget.style.background = 'var(--surface-tint)';
      },
      onMouseLeave: e => {
        if (!on) e.currentTarget.style.background = 'transparent';
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: n.icon,
      size: 18,
      strokeWidth: on ? 2 : 1.75
    }), n.label);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-tint)',
      borderRadius: 12,
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      marginBottom: 6
    }
  }, "Network"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      fontSize: 13,
      color: 'var(--text-strong)',
      fontWeight: 500
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--teal-mid)'
    },
    className: "zy-pulse"
  }), "Solana Mainnet"))));
}

/* ---- Topbar ---- */
function Topbar({
  title,
  subtitle,
  theme,
  onToggleTheme,
  onNotify
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16,
      padding: '20px 32px',
      borderBottom: '1px solid var(--border-default)',
      background: 'var(--surface-page)',
      position: 'sticky',
      top: 0,
      zIndex: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 26,
      color: 'var(--text-strong)',
      margin: 0,
      fontWeight: 400,
      letterSpacing: '-0.5px'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, subtitle)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 10,
      padding: '8px 12px',
      color: 'var(--text-muted)',
      fontSize: 13,
      minWidth: 200
    },
    className: "zy-search"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 16
  }), /*#__PURE__*/React.createElement("span", null, "Search providers, txns\u2026")), /*#__PURE__*/React.createElement("button", {
    onClick: onNotify,
    "aria-label": "Notifications",
    style: {
      width: 38,
      height: 38,
      borderRadius: 10,
      border: '1px solid var(--border-default)',
      background: 'var(--surface-card)',
      color: 'var(--text-body)',
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 18
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 9,
      right: 10,
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--teal-mid)',
      border: '2px solid var(--surface-card)'
    }
  })), /*#__PURE__*/React.createElement(ThemeToggle, {
    theme: theme,
    onToggle: onToggleTheme
  }), /*#__PURE__*/React.createElement(WalletButton, {
    connected: true,
    address: "8sG1MjujqWKNZKkkGQQdekuMTLJvFdP3hoohyEiUr82t",
    balance: "12,500 ZPH"
  })));
}
Object.assign(window, {
  Icon,
  Panel,
  Eyebrow,
  IconWell,
  ThemeToggle,
  Sidebar,
  Topbar,
  NAV
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/zypher-app/shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/zypher-site/sections.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Zypher site UI kit — section components.
   Composes design-system primitives from window.ZypherDesignSystem_7d1dbd.
   Icons: Lucide (the system's standard) in place of the original site's emoji. */
const {
  Button,
  Badge,
  Card,
  StatCard,
  MintAddress,
  SectionHeading,
  Callout,
  Accordion,
  Stepper,
  WalletButton
} = window.ZypherDesignSystem_7d1dbd;
const MINT = '8sG1MjujqWKNZKkkGQQdekuMTLJvFdP3hoohyEiUr82t';
function Icon({
  name,
  size = 22,
  color = 'currentColor'
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = '';
      const el = document.createElement('i');
      el.setAttribute('data-lucide', name);
      ref.current.appendChild(el);
      window.lucide.createIcons({
        attrs: {
          width: size,
          height: size,
          stroke: color
        }
      });
    }
  }, [name, size, color]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    style: {
      display: 'inline-flex'
    }
  });
}
const wrap = {
  maxWidth: 'var(--content-max)',
  margin: '0 auto',
  padding: '0 2rem'
};

/* ---------------- NAV ---------------- */
function Nav() {
  const links = ['About', 'Tokenomics', 'Roadmap', 'zCARE', 'FAQ'];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 100,
      background: 'rgba(255,255,255,0.95)',
      backdropFilter: 'blur(12px)',
      borderBottom: '1px solid var(--border)',
      height: 64,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 2rem'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#top",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 36,
      height: 36,
      background: 'var(--teal)',
      borderRadius: 8,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#fff',
      fontFamily: 'var(--font-display)',
      fontSize: 18,
      letterSpacing: '-0.5px'
    }
  }, "Z"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 17,
      fontWeight: 600,
      color: 'var(--navy)',
      letterSpacing: '-0.3px'
    }
  }, "Zypher"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--teal-mid)',
      background: 'var(--teal-light)',
      padding: '2px 7px',
      borderRadius: 4
    }
  }, "ZPH")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '2rem'
    }
  }, /*#__PURE__*/React.createElement("ul", {
    style: {
      display: 'flex',
      gap: '2rem',
      listStyle: 'none',
      margin: 0,
      padding: 0
    },
    className: "zy-navlinks"
  }, links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l
  }, /*#__PURE__*/React.createElement("a", {
    href: '#' + l.toLowerCase(),
    style: {
      textDecoration: 'none',
      color: 'var(--slate)',
      fontSize: 14,
      fontWeight: 500
    }
  }, l)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm"
  }, "Buy ZPH"), /*#__PURE__*/React.createElement(WalletButton, {
    size: "sm"
  }))));
}

/* ---------------- HERO ---------------- */
function Hero() {
  const stats = [{
    value: '$80B+',
    label: 'Uncompensated Care',
    sub: 'Lost annually in the US'
  }, {
    value: '1B',
    label: 'ZPH Supply',
    sub: 'Fixed, minting revoked'
  }, {
    value: "Mar '26",
    label: 'Token Launch',
    sub: 'TGE March 17, 2026'
  }, {
    value: 'Solana',
    label: 'Blockchain',
    sub: '65K TPS, sub-$0.001 fees'
  }];
  return /*#__PURE__*/React.createElement("section", {
    id: "top",
    style: {
      ...wrap,
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 80,
      alignItems: 'center',
      padding: '96px 2rem 80px'
    },
    className: "zy-hero"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      background: 'var(--teal-light)',
      color: 'var(--teal)',
      font: 'var(--type-eyebrow)',
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      padding: '6px 14px',
      borderRadius: 20,
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "zy-pulse",
    style: {
      width: 6,
      height: 6,
      background: 'var(--teal-mid)',
      borderRadius: '50%'
    }
  }), " Live on Solana"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 52,
      lineHeight: 1.1,
      color: 'var(--navy)',
      letterSpacing: '-1px',
      margin: '0 0 24px',
      fontWeight: 400
    }
  }, "Healthcare payments need a ", /*#__PURE__*/React.createElement("em", {
    style: {
      fontStyle: 'italic',
      color: 'var(--teal)'
    }
  }, "data layer.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      color: 'var(--slate)',
      lineHeight: 1.75,
      fontWeight: 300,
      margin: '0 0 36px'
    }
  }, "Zypher (ZPH) is building verified, on-chain provider infrastructure connected to federal data pipelines \u2014 designed to solve the $80B+ uncompensated care crisis in American healthcare."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    trailingIcon: "\u2197"
  }, "Buy ZPH on Jupiter"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary"
  }, "Read Whitepaper"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 1,
      background: 'var(--border)',
      borderRadius: 16,
      overflow: 'hidden',
      border: '1px solid var(--border)'
    }
  }, stats.map(s => /*#__PURE__*/React.createElement(StatCard, _extends({
    key: s.label
  }, s)))));
}

/* ---------------- TICKER ---------------- */
function Ticker() {
  const items = ['ZPH · SOLANA · HEALTHCARE INFRASTRUCTURE', 'MINT AUTHORITY REVOKED · FREEZE AUTHORITY REVOKED', 'LISTED ON JUPITER · RAYDIUM · DEXSCREENER', 'PHASE 2: zCARE STABLE PAYMENT TOKEN · COMING SOON'];
  const seq = [...items, ...items];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--navy)',
      color: '#fff',
      padding: '12px 0',
      overflow: 'hidden',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "zy-ticker",
    style: {
      display: 'inline-flex',
      gap: '3rem',
      fontSize: 13,
      fontWeight: 500,
      letterSpacing: '0.04em',
      opacity: 0.85
    }
  }, seq.map((t, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 4,
      height: 4,
      background: 'var(--teal-mid)',
      borderRadius: '50%'
    }
  }), " ", t))));
}

/* ---------------- PROBLEM ---------------- */
function Problem() {
  const cards = [{
    n: '$80B+',
    t: 'Uncompensated Care Annually',
    d: 'U.S. hospitals absorb over $80 billion per year in uncompensated care — services rendered to patients whose claims fail due to data errors and billing fragmentation.'
  }, {
    n: '~50%',
    t: 'Provider Directory Error Rate',
    d: 'Studies show provider directory error rates as high as 50% in certain markets. Outdated records cause claims denials that cannot be corrected retroactively.'
  }, {
    n: '0',
    t: 'Real-Time National Registry',
    d: 'The federal NPPES registry is batch-updated and siloed. No shared, real-time, composable infrastructure exists to synchronize provider data across payers.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    id: "about",
    style: {
      background: 'var(--surface)',
      padding: '96px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: wrap
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    label: "The Problem",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "American healthcare loses billions", /*#__PURE__*/React.createElement("br", null), "to a broken data layer."),
    sub: "Provider directories are inaccurate. Billing systems are fragmented. No unified, real-time source of provider truth exists \u2014 and hospitals pay for it every year."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr 1fr',
      gap: 24,
      marginTop: 56
    },
    className: "zy-3col"
  }, cards.map(c => /*#__PURE__*/React.createElement(Card, {
    key: c.t,
    accent: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 48,
      color: 'var(--teal)',
      lineHeight: 1,
      marginBottom: 12
    }
  }, c.n), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: 'var(--navy)',
      marginBottom: 8
    }
  }, c.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--slate)',
      lineHeight: 1.65
    }
  }, c.d))))));
}

/* ---------------- HOW IT WORKS ---------------- */
function HowItWorks() {
  const steps = [{
    title: 'Federal Data Ingestion',
    desc: 'NPPES, CMS, and HRSA data pipelines are connected and continuously ingested into the Zypher network.'
  }, {
    title: 'Verification & Hashing',
    desc: 'Provider records are normalized, validated, and cryptographically hashed using SHA-256.'
  }, {
    title: 'On-Chain Anchoring',
    desc: 'Verified hashes are anchored to Solana, creating an immutable audit trail linked to each provider NPI.'
  }, {
    title: 'Composable Access',
    desc: 'Any participant — payer, clearinghouse, or patient — can query verified provider data in real time via ZPH.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      ...wrap,
      padding: '96px 2rem'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    label: "The Solution",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "On-chain provider infrastructure,", /*#__PURE__*/React.createElement("br", null), "anchored to federal data."),
    sub: "Zypher ingests authoritative federal data and anchors it permanently on Solana \u2014 creating a composable, verifiable provider registry any participant can query."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 56
    },
    className: "zy-steps"
  }, /*#__PURE__*/React.createElement(Stepper, {
    orientation: "horizontal",
    steps: steps
  })));
}

/* ---------------- TOKENOMICS ---------------- */
function Tokenomics() {
  const specs = [['Token Name', 'Zypher', false], ['Ticker', 'ZPH', true], ['Blockchain', 'Solana (SPL)', false], ['Total Supply', '1,000,000,000', true], ['Mint Authority', 'Revoked ✓', 'green'], ['Freeze Authority', 'Revoked ✓', 'green'], ['TGE', 'March 17, 2026', false], ['DEX', 'Jupiter / Raydium', false]];
  const utils = [{
    icon: 'search',
    t: 'Network Query Fees',
    d: 'Participants querying verified provider records pay fees denominated in ZPH, creating continuous demand as utilization scales.'
  }, {
    icon: 'settings',
    t: 'Validator Incentives',
    d: 'Nodes that ingest, verify, and anchor federal data to the chain are compensated in ZPH.'
  }, {
    icon: 'vote',
    t: 'Governance',
    d: 'ZPH holders participate in protocol governance — data source additions, fee parameters, and network upgrades.'
  }, {
    icon: 'landmark',
    t: 'zCARE Collateral',
    d: 'Phase 2 introduces ZPH as collateral backing the zCARE stable payment token, creating a direct demand sink.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    id: "tokenomics",
    style: {
      background: 'var(--surface)',
      padding: '96px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: wrap
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    label: "Tokenomics",
    title: "ZPH \u2014 Infrastructure Token",
    sub: "ZPH powers access, governance, and liquidity across the Zypher network. Fixed supply, both authorities permanently revoked."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 48,
      alignItems: 'start'
    },
    className: "zy-2col"
  }, /*#__PURE__*/React.createElement(Card, {
    dark: true,
    style: {
      borderRadius: 16,
      padding: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 24,
      marginBottom: 28
    }
  }, "Token Specifications"), specs.map(([k, v, hl], i) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '12px 0',
      borderBottom: i < specs.length - 1 ? '1px solid rgba(255,255,255,0.08)' : 'none',
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'rgba(255,255,255,0.55)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: hl ? 600 : 500,
      color: hl === 'green' ? '#6EE7B7' : hl ? 'var(--teal-mid)' : '#fff'
    }
  }, v)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 20,
      fontWeight: 600,
      color: 'var(--navy)',
      margin: '0 0 20px'
    }
  }, "ZPH Utility"), utils.map((u, i) => /*#__PURE__*/React.createElement("div", {
    key: u.t,
    style: {
      display: 'flex',
      gap: 16,
      padding: '16px 0',
      borderBottom: i < utils.length - 1 ? '1px solid var(--border)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 36,
      height: 36,
      background: 'var(--teal-light)',
      borderRadius: 8,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0,
      color: 'var(--teal)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: u.icon,
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--navy)',
      marginBottom: 4
    }
  }, u.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--slate)',
      lineHeight: 1.55
    }
  }, u.d)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 48
    }
  }, /*#__PURE__*/React.createElement(MintAddress, {
    address: MINT
  }))));
}

/* ---------------- ROADMAP ---------------- */
function Roadmap() {
  const phases = [{
    tag: 'Underway',
    tone: 'done',
    title: 'Phase 1',
    when: 'Infrastructure Foundation · 2026',
    items: [['done', 'Token Generation Event (March 17, 2026)'], ['done', 'Raydium liquidity pool deployment'], ['done', 'Jupiter DEX listing'], ['done', 'Website & whitepaper publication'], ['active', 'CoinGecko listing'], ['active', 'Community growth & Twitter presence'], ['future', 'NPPES data pipeline proof-of-concept (Q3 2026)']]
  }, {
    tag: 'Upcoming',
    tone: 'future',
    title: 'Phase 2',
    when: 'Payment Layer · 2026–2027',
    items: [['future', 'zCARE stable payment token design'], ['future', 'Regulatory framework & compliance scaffolding'], ['future', 'Pilot partnerships with billing clearinghouses'], ['future', 'zCARE token generation & liquidity initialization'], ['future', 'Cross-chain bridge exploration']]
  }, {
    tag: 'Horizon',
    tone: 'future',
    title: 'Phase 3',
    when: 'Scale & Adoption · 2027+',
    items: [['future', 'National-scale NPPES/CMS data anchoring'], ['future', 'Payer & health system integration partnerships'], ['future', 'Expansion to additional federal health data sources'], ['future', 'Governance decentralization & DAO transition']]
  }];
  const mark = {
    done: '✓',
    active: '→',
    future: '○'
  };
  const markStyle = {
    done: {
      background: 'var(--teal)',
      color: '#fff'
    },
    active: {
      background: 'var(--amber-bg)',
      color: 'var(--amber-fg)',
      border: '1px solid #FCD34D'
    },
    future: {
      background: '#F1F5F9',
      color: 'var(--muted)'
    }
  };
  return /*#__PURE__*/React.createElement("section", {
    id: "roadmap",
    style: {
      ...wrap,
      padding: '96px 2rem'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    label: "Roadmap",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Building the infrastructure,", /*#__PURE__*/React.createElement("br", null), "phase by phase."),
    sub: "From token launch to national-scale healthcare data infrastructure and the zCARE payment layer."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr 1fr',
      gap: 24,
      marginTop: 56
    },
    className: "zy-3col"
  }, phases.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.title,
    style: {
      border: '1px solid var(--border)',
      borderRadius: 12,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 28px 20px',
      background: 'var(--surface)',
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: p.tone
  }, p.tag)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 22,
      color: 'var(--navy)',
      marginBottom: 4
    }
  }, p.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--muted)',
      fontWeight: 500
    }
  }, p.when)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 28px',
      background: 'var(--surface)',
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, p.items.map(([st, label]) => /*#__PURE__*/React.createElement("div", {
    key: label,
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 10,
      fontSize: 13,
      color: 'var(--slate)',
      lineHeight: 1.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0,
      marginTop: 1,
      fontSize: 10,
      ...markStyle[st]
    }
  }, mark[st]), /*#__PURE__*/React.createElement("span", null, label))))))));
}

/* ---------------- ZCARE ---------------- */
function Zcare() {
  return /*#__PURE__*/React.createElement("section", {
    id: "zcare",
    style: {
      background: 'var(--bg)',
      padding: '96px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--navy)',
      borderRadius: 20,
      padding: 64,
      display: 'grid',
      gridTemplateColumns: '1fr auto',
      gap: 48,
      alignItems: 'center',
      position: 'relative',
      overflow: 'hidden'
    },
    className: "zy-zcare"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: -20,
      top: -40,
      fontFamily: 'var(--font-display)',
      fontSize: 200,
      color: 'rgba(255,255,255,0.03)',
      lineHeight: 1,
      pointerEvents: 'none'
    }
  }, "zCARE"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-eyebrow)',
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--teal-mid)',
      marginBottom: 16
    }
  }, "Phase 2 \xB7 Coming Soon"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 40,
      color: '#fff',
      lineHeight: 1.15,
      margin: '0 0 20px',
      fontWeight: 400
    }
  }, "Introducing zCARE \u2014", /*#__PURE__*/React.createElement("br", null), "Healthcare's Payment Token."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 16,
      color: 'rgba(255,255,255,0.6)',
      lineHeight: 1.75,
      fontWeight: 300,
      maxWidth: 480,
      margin: 0
    }
  }, "Built on Zypher's verified provider infrastructure, zCARE is a stable payment token designed specifically for healthcare transactions \u2014 with HIPAA-compatible structures and clearinghouse integration hooks.")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'rgba(29,158,117,0.15)',
      border: '1px solid rgba(29,158,117,0.3)',
      borderRadius: 16,
      padding: '40px 36px',
      textAlign: 'center',
      minWidth: 200,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--teal-mid)',
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      marginBottom: 12
    }
  }, "Phase 2 Token"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 36,
      color: '#fff',
      marginBottom: 8
    }
  }, "zCARE"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'rgba(255,255,255,0.45)'
    }
  }, "Stable \xB7 Healthcare-native \xB7 Composable")))));
}

/* ---------------- FAQ (interactive) ---------------- */
function Faq() {
  const qs = [{
    q: 'What is Zypher (ZPH)?',
    a: 'Zypher (ZPH) is a Solana-based cryptocurrency project building healthcare payments infrastructure. ZPH powers a system designed to solve the $80B+ uncompensated care crisis through decentralized payment rails connected to real federal data pipelines including NPPES, CMS, and HRSA.'
  }, {
    q: 'Why is Zypher built on Solana?',
    a: 'Solana processes up to 65,000 transactions per second with sub-second finality and fees averaging less than $0.001 per transaction. For healthcare payment infrastructure at national scale, this throughput and cost profile is essential.'
  }, {
    q: 'Is ZPH supply fixed?',
    a: 'Yes — ZPH has a hard cap of 1,000,000,000 (1 billion) tokens. Both Mint Authority and Freeze Authority have been permanently revoked, meaning no additional ZPH can ever be created. This is cryptographically enforced and irreversible on-chain.'
  }, {
    q: 'Where can I buy ZPH?',
    a: 'ZPH is currently available on Jupiter and Raydium, two of Solana\'s leading DEX platforms. Always verify the mint address before trading to ensure you are purchasing the correct token.'
  }, {
    q: 'What is zCARE and when is it launching?',
    a: 'zCARE is Zypher\'s Phase 2 stable payment token designed specifically for healthcare transactions. It will be built with HIPAA-compatible transaction structures and integration hooks for existing billing clearinghouses.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    id: "faq",
    style: {
      ...wrap,
      padding: '96px 2rem'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    label: "FAQ",
    title: "Frequently asked questions."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 48
    }
  }, /*#__PURE__*/React.createElement(Accordion, {
    items: qs,
    defaultOpen: 0
  })));
}

/* ---------------- FOOTER ---------------- */
function Footer() {
  const cols = [['Protocol', ['About', 'Tokenomics', 'Roadmap', 'Whitepaper']], ['Trade', ['Jupiter', 'Raydium', 'DexScreener', 'CoinGecko']], ['Community', ['Twitter / X', 'GitHub', 'Telegram']]];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--navy)',
      color: 'rgba(255,255,255,0.6)',
      padding: '64px 2rem 40px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--content-max)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '2fr 1fr 1fr 1fr',
      gap: 48,
      paddingBottom: 48,
      borderBottom: '1px solid rgba(255,255,255,0.08)'
    },
    className: "zy-footcols"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 24,
      color: '#fff',
      marginBottom: 12
    }
  }, "Zypher"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      lineHeight: 1.7,
      color: 'rgba(255,255,255,0.45)',
      maxWidth: 280
    }
  }, "Healthcare payments infrastructure on Solana. Verified, on-chain provider data anchored to federal pipelines.")), cols.map(([title, items]) => /*#__PURE__*/React.createElement("div", {
    key: title
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'rgba(255,255,255,0.35)',
      marginBottom: 16
    }
  }, title), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      margin: 0,
      padding: 0
    }
  }, items.map(l => /*#__PURE__*/React.createElement("li", {
    key: l
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'rgba(255,255,255,0.55)',
      textDecoration: 'none',
      fontSize: 14
    }
  }, l))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingTop: 32,
      fontSize: 12,
      color: 'rgba(255,255,255,0.3)',
      flexWrap: 'wrap',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Zypher. ZPH is a utility token, not investment advice."), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)'
    }
  }, "MINT: ", MINT.slice(0, 6), "\u2026", MINT.slice(-4)))));
}
function ZypherSite() {
  return /*#__PURE__*/React.createElement("div", {
    className: "zy"
  }, /*#__PURE__*/React.createElement(Nav, null), /*#__PURE__*/React.createElement(Hero, null), /*#__PURE__*/React.createElement(Ticker, null), /*#__PURE__*/React.createElement(Problem, null), /*#__PURE__*/React.createElement(HowItWorks, null), /*#__PURE__*/React.createElement(Tokenomics, null), /*#__PURE__*/React.createElement(Roadmap, null), /*#__PURE__*/React.createElement(Zcare, null), /*#__PURE__*/React.createElement(Faq, null), /*#__PURE__*/React.createElement(Footer, null));
}
Object.assign(window, {
  ZypherSite,
  Nav,
  Hero,
  Ticker,
  Problem,
  HowItWorks,
  Tokenomics,
  Roadmap,
  Zcare,
  Faq,
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/zypher-site/sections.jsx", error: String((e && e.message) || e) }); }

__ds_ns.WalletButton = __ds_scope.WalletButton;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.MintAddress = __ds_scope.MintAddress;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.Accordion = __ds_scope.Accordion;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.ToastViewport = __ds_scope.ToastViewport;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.Stepper = __ds_scope.Stepper;

__ds_ns.Menu = __ds_scope.Menu;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Tooltip = __ds_scope.Tooltip;

})();

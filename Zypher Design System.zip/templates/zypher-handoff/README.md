# Handoff: Zypher Design System

A complete, committable copy of the **Zypher (ZPH)** design system — tokens, self-hosted fonts, brand assets, reusable components (React source **and** a compiled vanilla bundle), plus example UI kits and deck templates. This package is meant to be dropped into your GitHub repo and served from your website.

> **Goal:** get the Zypher design system **live on your website via GitHub.** Two routes are documented below — pick the one that matches your stack.

---

## About these files
- `styles.css`, `tokens/`, `assets/` (fonts + logos), and the component **`.jsx` source** are **real, production-usable assets** — link the CSS, use the components.
- The `.card.html` files (in `components/`) and everything under `examples/` are **design references / demos** — they show intended look and behavior. Recreate or reuse them in your site's environment; don't necessarily ship them verbatim.
- **Fidelity: high.** Exact colors, type, spacing, radii, and shadows are all encoded in the tokens — match them precisely.

---

## What's in this package

```
styles.css                  ← THE entry point. Link this one file.
tokens/                     ← CSS custom properties (imported by styles.css)
  fonts.css                 ← imports ../assets/fonts-local.css
  colors.css  typography.css  spacing.css  themes.css (light + dark)  base.css
assets/
  fonts/                    ← 22 self-hosted woff2 (DM Sans/Serif/Mono, OFL)
  fonts-local.css           ← @font-face rules → assets/fonts/*
  logo-mark.svg  logo-wordmark.svg
components/                 ← React source per component (.jsx + .d.ts + .prompt.md + demo .card.html)
  forms/ data/ layout/ disclosure/ feedback/ crypto/ navigation/ overlay/
_ds_bundle.js               ← compiled vanilla library: window.ZypherDesignSystem_7d1dbd
DESIGN_SYSTEM.md            ← full design guide (voice, visual foundations, iconography)
SKILL.md                    ← Agent-Skill manifest (for Claude Code / Claude.ai)
examples/                   ← reference designs (NOT required to ship)
  ui_kits/zypher-site/      ← marketing site recreation
  ui_kits/zypher-app/       ← ZPH holder dashboard (net-new, fake data)
  (slide-deck templates are kept in the authoring workspace; exportable on request)
```

---

## Quick start (any website)

1. Copy `styles.css`, `tokens/`, and `assets/` into your site (keep the relative folder structure — `styles.css` → `tokens/` → `assets/fonts-local.css` → `assets/fonts/` paths must stay intact).
2. Link the one entry file:
   ```html
   <link rel="stylesheet" href="/zypher-design/styles.css" />
   ```
3. Build with the tokens (works in plain HTML/CSS, any framework):
   ```html
   <h1 style="font-family: var(--font-display); color: var(--navy);">
     Healthcare payments need a <em style="color: var(--teal); font-style: italic;">data layer.</em>
   </h1>
   <button style="background: var(--teal); color:#fff; border:none; border-radius: var(--radius-md); padding: 13px 24px; font: var(--fw-medium) var(--fs-body) var(--font-sans);">Buy ZPH</button>
   ```
4. **Dark mode:** set `data-theme="dark"` on any wrapper element; every `--surface-*`, `--text-*`, `--border-*` token re-resolves automatically.

### Using the components
**Option 1 — React source (recommended for a React/Vite/Next site).** Each component is a self-contained `export function` that only imports React and reads CSS variables. Copy the `.jsx` files you need into your app and import them:
```jsx
import { Button } from './zypher-design/components/forms/Button.jsx';
import { Card } from './zypher-design/components/data/Card.jsx';
<Button trailingIcon="↗" href="https://jup.ag">Buy ZPH on Jupiter</Button>
```
(`.d.ts` files give you the prop types; `.prompt.md` files document usage + variants.)

**Option 2 — compiled vanilla bundle (no build step).** Load React UMD, then `_ds_bundle.js`; components appear on `window.ZypherDesignSystem_7d1dbd`:
```html
<script src="https://unpkg.com/react@18.3.1/umd/react.production.min.js"></script>
<script src="https://unpkg.com/react-dom@18.3.1/umd/react-dom.production.min.js"></script>
<link rel="stylesheet" href="/zypher-design/styles.css" />
<script src="/zypher-design/_ds_bundle.js"></script>
<script>
  const { Button, Card, Badge } = window.ZypherDesignSystem_7d1dbd;
  // render with ReactDOM…
</script>
```
Icons used by the demos are **Lucide** (`https://unpkg.com/lucide`). The system standardizes on Lucide stroke icons in teal wells.

---

## Get it live via GitHub

### Route A — Publish a static brand/style guide with GitHub Pages
Fastest way to get a public URL.
1. In your repo, create a folder (e.g. `zypher-design/`) and copy this package's `styles.css`, `tokens/`, `assets/` into it, plus any HTML you want to serve (e.g. `examples/ui_kits/zypher-site/` for the marketing page — also copy `_ds_bundle.js` to the path that page expects).
2. Commit and push:
   ```bash
   git checkout -b zypher-design-system
   git add zypher-design
   git commit -m "Add Zypher design system"
   git push -u origin zypher-design-system
   ```
3. Open a PR / merge to your default branch.
4. Repo **Settings → Pages →** Source: *Deploy from a branch* → pick your branch and `/ (root)` (or `/docs`). Your CSS is then live at `https://<org>.github.io/<repo>/zypher-design/styles.css`.

### Route B — Integrate into your existing website repo
Best when you already have a site (React/Next/Vue/static).
1. Copy `styles.css` + `tokens/` + `assets/` into your site's static/public assets (e.g. `public/zypher-design/`). Link `styles.css` in your root layout/`<head>`.
2. Bring components in via **Option 1** (paste `.jsx` into your component tree and adapt to your conventions) or **Option 2** (vendor `_ds_bundle.js`).
3. Commit on a branch, open a PR, and deploy through your existing pipeline (Vercel/Netlify/GitHub Actions/Pages). Your host serves the merged result — that's "live."

> **Note on the bundle namespace:** `_ds_bundle.js` exposes `window.ZypherDesignSystem_7d1dbd` and is regenerated by the authoring workspace. For a long-lived production site, prefer **Option 1** (component source compiled by your own build) so you control versioning; treat `_ds_bundle.js` as a convenience drop-in.

> **I can't push to your repo from here** (this environment has read-only GitHub access). Hand this folder to **Claude Code** in your local checkout and it can place the files, run the git commands above, and open the PR for you.

---

## Design tokens (reference)
Full values live in `tokens/`. Highlights:

**Color** — `--teal #0F6E56` (primary/action/verified), `--teal-mid #1D9E75`, `--teal-light #E1F5EE`, `--teal-dark #085041`, `--navy #0C2340` (dark sections), slate ramp `--ink #1A202C` / `--slate #4A5568` / `--muted #64748B`, surfaces `--bg #F7F9FC` / `--surface #FFFFFF`, `--border #E2E8F0`. Semantic aliases: `--color-primary`, `--surface-page`, `--surface-card`, `--text-strong/body/muted`, `--border-default`. Dark theme under `[data-theme="dark"]`.

**Type** — `--font-display` DM Serif Display (headlines/numerals), `--font-sans` DM Sans (UI/body), `--font-mono` DM Mono (addresses/code). Weights 300–700; display sizes 24/34/40/52px; body 11–17px.

**Spacing / radius / shadow / motion** — 4px spacing scale; radii 4/6/8/12/16/20/pill; soft teal/navy-tinted shadows; transitions 0.15–0.3s on `cubic-bezier(0.4,0,0.2,1)`; cards lift `translateY(-2px)` on hover.

## Components (18)
`forms/` Button, Input · `data/` Badge, Card, StatCard, MintAddress, Table · `layout/` SectionHeading, Callout, Stepper · `disclosure/` Accordion · `feedback/` Toast (+ ToastViewport, useToast) · `crypto/` WalletButton · `navigation/` Tabs, Menu · `overlay/` Tooltip, Dialog.

## Assets
Logos in `assets/` (`logo-mark.svg`, `logo-wordmark.svg` — faithful SVG recreations of the brand's CSS "Z" mark). Fonts in `assets/fonts/` (self-hosted woff2, OFL-licensed). Icons: Lucide (CDN).

## Source
Built from `https://github.com/zypherthecoin/Zypher` (the marketing site `index.html` is the design source of truth). The dashboard in `examples/` is a net-new extrapolation, not from the source.

# Zypher Design System

The design system for **Zypher (ZPH)** — healthcare payments infrastructure on Solana. This system captures the brand's clinical-meets-crypto voice and a calm, trustworthy visual language: deep navy, verified-green teal, generous whitespace, and a serif/sans/mono type triad.

> **Consumers link one file:** `styles.css` (imports all tokens + fonts). Components are bundled to `window.ZypherDesignSystem_7d1dbd` via the generated `_ds_bundle.js`.

---

## 1 · Company & Product Context

**Zypher (ZPH)** is a Solana-based project building a verified, on-chain provider **data layer** for U.S. healthcare. It ingests authoritative federal data (NPPES, CMS, HRSA), hashes and anchors it to Solana, and exposes a composable provider registry — positioned to address the **$80B+/yr uncompensated-care crisis**. ZPH is the infrastructure token (query fees, validator incentives, governance); **zCARE** is a planned Phase-2 healthcare-native stable payment token.

**Products represented:** one public surface — the **marketing landing page** (recreated as the `zypher-site` UI kit). There is no app or dashboard in the source.

### Sources
- **GitHub:** `https://github.com/zypherthecoin/Zypher` — a single `index.html` (the landing page, the design source of truth) plus `Zypher_Whitepaper.pdf`. Explore this repo to build more accurate Zypher designs.
- All tokens, type, color, and components in this system are lifted directly from that `index.html`.

---

## 2 · Content Fundamentals

**Voice:** confident infrastructure company, not hype-coin. Reads like a fintech/health-tech firm that happens to use a token. Specific, quantified, and a little austere.

- **Person & address:** third-person about the protocol ("Zypher ingests…", "ZPH powers…"); second-person "you" only in instructional/FAQ contexts ("Where can **I** buy ZPH?", "**you** can verify").
- **Casing:** Sentence case for body and most headings. **ALL-CAPS** reserved for eyebrows, tags, ticker strings, and labels (with wide letter-spacing). Serif headlines use an italic teal accent for one emphasized phrase: *"Healthcare payments need a **data layer.**"*
- **Numbers carry the argument:** `$80B+`, `~50%`, `1,000,000,000`, `65,000 TPS`, `<$0.001`. Big serif numerals are a core rhetorical device — but each one is real and load-bearing, never decorative.
- **Tone:** measured, technical, trust-forward. Compliance-aware ("HIPAA-compatible", "utility token, not investment advice"). Crypto terms used precisely (mint authority revoked, SPL, TGE, DEX).
- **Emoji:** the source uses a few emoji as utility/section icons (🔍 ⚙️ 🗳️ 🏦 📄). **This system replaces them with Lucide stroke icons** for a more clinical, consistent feel — see Iconography. Avoid emoji in new work.
- **Vibe:** "the boring, verified plumbing healthcare actually needs" — credibility over excitement.

**Example copy:**
> Eyebrow: `THE PROBLEM` · Headline: "American healthcare loses billions to a broken data layer." · Lede: "Provider directories are inaccurate. Billing systems are fragmented. No unified, real-time source of provider truth exists — and hospitals pay for it every year."

---

## 3 · Visual Foundations

**Color** — Two brand poles on cool neutrals:
- **Teal** (`#0F6E56` primary → `#1D9E75` mid → `#E1F5EE` tint → `#6EE7B7` bright-on-navy) = action, links, "verified/done", icon wells.
- **Navy** (`#0C2340`) = dark sections, footer, the tokenomics spec panel, ticker — signals depth and trust.
- **Slate ramp** (`#1A202C` ink → `#4A5568` body → `#64748B` muted) for text on light.
- **Surfaces:** page `#F7F9FC` (cool off-white), cards pure `#FFFFFF`, hairline borders `#E2E8F0`.
- **Semantic:** amber (`#FEF3C7`/`#92400E`) for in-progress/caution; gold `#B7791F` sparingly. No purple, no rainbow gradients.

**Type** — A three-font DM family:
- **DM Serif Display** — headlines, stat numerals, badge names. Tight tracking (`-1px`), 1.1 line-height, one italic teal accent per headline.
- **DM Sans** — all UI/body. Weight 300 for ledes (airy), 400 body, 500 buttons/nav, 600 titles, 700 caps eyebrows.
- **DM Mono** — on-chain addresses, tickers, code. Almost always teal-on-navy.

**Spacing & layout** — 4px base scale; sections breathe at **96px** vertical padding; content capped at **1100px**. Alternating section backgrounds: off-white `#F7F9FC` ↔ white `#FFFFFF` create rhythm with no dividers needed. 2-, 3-, and 4-column grids with 24px gaps.

**Backgrounds** — Flat color only. No photography, no illustration, no texture. The single decorative move: an oversized, 3%-opacity serif watchword ("zCARE") bleeding off a navy banner. The ticker marquee and a pulsing "Live on Solana" dot are the only ambient motion.

**Cards** — White, `1px` `#E2E8F0` border, **12px** radius, no shadow at rest. Optional **3px teal accent stripe** (top or left). Hover (on interactive cards): lift `translateY(-2px)`, border → teal, soft teal-tinted shadow `0 4px 16px rgba(15,110,86,.10)`.

**Radii** — 4 (chips) · 6 (buttons/inputs) · 8 (callouts) · 12 (cards) · 16 (panels/stat cluster) · 20 (hero banners) · pill (eyebrows).

**Shadows** — Minimal and soft, navy- or teal-tinted. Rest state is usually borderless-flat or hairline-bordered; elevation appears only on hover/overlays. No hard drop shadows.

**Motion** — Quiet and quick. Transitions `0.15–0.3s` on `cubic-bezier(0.4,0,0.2,1)`. Buttons lift 1px + darken on hover; cards lift 2px. Pulse + linear ticker are the only loops, both disabled under `prefers-reduced-motion`.

**Hover / press** — Primary buttons darken teal → `#085041` and rise 1px; secondary buttons gain a teal border + teal text; ghost gets a teal tint. Links shift slate → teal.

**Borders & transparency** — On navy, dividers are `rgba(255,255,255,0.08)` and teal accents use `rgba(29,158,117,0.15–0.3)` fills/borders. The nav uses `backdrop-filter: blur(12px)` over 95%-white. Blur is reserved for the sticky nav only.

**Imagery vibe** — N/A (no imagery in brand). If imagery is ever added, keep it cool-toned, clinical, and restrained to match the navy/teal palette.

---

## 4 · Iconography

- **Source brand:** uses a handful of **emoji** as utility/link/section icons (🔍 ⚙️ 🗳️ 🏦 📄 🏥 ⛓️) and **Unicode arrows** (`↗`, `→`, `○`, `✓`, `+`) for directional/status cues. No SVG icon set or icon font ships in the repo.
- **System standard (substitution — please confirm):** this design system standardizes on **[Lucide](https://lucide.dev)** (loaded from CDN) — thin `~1.75px` stroke icons rendered in `var(--teal)` inside `var(--teal-light)` rounded wells (`10px` radius, `36–44px`). Lucide's clinical, even stroke reads more credibly than emoji for a healthcare-infrastructure brand. The UI kit and `brand-icons` card use Lucide. **Flag:** if you'd prefer to keep the original emoji, or license a different icon set, tell me and I'll switch.
- **Status glyphs** remain Unicode where they read as type, not iconography: `✓` done, `→` active, `○` future, `+` expand.
- **Logo mark:** a serif **"Z"** in a teal rounded square (`8–12px` radius) — see `assets/logo-mark.svg` and `assets/logo-wordmark.svg`. These are faithful SVG recreations of the brand's CSS-defined mark (no logo file exists in the source).

---

## 5 · Fonts — self-hosted

The brand fonts **DM Serif Display, DM Sans, DM Mono** are **vendored locally** as `woff2` under `assets/fonts/` (latin + latin-ext, all required weights/styles; OFL-licensed). `tokens/fonts.css` imports `assets/fonts-local.css`, so the system is fully **offline-capable** — no Google Fonts CDN dependency.

---

## 6 · Index / Manifest

**Root**
- `styles.css` — global entry (import-only).
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `themes.css` (light + `[data-theme="dark"]`), `base.css`.
- `assets/` — `logo-mark.svg`, `logo-wordmark.svg`.
- `guidelines/` — foundation specimen cards (Colors ×3, Type ×3, Spacing ×2, Brand ×2).
- `SKILL.md` — Agent-Skill manifest for downloadable use.

**Components** (`window.ZypherDesignSystem_7d1dbd`)
- `forms/` — **Button**, **Input**
- `data/` — **Badge**, **Card**, **StatCard**, **MintAddress**, **Table**
- `layout/` — **SectionHeading**, **Callout**, **Stepper**
- `disclosure/` — **Accordion**
- `feedback/` — **Toast** (+ `ToastViewport`, `useToast`)
- `crypto/` — **WalletButton**
- `navigation/` — **Tabs**, **Menu**
- `overlay/` — **Tooltip**, **Dialog**

**UI Kits**
- `ui_kits/zypher-site/` — full interactive recreation of the Zypher marketing landing page (also a Starting Point).
- `ui_kits/zypher-app/` — **net-new** ZPH Holder Dashboard (wallet, staking, governance, provider registry, settings); light/dark; dependency-free SVG charts (also a Starting Point).

**Templates**
- `templates/pitch-deck/` — branded 7-slide Zypher pitch deck (`PitchDeck.dc.html`, 1920×1080) on a `deck-stage` shell. Copyable starting point for consuming projects.
- `templates/token-update/` — dark, metrics-forward 5-slide network/community update deck (`TokenUpdate.dc.html`, 1920×1080).

**Design System tab** renders every `@dsCard`-tagged HTML: groups *Colors, Type, Spacing, Brand, Components, Zypher Site, Zypher App*.

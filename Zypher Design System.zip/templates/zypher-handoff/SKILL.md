---
name: zypher-design
description: Use this skill to generate well-branded interfaces and assets for Zypher (ZPH) — healthcare payments infrastructure on Solana — either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files (`styles.css` + `tokens/`, `components/`, `ui_kits/`, `guidelines/`, `assets/`).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view — link `styles.css` for the real tokens and fonts, and use the Lucide icon CDN for iconography. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

Key facts to honor:
- **Palette:** teal (`#0F6E56`) for action/verified, navy (`#0C2340`) for depth/dark sections, cool off-white surfaces, slate text. No purple, no rainbow gradients.
- **Type:** DM Serif Display (headlines + numerals), DM Sans (UI/body), DM Mono (addresses/code) — all Google Fonts.
- **Voice:** confident healthcare-infrastructure company, not hype-coin. Sentence case; ALL-CAPS only for eyebrows/tags; numbers carry the argument.
- **Icons:** Lucide stroke icons in teal wells (not emoji).

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
